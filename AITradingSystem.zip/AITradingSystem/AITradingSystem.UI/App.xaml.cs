﻿using System.Windows;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Data.Binance;
using AITradingSystem.Data.News;
using AITradingSystem.Data.Storage;
using AITradingSystem.Services.AI;
using AITradingSystem.Services.Analysis;
using AITradingSystem.Services.Monitoring;
using AITradingSystem.Services.Trading;
using AITradingSystem.UI.ViewModels;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace AITradingSystem.UI;

public partial class App : Application
{
    private IHost? _host;

    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        try
        {
            _host = Host.CreateDefaultBuilder()
                .ConfigureServices((context, services) =>
                {
                    var configPath = AppDomain.CurrentDomain.BaseDirectory;
                    var config = ConfigLoader.Load(configPath);

                    services.AddSingleton(config);
                    services.AddSingleton(config.Trading);
                    services.AddSingleton(config.Binance);
                    services.AddSingleton(config.AI);
                    services.AddSingleton(config.News);
                    services.AddSingleton(config.Telegram);
                    services.AddSingleton(config.Logging);

                    Logger.Initialize(config.Logging);

                    services.AddSingleton<IBinanceRestClient, BinanceRestClient>();
                    services.AddSingleton<IBinanceWebSocketClient, BinanceWebSocketClient>();
                    services.AddSingleton<INewsProvider, CryptoPanicClient>();
                    services.AddSingleton<NewsAggregator>();
                    services.AddSingleton<ITradeHistoryRepository>(sp =>
                        new JsonTradeHistoryRepository(System.IO.Path.Combine(configPath, "data", "trades.json"), sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<JsonTradeHistoryRepository>>()));
                    services.AddSingleton<IStateRepository>(sp =>
                        new JsonStateRepository(System.IO.Path.Combine(configPath, "data", "state"), sp.GetRequiredService<Microsoft.Extensions.Logging.ILogger<JsonStateRepository>>()));

                    services.AddSingleton<PromptBuilder>();
                    services.AddSingleton<IAIModel, QwenModel>();
                    services.AddSingleton<MarketAnalyzer>();
                    services.AddSingleton<SentimentAnalyzer>();
                    services.AddSingleton<RiskManager>(sp =>
                        new RiskManager(config.Trading, config.Trading.PaperTradingMode ? config.Trading.PaperTradingInitialBalance : 10000m));
                    services.AddSingleton<PositionManager>();
                    services.AddSingleton<IOrderExecutor, OrderExecutor>();
                    services.AddSingleton<TradingEngine>();
                    services.AddSingleton<TelegramAlertService>();
                    services.AddSingleton<MetricsCollector>();

                    services.AddSingleton<MainViewModel>();
                    services.AddSingleton<DashboardViewModel>();
                    services.AddSingleton<TradingViewModel>();
                    services.AddSingleton<SettingsViewModel>();
                    services.AddSingleton<MainWindow>();
                })
                .Build();

            await _host.StartAsync();

            var mainWindow = _host.Services.GetRequiredService<MainWindow>();

            // КОРРЕКТНОЕ ЗАКРЫТИЕ: при закрытии окна останавливаем хост
            mainWindow.Closed += async (sender, args) =>
            {
                if (_host != null)
                {
                    await _host.StopAsync(TimeSpan.FromSeconds(3));
                    _host.Dispose();
                    Logger.Shutdown();
                }
                Environment.Exit(0); // Гарантированный выход
            };

            mainWindow.Show();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Критическая ошибка при запуске:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            Environment.Exit(1);
        }
    }
}
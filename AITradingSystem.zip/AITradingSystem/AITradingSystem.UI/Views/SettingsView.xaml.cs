﻿using System.Windows.Controls;

namespace AITradingSystem.UI.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
    }
}
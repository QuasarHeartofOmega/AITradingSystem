using System.Collections.ObjectModel;
using System.Globalization;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Services.AI;
using AITradingSystem.Services.Monitoring;
using AITradingSystem.Services.Trading;
using CommunityToolkit.Mvvm.ComponentModel;

namespace AITradingSystem.UI.ViewModels;

public partial class DashboardViewModel : ObservableObject
{
    private readonly RiskManager _riskManager;
    private readonly ExchangeAccountService _account;
    private readonly IAIModel _model;
    [ObservableProperty] private decimal _currentBalance;
    [ObservableProperty] private decimal _dailyPnL;
    [ObservableProperty] private string _dailyPnLPercentText = "0.00%";
    [ObservableProperty] private string _drawdownText = "0.00%";
    [ObservableProperty] private int _totalTrades;
    [ObservableProperty] private double _avgInferenceTime;
    [ObservableProperty] private string _usdtFree = "—";
    [ObservableProperty] private string _usdtLocked = "—";
    [ObservableProperty] private string _fdusdFree = "—";
    [ObservableProperty] private string _fdusdLocked = "—";
    [ObservableProperty] private string _usdcFree = "—";
    [ObservableProperty] private string _usdcLocked = "—";
    [ObservableProperty] private string _equityText = "Нет данных";
    [ObservableProperty] private string _environmentText = "—";
    [ObservableProperty] private string _modeText = "—";
    [ObservableProperty] private string _keysStatusText = "—";
    [ObservableProperty] private string _connectionText = "—";
    [ObservableProperty] private string _backendText = "Модель не загружена";
    [ObservableProperty] private string _lastErrorText = string.Empty;
    [ObservableProperty] private string _accountUpdatedText = "Аккаунт ещё не опрошен";
    public ObservableCollection<AssetBalance> AssetBalances { get; } = new();

    public DashboardViewModel(RiskManager riskManager, ExchangeAccountService account, IAIModel model)
    {
        _riskManager = riskManager; _account = account; _model = model;
        CurrentBalance = riskManager.DrawdownTracker.CurrentBalance;
        UpdateAccount();
    }
    private static string Amount(AccountBalance? balance, string asset, bool locked) =>
        balance == null ? "—" : (balance.Assets.TryGetValue(asset, out var a) ? (locked ? a.Locked : a.Free) : 0m)
            .ToString("0.########", CultureInfo.InvariantCulture);
    public void UpdateAccount()
    {
        var snapshot = _account.Snapshot;
        var balance = snapshot.Balance;
        UsdtFree = Amount(balance, "USDT", false); UsdtLocked = Amount(balance, "USDT", true);
        FdusdFree = Amount(balance, "FDUSD", false); FdusdLocked = Amount(balance, "FDUSD", true);
        UsdcFree = Amount(balance, "USDC", false); UsdcLocked = Amount(balance, "USDC", true);
        EquityText = snapshot.Equity.HasValue
            ? snapshot.Equity.Value.ToString("0.##", CultureInfo.InvariantCulture) + " USDT" + (snapshot.EquityIsPartial ? " (частичная оценка)" : string.Empty)
            : "Нет надёжной оценки";
        EnvironmentText = snapshot.Environment;
        ModeText = snapshot.Mode + (snapshot.Mode == "PAPER" ? " — ордера не отправляются" : " — ордера отправляются на биржу");
        KeysStatusText = _account.HasApiKeys ? "Ключи заданы (доступ проверяется запросом)" : "Ключи не заданы";
        ConnectionText = (_account.IsConnected ? "WS подключен" : "WS отключен") + " · REST " +
            (snapshot.LastRefreshUtc.HasValue && snapshot.Error == null ? "получен" : snapshot.Error == null ? "ожидание" : "ошибка/частичные данные");
        AccountUpdatedText = snapshot.LastRefreshUtc.HasValue ? "Обновлено UTC: " + snapshot.LastRefreshUtc.Value.ToString("yyyy-MM-dd HH:mm:ss") : "Аккаунт ещё не опрошен";
        LastErrorText = string.Join(" | ", new[] { snapshot.Error, (_model as QwenModel)?.LoadWarning }.Where(s => !string.IsNullOrEmpty(s)));
        AssetBalances.Clear();
        if (balance != null) foreach (var asset in balance.Assets.Values.OrderBy(a => a.Asset)) AssetBalances.Add(asset);
        UpdateBackend();
    }
    private void UpdateBackend()
    {
        BackendText = _model is QwenModel q ? q.IsLoaded ? q.BackendSummary : "Модель не загружена; конфигурация " + q.ActiveBackend : "Модель не загружена";
        LastInferenceText = _model.LastInferenceTimeMs > 0 ? _model.LastInferenceTimeMs.ToString("F0", CultureInfo.InvariantCulture) + " ms" : "Нет измерений";
    }
    [ObservableProperty] private string _lastInferenceText = "Нет измерений";
    public void UpdateMetrics(MetricsCollector metrics)
    {
        var tracker = _riskManager.DrawdownTracker;
        CurrentBalance = tracker.CurrentBalance; DailyPnL = tracker.DailyPnL;
        DailyPnLPercentText = $"{tracker.DailyPnLPercent:P2}"; DrawdownText = $"{tracker.CurrentDrawdownPercent:P2}";
        TotalTrades = metrics.TotalTrades; AvgInferenceTime = metrics.AverageInferenceTimeMs;
        UpdateBackend();
    }
}

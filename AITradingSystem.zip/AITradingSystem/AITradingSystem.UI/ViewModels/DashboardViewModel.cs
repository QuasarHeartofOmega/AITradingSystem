﻿using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Services.Monitoring;
using CommunityToolkit.Mvvm.ComponentModel;

namespace AITradingSystem.UI.ViewModels;

public partial class DashboardViewModel : ObservableObject
{
    private readonly RiskManager _riskManager;

    [ObservableProperty]
    private decimal _currentBalance;

    [ObservableProperty]
    private decimal _dailyPnL;

    [ObservableProperty]
    private string _dailyPnLPercentText = "0.00%";

    [ObservableProperty]
    private string _drawdownText = "0.00%";

    [ObservableProperty]
    private int _totalTrades;

    [ObservableProperty]
    private double _avgInferenceTime;

    public DashboardViewModel(RiskManager riskManager)
    {
        _riskManager = riskManager ?? throw new System.ArgumentNullException(nameof(riskManager));
        CurrentBalance = _riskManager.DrawdownTracker.CurrentBalance;
    }

    public void UpdateMetrics(MetricsCollector metrics)
    {
        var tracker = _riskManager.DrawdownTracker; // Берем трекер из единого RiskManager

        CurrentBalance = tracker.CurrentBalance;
        DailyPnL = tracker.DailyPnL;

        DailyPnLPercentText = $"{tracker.DailyPnLPercent:P2}";
        DrawdownText = $"{tracker.CurrentDrawdownPercent:P2}";

        TotalTrades = metrics.TotalTrades;
        AvgInferenceTime = metrics.AverageInferenceTimeMs;
    }
}
using System.Collections.ObjectModel;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Services.Trading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.UI.ViewModels;

public partial class TradingViewModel : ObservableObject
{
	private readonly PositionManager _positionManager;
    private readonly IOrderExecutor _orderExecutor; 
	private readonly ILogger<TradingViewModel> _logger;

	[ObservableProperty]
	private ObservableCollection<Position> _openPositions = new();

	[ObservableProperty]
	private ObservableCollection<TradeRecord> _tradeHistory = new();

	[ObservableProperty]
	private string _lastSignalText = "Ожидание сигнала...";

	public TradingViewModel(
		PositionManager positionManager,
		IOrderExecutor orderExecutor, 
		ILogger<TradingViewModel> logger)
	{
		_positionManager = positionManager;
		_orderExecutor = orderExecutor;
		_logger = logger;

		// Загрузка начальных данных
		foreach (var pos in _positionManager.GetOpenPositions())
		{
			OpenPositions.Add(pos);
		}
	}

	public void AddSignal(TradingSignal signal)
	{
		LastSignalText = $"[{signal.Timestamp:HH:mm:ss}] {signal.Symbol}: {signal.Action} (Conf: {signal.Confidence:P0})\nReason: {signal.Reasoning}";
	}

	public void AddPosition(Position position)
	{
		OpenPositions.Add(position);
	}

	public void RemovePosition(string symbol)
	{
		var pos = OpenPositions.FirstOrDefault(p => p.Symbol == symbol);
		if (pos != null)
		{
			OpenPositions.Remove(pos);
		}
	}

	public void AddTradeRecord(TradeRecord trade)
	{
		TradeHistory.Insert(0, trade);
		if (TradeHistory.Count > 100)
		{
			TradeHistory.RemoveAt(100);
		}
	}

	[RelayCommand]
	private async Task ClosePositionAsync(Position position)
	{
		if (position == null) return;

		_logger.LogInformation("Ручное закрытие позиции {Symbol}", position.Symbol);
		var order = await _orderExecutor.ClosePositionAsync(position);

		if (order != null)
		{
			// В реальном приложении здесь будет ожидание заполнения и создание TradeRecord
			// Для упрощения UI просто удаляем из списка
			RemovePosition(position.Symbol);
		}
	}
}
﻿using AITradingSystem.Common.Configuration;
using CommunityToolkit.Mvvm.ComponentModel;

namespace AITradingSystem.UI.ViewModels;

public partial class SettingsViewModel : ObservableObject
{
    private readonly AppConfig _config;

    [ObservableProperty]
    private string _symbolsList;

    [ObservableProperty]
    private double _riskPerTrade;

    [ObservableProperty]
    private double _maxDrawdown;

    [ObservableProperty]
    private bool _paperTradingMode;

    public SettingsViewModel(AppConfig config)
    {
        _config = config;
        SymbolsList = string.Join(", ", config.Trading.Symbols);
        RiskPerTrade = config.Trading.RiskPerTrade * 100; // В процентах
        MaxDrawdown = config.Trading.MaxDrawdown * 100;
        PaperTradingMode = config.Trading.PaperTradingMode;
    }
}
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Config;
using AITradingSystem.Services.AI;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AITradingSystem.UI.ViewModels;

public partial class SymbolSetting : ObservableObject
{
    [ObservableProperty] private string _symbol = string.Empty;
    [ObservableProperty] private bool _isEnabled = true;
    [ObservableProperty] private decimal _maxPositionPercent = 5m;
}

public partial class SettingsViewModel : ObservableObject
{
    private readonly AppConfig _config;
    private readonly IAIModel _model;
    public ObservableCollection<SymbolSetting> SymbolItems { get; } = new();
    [ObservableProperty] private string _watchAssetsList;
    [ObservableProperty] private string _quoteAssetsList;
    [ObservableProperty] private double _riskPerTrade;
    [ObservableProperty] private double _maxDrawdown;
    [ObservableProperty] private bool _paperTradingMode;
    [ObservableProperty] private string _binanceEnvironment;
    [ObservableProperty] private string _aiBackend;
    [ObservableProperty] private bool _enableThinking;
    [ObservableProperty] private bool _aiCanClosePositions;
    [ObservableProperty] private bool _cryptocurrencyCvEnabled;
    [ObservableProperty] private string _statusText = string.Empty;
    [ObservableProperty] private string _backendInfo = "Модель ещё не загружена";
    public IReadOnlyList<string> BinanceEnvironments { get; } = new[] { "Demo", "Testnet", "Live" };
    public IReadOnlyList<string> AiBackends { get; } = new[] { "Auto", "Cuda12", "Vulkan", "Cpu" };

    public SettingsViewModel(AppConfig config, IAIModel model)
    {
        _config = config; _model = model;
        var registry = LoadRegistry();
        foreach (var item in registry.Symbols)
            SymbolItems.Add(new SymbolSetting { Symbol = item.Symbol, IsEnabled = item.Enabled, MaxPositionPercent = item.MaxPositionPercent });
        _watchAssetsList = string.Join(", ", config.Trading.WatchAssets);
        _quoteAssetsList = string.Join(", ", config.Trading.QuoteAssets);
        _riskPerTrade = config.Trading.RiskPerTrade * 100;
        _maxDrawdown = config.Trading.MaxDrawdown * 100;
        _paperTradingMode = config.Trading.PaperTradingMode;
        _binanceEnvironment = config.Binance.ResolvedEnvironment.ToString();
        _aiBackend = config.AI.ResolvedBackend.ToString();
        _enableThinking = config.AI.EnableThinking;
        _aiCanClosePositions = config.Trading.AiCanClosePositions;
        _cryptocurrencyCvEnabled = config.News.CryptocurrencyCvEnabled;
        RefreshBackendInfo();
    }

    private static string ConfigPath(string file) => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, file);
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true, WriteIndented = true };
    private SymbolsRegistry LoadRegistry()
    {
        var path = ConfigPath("symbols.json");
        if (File.Exists(path))
        {
            var saved = JsonSerializer.Deserialize<SymbolsRegistry>(File.ReadAllText(path), JsonOptions);
            if (saved is { Symbols.Count: > 0 }) return saved;
        }
        return new SymbolsRegistry
        {
            Symbols = _config.Trading.Symbols.Select(s => new SymbolConfig { Symbol = s, MaxPositionPercent = 5m }).ToList(),
            WatchAssets = new(_config.Trading.WatchAssets), QuoteAssets = new(_config.Trading.QuoteAssets)
        };
    }
    public void RefreshBackendInfo()
    {
        BackendInfo = _model is QwenModel q
            ? $"{q.BackendSummary}; AutoFit={_config.AI.AutoFitGpu}, VRAM reserve={_config.AI.VramReserveMb} MiB" +
              (string.IsNullOrEmpty(q.LoadWarning) ? string.Empty : "; " + q.LoadWarning)
            : $"Конфигурация: {_config.AI.Backend}; AutoFit={_config.AI.AutoFitGpu}";
    }
    [RelayCommand] private void AddSymbol()
    {
        if (SymbolItems.Count < 32) SymbolItems.Add(new SymbolSetting());
        else StatusText = "Максимум 32 пары.";
    }
    [RelayCommand] private void RemoveSymbol(SymbolSetting? item) { if (item != null) SymbolItems.Remove(item); }
    [RelayCommand] private void Save()
    {
        try
        {
            var registry = LoadRegistry();
            registry.WatchAssets = WatchAssetsList.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).ToList();
            registry.QuoteAssets = QuoteAssetsList.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).ToList();
            registry.Symbols = SymbolItems.Select((item, i) => {
                var old = registry.Symbols.FirstOrDefault(s => s.Symbol.Equals(item.Symbol.Trim(), StringComparison.OrdinalIgnoreCase));
                return new SymbolConfig { Symbol = item.Symbol, Enabled = item.IsEnabled, MaxPositionPercent = item.MaxPositionPercent,
                    Priority = old?.Priority ?? i, Notes = old?.Notes ?? string.Empty, PriceDecimals = old?.PriceDecimals };
            }).ToList();
            registry.UpdatedAt = DateTime.UtcNow;
            registry.Validate();
            var trading = new TradingConfig
            {
                Symbols = registry.Symbols.Where(s => s.Enabled).Select(s => s.Symbol).ToList(),
                WatchAssets = new(registry.WatchAssets), QuoteAssets = new(registry.QuoteAssets),
                RiskPerTrade = RiskPerTrade / 100, MaxDrawdown = MaxDrawdown / 100,
                PaperTradingMode = PaperTradingMode, AiCanClosePositions = AiCanClosePositions,
                AccountRefreshIntervalSeconds = _config.Trading.AccountRefreshIntervalSeconds,
                MinExchangePositionNotional = _config.Trading.MinExchangePositionNotional
            };
            trading.Validate();
            var path = ConfigPath("appsettings.json");
            var root = File.Exists(path) ? JsonNode.Parse(File.ReadAllText(path))?.AsObject() ?? new JsonObject() : new JsonObject();
            var section = root["Trading"]?.AsObject() ?? new JsonObject();
            section["Symbols"] = new JsonArray(trading.Symbols.Select(s => JsonValue.Create(s)).ToArray());
            section["WatchAssets"] = new JsonArray(registry.WatchAssets.Select(s => JsonValue.Create(s)).ToArray());
            section["QuoteAssets"] = new JsonArray(registry.QuoteAssets.Select(s => JsonValue.Create(s)).ToArray());
            section["SymbolPositionLimits"] = new JsonObject(registry.Symbols.Where(s => s.Enabled).Select(s => new KeyValuePair<string, JsonNode?>(s.Symbol, JsonValue.Create(s.MaxPositionPercent))));
            section["RiskPerTrade"] = trading.RiskPerTrade; section["MaxDrawdown"] = trading.MaxDrawdown;
            section["PaperTradingMode"] = PaperTradingMode; section["AiCanClosePositions"] = AiCanClosePositions;
            root["Trading"] = section;
            var binance = root["Binance"]?.AsObject() ?? new JsonObject();
            binance["Environment"] = BinanceEnvironment; binance["UseTestnet"] = BinanceEnvironment == "Testnet"; root["Binance"] = binance;
            var ai = root["AI"]?.AsObject() ?? new JsonObject(); ai["Backend"] = AiBackend; ai["EnableThinking"] = EnableThinking; root["AI"] = ai;
            var news = root["News"]?.AsObject() ?? new JsonObject(); news["CryptocurrencyCvEnabled"] = CryptocurrencyCvEnabled; root["News"] = news;
            // Сначала реестр, затем appsettings; UI сообщает о необходимости перезапуска.
            File.WriteAllText(ConfigPath("symbols.json"), JsonSerializer.Serialize(registry, JsonOptions));
            File.WriteAllText(path, root.ToJsonString(JsonOptions));
            StatusText = "Сохранено. Перезапустите приложение: список пар, режим, ключи и GPU применяются при старте.";
        }
        catch (Exception ex) { StatusText = "Ошибка сохранения: " + ex.Message; }
    }
}

using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;
using AITradingSystem.Common.Configuration;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AITradingSystem.UI.ViewModels;

public partial class SettingsViewModel : ObservableObject
{
    private readonly AppConfig _config;

    [ObservableProperty]
    private string _symbolsList;

    [ObservableProperty]
    private double _riskPerTrade;

    [ObservableProperty]
    private double _maxDrawdown;

    [ObservableProperty]
    private bool _paperTradingMode;

    /// <summary>Окружение Binance: Live | Testnet | Demo (demo.binance.com).</summary>
    [ObservableProperty]
    private string _binanceEnvironment;

    /// <summary>Бэкенд инференса: Auto | Cuda12 | Vulkan | Cpu.</summary>
    [ObservableProperty]
    private string _aiBackend;

    [ObservableProperty]
    private bool _enableThinking;

    [ObservableProperty]
    private bool _aiCanClosePositions;

    [ObservableProperty]
    private bool _cryptocurrencyCvEnabled;

    public IReadOnlyList<string> BinanceEnvironments { get; } = new[] { "Demo", "Testnet", "Live" };
    public IReadOnlyList<string> AiBackends { get; } = new[] { "Auto", "Cuda12", "Vulkan", "Cpu" };

    [ObservableProperty]
    private string _statusText = string.Empty;

    public SettingsViewModel(AppConfig config)
    {
        _config = config;
        SymbolsList = string.Join(", ", config.Trading.Symbols);
        RiskPerTrade = config.Trading.RiskPerTrade * 100; // В процентах
        MaxDrawdown = config.Trading.MaxDrawdown * 100;
        PaperTradingMode = config.Trading.PaperTradingMode;
        _binanceEnvironment = config.Binance.ResolvedEnvironment.ToString();
        _aiBackend = config.AI.ResolvedBackend.ToString();
        _enableThinking = config.AI.EnableThinking;
        _aiCanClosePositions = config.Trading.AiCanClosePositions;
        _cryptocurrencyCvEnabled = config.News.CryptocurrencyCvEnabled;
    }

    [RelayCommand]
    private void Save()
    {
        try
        {
            // === Валидация ===
            var symbols = SymbolsList
                .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(s => s.ToUpperInvariant())
                .Distinct()
                .ToList();

            if (symbols.Count == 0 || symbols.Count > 10)
            {
                StatusText = "Ошибка: укажите от 1 до 10 торговых пар.";
                return;
            }

            if (RiskPerTrade <= 0 || RiskPerTrade > 5)
            {
                StatusText = "Ошибка: риск на сделку должен быть в диапазоне (0; 5]%.";
                return;
            }

            if (MaxDrawdown <= 0 || MaxDrawdown >= 100)
            {
                StatusText = "Ошибка: макс. просадка должна быть в диапазоне (0; 100)%.";
                return;
            }

            // === Обновляем конфиг в памяти (применится при следующем «Старт») ===
            _config.Trading.Symbols = symbols;
            _config.Trading.RiskPerTrade = RiskPerTrade / 100.0;
            _config.Trading.MaxDrawdown = MaxDrawdown / 100.0;
            _config.Trading.PaperTradingMode = PaperTradingMode;
            _config.Trading.AiCanClosePositions = AiCanClosePositions;
            _config.Binance.Environment = BinanceEnvironment;
            _config.AI.Backend = AiBackend;
            _config.AI.EnableThinking = EnableThinking;
            _config.News.CryptocurrencyCvEnabled = CryptocurrencyCvEnabled;

            // GPU-бэкенд имеет смысл только со всеми слоями на видеокарте.
            if (!AiBackend.Equals("Cpu", StringComparison.OrdinalIgnoreCase) && _config.AI.GpuLayers == 0)
                _config.AI.GpuLayers = -1;

            // === Персистим в appsettings.json рядом с exe ===
            var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "appsettings.json");
            var root = File.Exists(path)
                ? JsonNode.Parse(File.ReadAllText(path)) ?? new JsonObject()
                : new JsonObject();

            var trading = root["Trading"] as JsonObject ?? new JsonObject();
            trading["Symbols"] = new JsonArray(symbols.Select(s => JsonValue.Create(s)).ToArray());
            trading["RiskPerTrade"] = _config.Trading.RiskPerTrade;
            trading["MaxDrawdown"] = _config.Trading.MaxDrawdown;
            trading["PaperTradingMode"] = PaperTradingMode;
            trading["AiCanClosePositions"] = AiCanClosePositions;
            root["Trading"] = trading;

            var binance = root["Binance"] as JsonObject ?? new JsonObject();
            binance["Environment"] = BinanceEnvironment;
            binance["UseTestnet"] = BinanceEnvironment.Equals("Testnet", StringComparison.OrdinalIgnoreCase);
            root["Binance"] = binance;

            var ai = root["AI"] as JsonObject ?? new JsonObject();
            ai["Backend"] = AiBackend;
            ai["EnableThinking"] = EnableThinking;
            ai["GpuLayers"] = _config.AI.GpuLayers;
            root["AI"] = ai;

            var news = root["News"] as JsonObject ?? new JsonObject();
            news["CryptocurrencyCvEnabled"] = CryptocurrencyCvEnabled;
            root["News"] = news;

            File.WriteAllText(path, root.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));

            SymbolsList = string.Join(", ", symbols);
            StatusText = "Сохранено ✓ Пары/риск — со следующего «Старт»; окружение Binance и бэкенд GPU — после перезапуска.";
        }
        catch (Exception ex)
        {
            StatusText = $"Ошибка сохранения: {ex.Message}";
        }
    }
}

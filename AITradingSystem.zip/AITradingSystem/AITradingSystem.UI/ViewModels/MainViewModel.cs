using System.Windows;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Services.Monitoring;
using AITradingSystem.Services.Trading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.UI.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly TradingEngine _engine;
    private readonly MetricsCollector _metrics;
    private readonly ILogger<MainViewModel> _logger;



    [ObservableProperty]
    private BotStatus _botStatus = BotStatus.Stopped;

    [ObservableProperty]
    private string _statusText = "Остановлен";

    [ObservableProperty]
    private bool _isRunning;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(StartCommand))]
    private bool _canStart = true;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(StopCommand))]
    private bool _canStop;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(PauseCommand))]
    private bool _canPause;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(ResumeCommand))]
    private bool _canResume;

    public DashboardViewModel Dashboard { get; }
    public TradingViewModel Trading { get; }
    public SettingsViewModel Settings { get; }

    public MainViewModel(
        TradingEngine engine,
        MetricsCollector metrics,
        DashboardViewModel dashboard,
        TradingViewModel trading,
        SettingsViewModel settings,
        ILogger<MainViewModel> logger)
    {
        _engine = engine;
        _metrics = metrics;
        _logger = logger;
        Dashboard = dashboard;
        Trading = trading;
        Settings = settings;

        // Подписка на события движка
        _engine.OnStatusChanged += OnStatusChanged;
        _engine.OnSignalGenerated += signal => Application.Current.Dispatcher.Invoke(() => Trading.AddSignal(signal));
        _engine.OnPositionOpened += pos => Application.Current.Dispatcher.Invoke(() => Trading.AddPosition(pos));
        _engine.OnPositionClosed += trade =>
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                Trading.RemovePosition(trade.Symbol);
                Trading.AddTradeRecord(trade);
                _metrics.RecordTrade(trade);
                Dashboard.UpdateMetrics(_metrics);
            });
        };
    }

    private void OnStatusChanged(BotStatus status)
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            BotStatus = status;
            StatusText = status switch
            {
                BotStatus.Stopped => "Остановлен",
                BotStatus.Starting => "Запуск...",
                BotStatus.Running => "Работает",
                BotStatus.Paused => "Приостановлен",
                BotStatus.Stopping => "Остановка...",
                BotStatus.Error => "Ошибка",
                _ => "Неизвестно"
            };

            IsRunning = status == BotStatus.Running || status == BotStatus.Paused;
            CanStart = status == BotStatus.Stopped || status == BotStatus.Error;
            CanStop = status == BotStatus.Running || status == BotStatus.Paused || status == BotStatus.Starting;
            CanPause = status == BotStatus.Running;
            CanResume = status == BotStatus.Paused;
        });
    }

    [RelayCommand(CanExecute = nameof(CanStart))]
    private async Task StartAsync()
    {
        try
        {
            await _engine.StartAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка при запуске движка");
            MessageBox.Show($"Ошибка запуска: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    [RelayCommand(CanExecute = nameof(CanStop))]
    private async Task StopAsync()
    {
        await _engine.StopAsync();
    }

    [RelayCommand(CanExecute = nameof(CanPause))]
    private void Pause()
    {
        _engine.Pause();
    }

    [RelayCommand(CanExecute = nameof(CanResume))]
    private void Resume()
    {
        _engine.Resume();
    }
}
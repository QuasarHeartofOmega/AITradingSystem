# План доработок AITradingSystem — трекер выполнения

Источник: план пользователя (P0 / P1 / P2), скопирован дословно; добавлены статусы, ссылки на файлы и критерии приёмки.
Аудит выполнен: **24.11.2026**, по коду из `AITradingSystem.zip` (репозиторий `QuasarHeartofOmega/AITradingSystem`).

## Легенда

| Метка | Значение |
|---|---|
| ✅ | Выполнено — обязательно перечислены **изменённые файлы** |
| 🟡 | Частично — есть фундамент, но критерий пункта не выполнен |
| ⬜ | Не сделано — указаны файлы, которые предстоит менять |

**Правило ведения файла:** пункт переводится в ✅ только вместе со списком изменённых файлов (и, при наличии, коммитом). Пока кода нет — статус не меняется. Промежуточное состояние фиксируется как 🟡 с описанием, чего именно не хватает.

## Сводка на 24.11.2026 (после прохода 11 — P0 закрыт 7/7, фикс `volume_ratio` выполнен; осталось 13 шагов очереди)

| Блок | Готово | Частично | Не сделано |
|---|---|---|---|
| P0 — защита капитала | 7 / 7 | 0 | 0 |
| P1 — деньги и данные | 0 / 8 | 2 | 6 |
| P2 — сигнал и HOLD | 1 / 6 | 1 | 4 |

> **Проход 1 (аудит):** код не менялся, выполнен P2.1 — диагностика по логам (артефакт: [`docs/signal-funnel-20261124.md`](docs/signal-funnel-20261124.md)).
> **Проход 2:** выполнен **P0.1 — биржевые стоп-ордера OCO**.
> **Проход 3:** выполнен **P0.2 — независимый контур мониторинга на тик WS**.
> **Проход 4:** по команде заказчика сделан **фундамент P0.3 — очередь исполнения с приоритетами и идемпотентность по `clientOrderId`**; пункт был переведён в 🟡.
> **Проход 5:** **P0.3 доведён до ✅** — durable-журнал намерений (идемпотентность переживает рестарт), детерминированные `clientOrderId`, ретрай операции с backoff/jitter и лимитом попыток, метрики очереди в дашборде. Остаток, не входящий в P0.3, явно передан P0.5 / P1.6 / P0.6.
> **Проход 7 (ранее не записанный):** обнаружен и зафиксирован фундамент **P0.5–P0.7**: `ReconciliationService`, `ExecutionReport`, listenKey/user-data WS, авто/ручной kill-switch, двухшаговый Live и отдельные Live-ключи в конфиге. UI/DI были не доведены.
> **Проход 8:** фундамент учтён в трекере; доведены DI-регистрация `ReconciliationService`, ключи `appsettings.json`, UI подтверждения Live/отдельных Live-ключей, несмываемый баннер REAL MONEY, сброс kill-switch и панель реконсиляции в дашборде. **P0.6 и P0.7 закрыты**.
> **Проход 9:** проверка завершённости **P0.5** по коду — все четыре пункта остатка (применение филлов без повторного MARKET, подхват сирот, пересоздание listenKey + реконсиляция, частичные филлы из stream) реализованы в дереве, но не были записаны в трекер. **P0.5 → ✅**, блок **P0 закрыт полностью (7/7)**. Код в этом проходе не менялся — только SECUPD.md. Следующий шаг — **P1.6** (бюджет весов), либо по порядку работ — фикс `volume_ratio` → P2.2.
> **Проход 10:** по команде заказчика оставшиеся работы упорядочены от лёгких/мелких к тяжёлым/большим с сохранением зависимостей. Код не менялся; изменён только `SECUPD.md`. Первый шаг очереди — фикс `volume_ratio`, последний — P2.6.
 > **Проход 11 (этот):** исходники распакованы из архива в корень клона; выполнен **шаг №1 очереди — фикс `volume_ratio`**. Числитель отношения теперь берётся из последней закрытой свечи калькулятора, а не из внутриинтервального WS-тика. Добавлены регрессионные тесты, не запускались. Следующий шаг — **№2, P1.8: мониторинг дрейфа часов**.
> **Проход 6:** **P0.4 выполнен** — полный персист риск-состояния (`risk_state.json`: пик, дневной старт, дата дня, макс. просадка, баланс), граница дня по часам биржи, восстановление в `StartAsync` до первого `UpdateBalance`, персист после каждого изменения баланса, миграция с legacy `peak_balance.json`. Следующий по плану — **P0.6** (kill-switch), не начат.
> Счётчики «частично/не сделано» пересчитаны по фактическим статусам пунктов (в проходе 2 сводка P0/P1 расходилась с телом документа).
>
> **Замечания к рабочему дереву:**
> - В git-репозитории лежит только `AITradingSystem.zip`; исходники распакованы. **С прохода 6 корень решения — сам клон `AITradingSystem/`** (без подкаталога `extracted/`, которого в снапшоте репозитория не было); все пути ниже относительны его. Правки внесены в распакованные файлы, zip не пересобирался. Проверено: zip уже содержит правки проходов 2–5 (`ExecutionQueue`, `PositionMonitor`, OCO-модели, журнал намерений на месте).
> - Распаковка zip перезаписала `README.md` репозитория (в клоне был 1-байтовый, в zip — свой); прочее дерево клона не тронуто.
> - Артефакт `docs/signal-funnel-20261124.md`, на который ссылается P2.1, **в снапшоте репозитория отсутствует** — каталога `docs/` нет. Выводы диагностики сохранены в тексте P2.1.
> - Сборки/компиляции в этом проходе не выполнялись (по требованию заказчика); тесты добавлены, но не запускались.

---

## P0 — защита капитала

### ✅ P0.1 Биржевые стоп-ордера
> Биржевые стоп-ордера: OCO (`STOP_LOSS_LIMIT` + `TAKE_PROFIT_LIMIT`) сразу после филла входа; трейлинг через cancel/replace (`OrderExecutor`, `BinanceRestClient`). Локальный SL — только дублёр. **Критерий: убить процесс с позицией → биржа закрывает сама.**

**Выполнено 24.11.2026 (проход 2).** Защита теперь ставится на самой бирже связкой OCO и переживает смерть процесса: ноги `STOP_LOSS_LIMIT` + `TAKE_PROFIT_LIMIT` остаются в стакане Binance, активация одной отменяет другую.

**Что сделано:**
1. **REST-слой:** `POST /api/v3/orderList/oco` (новый эндпоинт Binance, не legacy `/api/v3/order/oco`), `DELETE /api/v3/orderList`, `GET /api/v3/openOrderList`. Для SELL-защиты long: `aboveType=TAKE_PROFIT_LIMIT`, `belowType=STOP_LOSS_LIMIT`; для BUY — зеркально. У каждой связки/ноги свой `listClientOrderId`/`clientOrderId` (`oco-`/`sl-`/`tp-` + GUID, ≤36 символов).
2. **Постановка сразу после филла:** `TradingEngine.ProcessSymbolAsync` → `EnsureExchangeProtectionAsync` → `OrderExecutor.EnsureProtectionAsync` сразу после `AddPositionAsync`. Ориентир цены для правила OCO — mid стакана (актуальнее закрытия свечи).
3. **Fail-closed:** если OCO не встала в live — позиция закрывается market'ом (`Trading:ClosePositionIfProtectionFails=true`), правило «нет биржевой защиты → нет позиции». Тот же контроль применяется на каждом круге сопровождения, т.е. позиции, восстановленные из `positions.json` без защиты, либо получают OCO, либо закрываются.
4. **Трейлинг через cancel/replace:** `OrderExecutor.UpdateStopLossAsync` снимает старую связку и ставит новую с подтянутым стопом; локальный SL двигается **только после подтверждённой замены**. Троттлинг: `TrailingReplaceMinIntervalSeconds=30`, `TrailingReplaceMinStepPercent=0.15`. Если новая связка не встала — восстанавливается прежний стоп; если и это не удалось — позиция помечается незащищённой и закрывается движком.
5. **Закрытие:** перед MARKET-выходом OCO снимается (`CancelProtectionAsync`), иначе базовый актив заблокирован ногами и биржа отвечает -2010. Ответ «unknown order/list» (-2011) трактуется как «связки уже нет» (вероятно, сработала нога) и логируется `PROTECTION-GONE`.
6. **Округления защитных ног (задел под P1.3):** `ProtectiveOrderPricing.TryBuild` округляет объём к `stepSize`, обе цены к `tickSize` в сторону исполнения, проверяет `minQty` и `minNotional` по худшей ноге и правило Binance `TP.stopPrice > LastPrice > SL.stopPrice`. Лимитная цена отступает от триггера на `ProtectionLimitSlippage=0.3%`, чтобы сработавшая нога налилась.
7. **Персист:** `Position.Protection` (`ProtectiveOrderList`: orderListId, id/clientOrderId обеих ног, триггеры и лимитные цены, объём, статус) сохраняется в `positions.json` сразу после постановки/замены.
8. **Paper-режим:** защита симулируется (`IsSimulated=true`, на биржу ничего не отправляется), выходы по-прежнему считает локальный мониторинг.

**Изменённые файлы:**
- **новые:** `AITradingSystem.Core/Models/Trading/ProtectiveOrderList.cs`, `AITradingSystem.Core/Models/Trading/ProtectiveOrderPricing.cs`
- `AITradingSystem.Core/Models/Trading/Position.cs` (`Protection`, `HasExchangeProtection`, `SetProtection`)
- `AITradingSystem.Data/Binance/IBinanceRestClient.cs` (`PlaceOcoAsync`, `CancelOcoAsync`, `GetOpenOrderListsAsync`)
- `AITradingSystem.Data/Binance/BinanceRestClient.cs` (реализация OCO + `MapToProtection`; `BinanceApiException.IsUnknownOrderOrList`, `IsWouldImmediatelyTrigger`)
- `AITradingSystem.Data/Binance/BinanceModels.cs` (`BinanceOrderListResponse`, `BinanceOrderListRef`, `BinanceOrderResponse.StopPrice`)
- `AITradingSystem.Services/Trading/IOrderExecutor.cs` (`EnsureProtectionAsync`, `CancelProtectionAsync`, `UpdateStopLossAsync` → `Task<bool>`)
- `AITradingSystem.Services/Trading/OrderExecutor.cs` (постановка/замена/снятие OCO, cancel перед market-закрытием)
- `AITradingSystem.Services/Trading/TradingEngine.cs` (`EnsureExchangeProtectionAsync`, вызов после филла и в `MonitorPositionAsync`, трейлинг через executor, mid стакана как ориентир цены)
- `AITradingSystem.Common/Configuration/TradingConfig.cs` (`ExchangeProtectionEnabled`, `ProtectionLimitSlippage`, `ClosePositionIfProtectionFails`, `TrailingReplaceMinIntervalSeconds`, `TrailingReplaceMinStepPercent` + валидация)
- `AITradingSystem.UI/appsettings.json` (те же 5 ключей)
- `AITradingSystem.Tests/TradingLogicTests.cs` (5 тестов: правило above/below, отказ при стопе за рынком, округление/minNotional, порог значимости трейлинга, `HasExchangeProtection`)

**Критерий приёмки:** выполнен на уровне механики — ноги OCO живут на бирже независимо от процесса. Проверка «убить процесс» в живом окружении не проводилась (сборки/запуски запрещены в этом проходе).

**Остаточные ограничения (не входят в P0.1):**
- если биржа исполнила стоп, пока процесс был мёртв, после рестарта бот увидит позицию из `positions.json` и попытается закрыть её повторно — ~~распознавание филлов через user-data stream/реконсиляцию делает **P0.5**~~ **закрыто проходом 9 (P0.5 ✅)**: филл применяется через `ApplyExchangeFillAsync` с дедуп-леджером, повторный MARKET не шлётся;
- ~~accompanied-мониторинг по-прежнему ходит раз в круг анализа (~7 мин на 12 пар)~~ — **закрыто проходом 3 (P0.2)**: сопровождение вынесено в тик-контур `PositionMonitor`;
- `GetOpenOrderListsAsync` возвращает только id связки/ног (Binance не отдаёт типы и цены в `openOrderList`) — ~~разбор ног оставлен реконсиляции P0.5~~ **закрыто проходом 9**: реконсиляция запрашивает ноги по `origClientOrderId`.

---

### ✅ P0.2 Независимый контур мониторинга
> Независимый контур мониторинга: сопровождение позиций на каждый тик WS (≤1–2 с), без `await` LLM (`TradingEngine`).

**Выполнено 24.11.2026 (проход 3).** Сопровождение позиций больше не стоит в очереди за инференсом модели: отдельный контур `PositionMonitor` реагирует на тики WebSocket и проверяет SL/TP, биржевую защиту и трейлинг независимо от цикла анализа.

**Что сделано:**
1. **Новый контур:** `PositionMonitor` — собственный цикл с периодом `PositionMonitorIntervalMs=500` мс. В нём нет ни одного обращения к LLM/новостям: только цена, SL/TP, OCO-защита и трейлинг.
2. **Тики без блокировки WS:** `OnKlineReceived`/`OnOrderBookReceived` пишут последний тик в `ConcurrentDictionary` (latest-wins) и сразу возвращаются — receive-loop не ждёт REST. Источники: kline (~2 с) и partial-depth `@depth20@1000ms` (1 с).
3. **Цена выхода — исполнимая:** для long берётся best **bid**, для short — best **ask** (`ResolveExitPrice`), а не закрытие свечи. Нет стакана — last, нет last — mid.
4. **Параллелизм по символам:** обработка каждой позиции — отдельная задача с single-flight (`_inFlight`), поэтому медленный REST по одной паре не задерживает остальные 11. Принудительный обход раз в `PositionMonitorSweepSeconds=5` с работает даже если WS молчит.
5. **SL/TP:** проверка по тику плюс экстремумы текущей свечи, **только** если свеча началась после входа (`CandleStartedBeforeEntry`) — защита от «мгновенного стопа» сохранена (`EvaluateExits`).
6. **Защита и трейлинг переехали в контур:** `EnsureProtectionAsync` для позиций без OCO (в т.ч. восстановленных из `positions.json`) с троттлингом попыток `ProtectionRetryIntervalSeconds=15`; fail-closed «нет защиты → нет позиции» сохранён. Трейлинг — по-прежнему cancel/replace биржевой связки через executor (`TrailingReplaceMinIntervalSeconds`/`MinStepPercent`), локальный SL двигается только после подтверждённой замены, персист сразу.
7. **Без гонок с циклом анализа:** посимвольный шлюз `PositionMonitor.LockSymbolAsync`. Критические секции короткие (вход+постановка защиты, закрытие); инференс LLM идёт **вне** шлюза. `ClosePositionAsync` берёт шлюз и перепроверяет, что позиция ещё открыта (`PositionManager.GetPositionById`) — двойной MARKET-выход из тик-контура и ИИ-пересмотра исключён.
8. **Цикл анализа разгружен:** `ProcessSymbolAsync` для открытой позиции теперь только спрашивает модель «держать/закрыть»; методы `MonitorPositionAsync` и `EnsureExchangeProtectionAsync` из `TradingEngine` удалены. Сопровождение продолжает работать и на `Pause` (пауза останавливает только входы/анализ).
9. **ATR для трейлинга:** кэш `_atrAbsolute` обновляется на закрытых свечах и при прогреве историей — индикаторы не пересчитываются на каждом тике.
10. **Телеметрия задержки:** `MetricsCollector.RecordPositionCheck` (счётчик, средняя/худшая задержка «тик → проверка»), предупреждение `MONITOR-LAG` при превышении `PositionMonitorMaxLatencyMs=2000` (троттлинг 30 с на символ), `MONITOR-START` при старте контура.
11. **Жизненный цикл:** контур стартует в `StartAsync` до основного цикла, гасится в `StopAsync`/`CleanupAfterFailedStartAsync` раньше отключения WS; зарегистрирован в DI (`App.xaml.cs`).

**Изменённые файлы:**
- **новый:** `AITradingSystem.Services/Trading/PositionMonitor.cs`
- `AITradingSystem.Services/Trading/TradingEngine.cs` (приём тиков, шлюзы входа/закрытия, `ClosePositionCoreAsync`, кэш ATR, старт/остановка контура, удаление `MonitorPositionAsync`/`EnsureExchangeProtectionAsync`)
- `AITradingSystem.Services/Trading/PositionManager.cs` (`GetPositionById`)
- `AITradingSystem.Common/Configuration/TradingConfig.cs` (`PositionMonitorIntervalMs`, `PositionMonitorSweepSeconds`, `PositionMonitorMaxLatencyMs`, `ProtectionRetryIntervalSeconds` + валидация)
- `AITradingSystem.UI/appsettings.json` (те же 4 ключа)
- `AITradingSystem.Services/Monitoring/MetricsCollector.cs` (`RecordPositionCheck`, `PositionChecks`, `AveragePositionCheckLatencyMs`, `MaxPositionCheckLatencyMs`, сводка)
- `AITradingSystem.UI/App.xaml.cs` (регистрация `PositionMonitor` в DI)
- `AITradingSystem.Tests/TradingLogicTests.cs` (5 тестов: исполнимая цена выхода bid/ask, срабатывание по тику, экстремумы свечи после входа, отсутствие тика ≠ выход, валидация новых ключей)

**Критерий приёмки:** сопровождение привязано к тику (kline ~2 с / depth 1 с) и не содержит `await` LLM; худшая задержка измеряется и алертится порогом 2 с. Живой замер задержки не проводился (сборки/запуски запрещены в этом проходе).

**Остаточные ограничения (не входят в P0.2):**
- если процесс мёртв, сопровождение делает только биржевая OCO-связка (P0.1); ~~распознавание её филлов после рестарта — **P0.5**~~ **закрыто проходом 9 (P0.5 ✅)**;
- «протухшие» данные после реконнекта WS входы пока не блокируют — **P1.4**;
- ~~очередь исполнения с приоритетами (закрытие раньше входов)~~ — **закрыто проходом 5 (P0.3)**: сетевые отправки идут через `ExecutionQueue` с приоритетами, durable-журналом и ретраями.

---

### ✅ P0.3 Очередь исполнения с приоритетами
> Очередь исполнения с приоритетами: закрытие/защита раньше входов; идемпотентность через `clientOrderId`.

**Выполнено 24.11.2026: фундамент — проход 4, закрытие пункта — проход 5.** Сетевые отправки ордеров больше не идут напрямую из цикла анализа: они проходят через очередь с приоритетами и ключом идемпотентности.

**Что сделано:**
1. **Новый `ExecutionQueue`** — диспетчер с приоритетами `Protection(0) → Close(1) → Trailing(2) → Entry(3)`, FIFO внутри приоритета. Защита и закрытие обгоняют вход, даже если вход запрошен раньше.
2. **Параллелизм и сериализация:** `ExecutionQueueMaxParallel=2` одновременных отправок, но **по одному символу — не более одной операции в полёте** (нет гонок «вход vs закрытие» на одной паре).
3. **В очереди только сетевая операция**, а не ожидание филла: 60-секундный опрос лимитного входа (`WaitForFillAsync`) выполняется вне очереди и не блокирует закрытие другой позиции.
4. **Идемпотентность по `clientOrderId`:** повтор с тем же ключом либо присоединяется к уже идущей отправке (`IDEMPOTENT-JOIN`), либо получает сохранённый результат (`IDEMPOTENT-REPLAY`, TTL `ExecutionIdempotencyTtlSeconds=600`) — второй ордер не создаётся. Кэшируется только успех: отказ можно повторить тем же id.
5. **`newClientOrderId` в REST:** `PlaceOrderAsync`/`PlaceMarketOrderAsync` принимают `clientOrderId` и шлют его бирже. Ретраи внутри `SendRequestAsync` (5xx, -1000/-1001/-1007, сетевой сбой) переиспользуют тот же id — **закрыта дыра «ретрай POST /order создаёт дубль»**.
6. **Ответ «Duplicate order sent»** (`BinanceApiException.IsDuplicateOrder`) трактуется как «ордер уже принят»: новый метод `GetOrderAsync(symbol, clientOrderId)` (`origClientOrderId`) забирает его состояние вместо повторной отправки.
7. **OCO тоже идемпотентна:** `listClientOrderId` генерируется в `OrderExecutor` (`oco-…`) и передаётся в `PlaceOcoAsync`, он же — ключ очереди; повтор не создаёт вторую пару ног.
8. **Приоритеты расставлены по местам:** постановка/снятие защиты — `Protection`, market-закрытие и отмена ордера — `Close`, cancel/replace трейлинга — `Trailing`, вход (limit/market) — `Entry`.
9. **Отмена вызывающего:** токен stopping-а снимает ещё не отправленную операцию с очереди — ордер не уйдёт на биржу после остановки движка.
10. **Телеметрия:** `MetricsCollector.RecordExecutionWait` / `RecordExecutionQueueDepth` (среднее/худшее ожидание, макс. глубина), предупреждение `QUEUE-WAIT` при ожидании > `ExecutionQueueWarnWaitMs=3000`.

**Изменённые файлы:**
- **новый:** `AITradingSystem.Services/Trading/ExecutionQueue.cs` (`ExecutionPriority` + очередь)
- `AITradingSystem.Services/Trading/OrderExecutor.cs` (очередь во всех отправках, `PlaceOrderIdempotentAsync`, `NewClientOrderId`, генерация `listClientOrderId`, обработка дубля)
- `AITradingSystem.Data/Binance/IBinanceRestClient.cs` (`clientOrderId` в `PlaceOrderAsync`/`PlaceMarketOrderAsync`, перегрузка `GetOrderAsync(symbol, clientOrderId)`)
- `AITradingSystem.Data/Binance/BinanceRestClient.cs` (`newClientOrderId`, `origClientOrderId`, `BinanceApiException.IsDuplicateOrder`)
- `AITradingSystem.Common/Configuration/TradingConfig.cs` (`ExecutionQueueMaxParallel`, `ExecutionIdempotencyTtlSeconds`, `ExecutionQueueWarnWaitMs` + валидация)
- `AITradingSystem.UI/appsettings.json` (те же 3 ключа)
- `AITradingSystem.Services/Monitoring/MetricsCollector.cs` (`RecordExecutionWait`, `RecordExecutionQueueDepth`, метрики в сводке)
- `AITradingSystem.UI/App.xaml.cs` (регистрация `ExecutionQueue` в DI)
- `AITradingSystem.Tests/TradingLogicTests.cs` (3 теста: закрытие обгоняет ранее поставленный вход, повтор по тому же `clientOrderId` не отправляет второй ордер, одна операция на символ в полёте)

**Доведено до ✅ 24.11.2026 (проход 5).** Закрыты три из пяти пунктов остатка; два оставшихся не входят в P0.3 и переданы соседним пунктам.

**Что добавлено в проходе 5:**
1. **Durable-журнал намерений** (`IExecutionJournal` / `JsonExecutionJournal`, файл `data/state/execution_journal.json`): запись `Pending` фиксируется **до** сетевого вызова (write-ahead, атомарно tmp+rename), после ответа — `Confirmed`/`Failed`. Кэш идемпотентности больше не живёт только в памяти.
2. **Восстановление при старте:** `ExecutionQueue.RestoreAsync` вызывается в `TradingEngine.StartAsync` **до** первой торговой операции. Подтверждённые ключи в окне TTL блокируют повтор; неподтверждённые (`Pending`) не вычищаются по TTL и попадают в `UnresolvedIntents` + лог `EXEC-INTENT-UNRESOLVED`.
3. **Сверка с биржей вместо слепой отправки:** `OrderExecutor.ResolveRestoredIntentAsync` (регистрируется через `SetIntentResolver`) забирает ордер по `origClientOrderId`. Нет ордера → ключ снимается (`EXEC-INTENT-CLEARED`), отправка разрешена; есть → берётся его состояние (`EXEC-INTENT-RESOLVED`), второй ордер не шлётся. Сетевая ошибка при сверке не глотается — повтор запрещён (fail-closed). Связку OCO целиком восстановить нельзя (Binance не отдаёт ноги в `openOrderList`), поэтому незавершённая связка снимается и ставится заново.
4. **Детерминированные `clientOrderId`** (`StableClientOrderId`, префикс + 32 hex SHA-256, ≤36 символов) вместо GUID: вход — от `symbol|side|qty|price|signal.Timestamp`, закрытие — от `position.Id|qty`, OCO — от `position.Id|qty|SL|TP`. Ключ одинаков после рестарта, поэтому журнал реально работает; закрытие остатка после частичного филла получает новый ключ (другой объём).
5. **Снятие ключа при отмене:** `ExecutionQueue.ForgetKeyAsync` вызывается после успешного снятия OCO (и при «связки уже нет») — cancel/replace трейлинга и повторная постановка той же защиты не блокируются собственным кэшем.
6. **Ретрай на уровне операции:** `ExecutionRetryMaxAttempts=3`, экспоненциальный backoff `ExecutionRetryBaseDelayMs=300` → потолок `ExecutionRetryMaxDelayMs=5000` с **полным jitter**. Ретраится только транзиент (`BinanceApiException.IsTransient`: 5xx/429/418/−1000/−1001/−1003/−1006/−1007, сетевые/таймаут), отказ по существу (−2010 и т.п.) — нет. Повтор идёт **с тем же `clientOrderId`**, журнал пишет номер попытки.
7. **Backoff не держит символ:** на время ожидания слот символа и общий слот освобождаются, операция возвращается в очередь с прежним FIFO-номером (`NotBeforeUtc`), диспетчер будится таймером. Закрытие по той же паре не стоит за ретраем входа.
8. **Наблюдаемость в UI:** панель «Очередь исполнения (P0.3)» в дашборде — текущая/максимальная глубина, ожидание avg/max, ретраи, склеенные запросы, пропущенные повторы, восстановленные ключи; жёлтый алерт при превышении `ExecutionQueueWarnWaitMs` и при наличии неподтверждённых намерений.

**Изменённые файлы (проход 5):**
- **новые:** `AITradingSystem.Core/Models/Trading/ExecutionIntent.cs` (`ExecutionIntentStatus` + запись намерения), `AITradingSystem.Data/Storage/IExecutionJournal.cs`, `AITradingSystem.Data/Storage/JsonExecutionJournal.cs`
- `AITradingSystem.Services/Trading/ExecutionQueue.cs` (`RestoredExecution`, журнал в ctor, `RestoreAsync`/`SetIntentResolver`/`ForgetKeyAsync`, ретрай с backoff/jitter и освобождением слота, `UnresolvedIntents`, счётчики)
- `AITradingSystem.Services/Trading/OrderExecutor.cs` (`StableClientOrderId` вместо GUID, `ResolveRestoredIntentAsync`, снятие ключа при cancel OCO; `NewClientOrderId` удалён как неиспользуемый)
- `AITradingSystem.Services/Trading/TradingEngine.cs` (ctor + `ExecutionQueue`, `RestoreAsync` и алерт по неподтверждённым намерениям в `StartAsync`)
- `AITradingSystem.Data/Binance/BinanceRestClient.cs` (`BinanceApiException.IsTransient`)
- `AITradingSystem.Common/Configuration/TradingConfig.cs` (`ExecutionRetryMaxAttempts`, `ExecutionRetryBaseDelayMs`, `ExecutionRetryMaxDelayMs` + валидация, в т.ч. потолок ≥ базы)
- `AITradingSystem.UI/appsettings.json` (те же 3 ключа)
- `AITradingSystem.Services/Monitoring/MetricsCollector.cs` (`ExecutionQueueDepth`, `ExecutionRetries`, `RecordExecutionRetry`, сводка)
- `AITradingSystem.UI/App.xaml.cs` (DI: `IExecutionJournal` → `JsonExecutionJournal` в `data/state`)
- `AITradingSystem.UI/ViewModels/DashboardViewModel.cs` (ctor + `ExecutionQueue`/`TradingConfig`, `ExecutionQueueText`, `ExecutionQueueAlertText`)
- `AITradingSystem.UI/Views/DashboardView.xaml` (панель метрик очереди)
- `AITradingSystem.Tests/TradingLogicTests.cs` (7 тестов: подтверждённый ключ переживает рестарт и блокирует второй ордер; неподтверждённое намерение сверяется с биржей — «нет ордера → отправка», «есть ордер → повтора нет»; ретрай транзиента тем же ключом; лимит попыток; отказ по существу не ретраится; валидация новых ключей)

**Критерий приёмки:** выполнен — «закрытие/защита раньше входов» и «идемпотентность через `clientOrderId`» реализованы, идемпотентность переживает рестарт, покрыто тестами. Сквозная проверка на живом окружении не проводилась (сборки/запуски запрещены).

**Остаток вне P0.3 (передан по назначению):**
- **бюджет весов `X-MBX-USED-WEIGHT`** — **P1.6** (очередь ограничивает только параллелизм);
- **приоритетное вытеснение в полёте** (cancel уже отправленного входа при пробитии риска) — решается вместе с **P0.6**;
- **подхват сиротских позиций/ордеров и филлов, случившихся пока процесс был мёртв** — ~~**P0.5**: журнал даёт список `UnresolvedIntents`, но полной реконсиляции по user-data stream не заменяет~~ **закрыто проходом 9 (P0.5 ✅)**: реконсиляция применяет филлы по кумулятиву с дедуп-леджером `Position.AppliedExchangeFills` — повторный MARKET по уже закрытой биржей позиции не шлётся и для нового ключа.

---

### ✅ P0.4 Персист DrawdownTracker
> Персист `DrawdownTracker` (пик, дневной старт) в `JsonStateRepository`, сброс по UTC биржи, восстановление при старте.

**Выполнено 24.11.2026 (проход 6).** Дневной убыток и пик больше не обнуляются рестартом: состояние трекера целиком живёт в `data/state/risk_state.json`, граница торгового дня считается по часам биржи.

**Что сделано:**
1. **Снимок состояния:** `DrawdownState` (`DrawdownTracker.cs`) — пик, дневной старт, дата дня (`DayStartUtc`), максимальная просадка, текущий баланс, время сохранения. Методы `CaptureState()` / `RestoreState()`.
2. **Персист:** `IStateRepository.SaveRiskStateAsync` / `LoadRiskStateAsync`; `JsonStateRepository` пишет `risk_state.json` атомарно (tmp + rename, как журнал намерений P0.3). Legacy `SavePeakBalanceAsync`/`LoadPeakBalanceAsync` сохранены; если `risk_state.json` нет, а `peak_balance.json` есть — миграция «только пик» (`CurrentBalance=0`), дневной старт берётся из первого фактического баланса.
3. **Часы биржи:** `DrawdownTracker.SetExchangeClock(Func<DateTime>)` — смена дня считается по времени биржи, не `DateTime.UtcNow.Date` процесса. `TradingEngine.ConfigureExchangeClockAsync` в `StartAsync` оценивает смещение через `GET /api/v3/time` (полудлина RTT, как в синхронизации подписи); при недоступности `/time` — предупреждение и локальные UTC-часы. Опциональный параметр `exchangeUtcNow` добавлен в конструкторы `DrawdownTracker`/`RiskManager` (старые вызовы совместимы).
4. **Восстановление при старте:** `StartAsync` — сначала часы биржи, затем `LoadRiskStateAsync` + `RestoreState` **до** первого `UpdateBalance`, лог `RISK-STATE-RESTORED`. Если сохранённый день уже прошёл по часам биржи — дневной PnL обнуляется, пик/просадка остаются (ролловер внутри `RestoreState` → `UpdateBalance`).
5. **Персист после каждого изменения баланса:** helper `UpdateRiskBalanceAsync` (update + save) заменил прямые `_riskManager.UpdateBalance` в комиссии входа (paper) и в обновлении баланса после закрытия (paper и live); состояние фиксируется и сразу после стартового баланса.
6. **Paper-баланс переживает рестарт:** при восстановлении виртуальный баланс берётся из `risk_state.json`, а не сбрасывается к `PaperTradingInitialBalance` (иначе дневной старт восстанавливался бы несогласованно). Первый запуск — по-прежнему из конфига.

**Изменённые файлы:**
- `AITradingSystem.Core/RiskManagement/DrawdownTracker.cs` (`DrawdownState`, `SetExchangeClock`, `CaptureState`, `RestoreState`, день по часам биржи)
- `AITradingSystem.Core/RiskManagement/RiskManager.cs` (опциональный `exchangeUtcNow` в ctor)
- `AITradingSystem.Data/Storage/IStateRepository.cs` (`SaveRiskStateAsync`, `LoadRiskStateAsync`)
- `AITradingSystem.Data/Storage/JsonStateRepository.cs` (`risk_state.json`, атомарная запись, миграция с legacy пика)
- `AITradingSystem.Services/Trading/TradingEngine.cs` (ctor + `IStateRepository`, `ConfigureExchangeClockAsync`/`PersistRiskStateAsync`/`UpdateRiskBalanceAsync`, восстановление в `StartAsync`, персист на обоих путях обновления баланса)
- `AITradingSystem.Tests/TradingLogicTests.cs` (6 тестов: дневной лимит переживает рестарт; пик переживает рестарт; ролловер по часам биржи, а не локальным; протухший день сбрасывает дневной PnL, но не пик; roundtrip репозитория; миграция с legacy `peak_balance.json`)

**Критерий приёмки:** выполнен на уровне механики — после рестарта дневной убыток/пик восстанавливаются, новый день начинается по UTC биржи. Живой прогон «убить процесс» не проводился (сборки/запуски запрещены в этом проходе).

**Остаточные ограничения (не входят в P0.4):**
- пробитие лимита по-прежнему только запрещает новые входы — авто-закрытие позиций и паническая кнопка — **P0.6**;
- в live баланс между сделками не опрашивается — дневной PnL фиксируется по событиям сделок (как и раньше); после применённого биржевого филла баланс теперь запрашивается (P0.5, проход 9), непрерывная переоценка equity — **P1.8**;
- смещение часов биржи оценивается один раз при старте; мониторинг дрейфа — **P1.8**.

---

### ✅ P0.5 Реконсиляция + user-data stream
> Реконсиляция + user-data stream (`listenKey`/`executionReport`) вместо polling; подхват сиротских позиций/ордеров; учёт частичных филлов.

**Выполнено 24.11.2026: фундамент — проход 7, UI/DI — проход 8, завершение — проход 9 (проверка завершённости + учёт в трекере).** Все четыре пункта остатка закрыты в коде; проход 9 проверил их наличие и согласованность и внёс запись в SECUPD.md (код в проходе 9 не менялся).

**Что сделано (поверх фундамента проходов 7–8):**
1. **Применение филлов без повторного MARKET:** `TradingEngine.ApplyExchangeFillAsync` применяет биржевой филл (защитная нога / close из журнала) к позиции, истории и балансу под посимвольным шлюзом. Дедуп — durable-леджер `Position.AppliedExchangeFills` (кумулятив по `clientOrderId`, персистится в `positions.json`): повторный `executionReport`, устаревший кумулятив и стартовая реконсиляция не закрывают объём дважды. Частичный филл защитной ноги уменьшает позицию (`ReduceQuantity`), старая OCO снимается — контур сопровождения ставит новую на остаток. После применения — обновление баланса с биржи и `UpdateRiskBalanceAsync` (kill-switch P0.6 взводится по факту).
2. **Подхват сиротских позиций/ордеров:** `ReconciliationService.RemediateAsync` — (а) пропавшая OCO: ноги запрашиваются по `origClientOrderId`, исполненный объём применяется; если филлов нет — локальная защита сбрасывается, тик-контур переставит OCO или fail-closed закроет остаток; (б) журнал намерений P0.3: entry с филлом при отсутствии позиции → `AdoptOrphanPositionAsync` (SL/TP от ATR, постановка OCO сразу, fail-closed «нет защиты → нет позиции»), close с филлом → применение к позиции; (в) открытые ордера: сиротский entry с исполненным объёмом подхватывается даже без записи в журнале; сиротские ордера/OCO бота (префиксы `mkt-/ent-/cls-/oco-/sl-/tp-`) снимаются через очередь с приоритетами Close/Protection; **внешние ордера не трогаются**. Переключатели: `ReconciliationAdoptOrphanPositions`, `ReconciliationCancelOrphanBotOrders`.
3. **Живучесть listenKey:** `KeepAliveLoopAsync` (PUT каждые `UserDataKeepAliveMinutes`), `HealthLoopAsync` (проверка socket каждые `UserDataStreamHealthCheckSeconds=15`), при сбое продления/обрыве — `RecreateListenKeyAsync`: переподключение user-data WS, метрика `ListenKeyRecreations` и **полная реконсиляция после пересоздания**. Фоновые ошибки переподключения user-data WS не глотаются молча — health-check видит `IsUserDataStreamConnected=false` и поднимает контур заново.
4. **Частичные филлы из stream вместо polling:** `OrderExecutor.WaitForFillAsync` при включённом и подключённом user-data stream ждёт `executionReport` (`_latestReports` latest-wins + `_fillWaiters` TCS по ключам `clientOrderId`/`id:<orderId>`), кумулятив ордера обновляется из report; REST-polling остаётся только fallback (stream выключен/не подключён). Финальное состояние и комиссии забираются **одним** GET, не циклом опроса. Неисполненный остаток по таймауту отменяется, фактический филл добирается после отмены.
5. **Наблюдаемость:** метрики `ReconciliationFillsApplied`, `OrphanPositionsAdopted`, `OrphanOrdersCanceled`, `ListenKeyRecreations` + сводка; панель дашборда показывает их вместе с отчётом реконсиляции. Логи: `EXCHANGE-FILL-APPLIED`, `PROTECTION-FILLED-APPLIED`, `RECON-ADOPT`, `RECON-CANCEL`, `USER-DATA-RECREATE`.

**Изменённые файлы фундамента (проход 7):** новые `AITradingSystem.Core/Models/Trading/ExecutionReport.cs`, `AITradingSystem.Services/Trading/ReconciliationService.cs`; изменены `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `AITradingSystem.Data/Binance/BinanceModels.cs`, `BinanceRestClient.cs`, `IBinanceRestClient.cs`, `BinanceWebSocketClient.cs`, `IBinanceWebSocketClient.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.UI/ViewModels/TradingViewModel.cs`, `AITradingSystem.UI/Views/TradingView.xaml`, `AITradingSystem.UI/ViewModels/SettingsViewModel.cs`, `AITradingSystem.Common/Configuration/BinanceConfig.cs`.
**Изменённые файлы прохода 8:** `AITradingSystem.UI/App.xaml.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.UI/ViewModels/DashboardViewModel.cs`, `AITradingSystem.UI/Views/DashboardView.xaml`, `AITradingSystem.Tests/TradingLogicTests.cs`.
**Файлы завершения (проход 9 — учтены в трекере, код уже был в дереве):** `AITradingSystem.Services/Trading/ReconciliationService.cs` (remediate/adopt/listenKey-recreate/применение филлов), `AITradingSystem.Services/Trading/TradingEngine.cs` (`ApplyExchangeFillAsync`, `AdoptOrphanPositionAsync`, `Configure` колбэков), `AITradingSystem.Services/Trading/OrderExecutor.cs` (stream-first `WaitForFillAsync`, `_latestReports`/`_fillWaiters`, `IDisposable`), `AITradingSystem.Core/Models/Trading/Position.cs` (`AppliedExchangeFills`, `GetUnappliedExchangeFill`, `RecordExchangeFill`, `ReduceQuantity`), `AITradingSystem.Core/Models/Trading/Order.cs` (`FilledQuoteQuantity`, `Commission`, `AverageFillPrice`, `UpdatedAt`), `AITradingSystem.Common/Configuration/TradingConfig.cs` + `AITradingSystem.UI/appsettings.json` (`UserDataStreamHealthCheckSeconds`, `ReconciliationAdoptOrphanPositions`, `ReconciliationCancelOrphanBotOrders`), `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.UI/ViewModels/DashboardViewModel.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs` (`MapToOrder`: комиссии/quote из fills), `AITradingSystem.Tests/TradingLogicTests.cs` (3 теста: дедуп-леджер по кумулятиву, `ToReport` берёт кумулятив и среднюю цену филла, валидация health-check).

**Критерий приёмки:** выполнен на уровне механики — филлы биржи применяются к позиции/истории/балансу без повторного MARKET и без двойного учёта после рестарта; сироты подхватываются/снимаются; listenKey пересоздаётся с реконсиляцией; ожидание филлов идёт через stream. Живой прогон не проводился (сборки/запуски запрещены).

**Остаточные ограничения (не входят в P0.5):**
- `outboundAccountPosition`/`balanceUpdate` из user-data stream не обрабатываются — баланс обновляется REST-запросом после применённого филла; непрерывная переоценка equity — **P1.8**;
- реконсиляция выполняется при старте и после пересоздания listenKey; периодической фоновой реконсиляции по таймеру нет (при живом stream события приходят сами);
- бюджет весов REST-запросов реконсиляции — **P1.6**.

---

### ✅ P0.6 Kill-switch
> Kill-switch: авто-закрытие всех позиций при пробитии лимита просадки/дня (сейчас лимиты только запрещают новые входы) + паническая кнопка в UI.

**Выполнено 24.11.2026: фундамент — проход 7, UI-хвост — проход 8.** `RiskManager.ShouldEngageKillSwitch` даёт чистый предикат по лимитам просадки/дня и флагу `KillSwitchAutoCloseOnRiskBreach`. `TradingEngine.UpdateRiskBalanceAsync` после каждого обновления баланса взводит kill-switch: блокирует новые входы, ставит Pause и вызывает `CloseAllPositionsAsync` через штатный пайплайн (снятие OCO → market → история → баланс → события). Ручная паника в UI двухшаговая (MessageBox Yes/No) и вызывает `EngageKillSwitchAsync("ManualPanic")`.

**Доведено проходом 8:** кнопка «Сброс kill-switch» с подтверждением вызывает `ResetKillSwitch`; баннер оболочки показывает состояние kill-switch; дашборд выводит счётчик активаций; добавлен тест предиката `ShouldEngageKillSwitch` (не запускался).

**Изменённые файлы:** `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.UI/ViewModels/TradingViewModel.cs`, `AITradingSystem.UI/Views/TradingView.xaml`, `AITradingSystem.UI/ViewModels/MainViewModel.cs`, `AITradingSystem.UI/ViewModels/DashboardViewModel.cs`, `AITradingSystem.UI/Views/DashboardView.xaml`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Tests/TradingLogicTests.cs`.

**Критерий приёмки:** выполнен на уровне механики — пробитие лимита после обновления баланса закрывает все позиции и блокирует входы; паническая кнопка и явный сброс есть в UI. Живой прогон не проводился (сборки/запуски запрещены). Непрерывная переоценка equity между сделками относится к P0.5/P1.8, а не к критерию P0.6.

---

### ✅ P0.7 Защита от случайного Live
> Защита от случайного Live: двухшаговое подтверждение, отдельные ключи/конфиги, несмываемый индикатор «REAL MONEY».

**Выполнено 24.11.2026: фундамент — проход 7, UI-хвост — проход 8.** Переход в Live требует второго шага: выбор Live показывает блок подтверждения, сохранение заблокировано до ввода точной фразы `LIVE` и команды «Подтвердить Live». `BinanceConfig` поддерживает отдельные `EncryptedLiveApiKey`/`EncryptedLiveApiSecret`; `BinanceRestClient` в Live использует их через `EffectiveEncrypted*`, общие ключи остаются для Demo/Testnet. В оболочке постоянный баннер `REAL MONEY — LIVE` с красным фоном обновляется таймером независимо от статуса бота.

**Доведено проходом 8:** добавлены отсутствовавшие команда `ConfirmLive`, сброс подтверждения при смене окружения, поля ввода отдельных Live-ключей (Secret через PasswordBox), шифрование через `ApiKeyEncryptor` при сохранении, ключи `EncryptedLive*` в `appsettings.json`, привязки фона/цвета баннера в `MainWindow.xaml`; добавлен тест выбора Live-ключей (не запускался).

**Изменённые файлы:** `AITradingSystem.Common/Configuration/BinanceConfig.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.UI/ViewModels/SettingsViewModel.cs`, `AITradingSystem.UI/Views/SettingsView.xaml`, `AITradingSystem.UI/Views/SettingsView.xaml.cs`, `AITradingSystem.UI/ViewModels/MainViewModel.cs`, `AITradingSystem.UI/MainWindow.xaml`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Tests/TradingLogicTests.cs`.

**Критерий приёмки:** выполнен на уровне механики — одно кликовое переключение в Live не сохраняется, отдельные Live-ключи поддержаны и вводятся из UI, индикатор REAL MONEY постоянный. Живой прогон UI не проводился (сборки/запуски запрещены).

---

## P1 — корректность денег и данных

### ⬜ P1.1 Slippage-модель в paper-режиме
> Slippage-модель в paper-режиме (филл по стакану, комиссии обеих ног).

**Сейчас:** paper-филл считается по цене сигнала с комиссией (`OrderExecutor.cs:119–122`, `:365`), стакан в симуляции не участвует; комиссии обеих ног в модель сделки не заложены. `grep Slippage` — 0 совпадений.

**Файлы:** `AITradingSystem.Services/Trading/OrderExecutor.cs` (`SimulatePaperOrder`, `ClosePositionAsync:175`), `AITradingSystem.Core/Models/MarketData/OrderBook.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`.

### ⬜ P1.2 Комиссии в R/R и безубытке
> Комиссии в R/R и безубытке; ограничение проскальзывания на market-выходе.

**Сейчас:** `RiskManager` считает R/R по чистым ценам (`RiskManager.cs:42`, `:86–89`), комиссия не входит; выход — `PlaceMarketOrderAsync` без ограничения проскальзывания (`OrderExecutor.cs:200`).

**Файлы:** `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`.

### 🟡 P1.3 Округления tick/step/minNotional для всех ног
> Округления tick/step/minNotional для всех ног включая OCO; dust; аудит частичного филла после отмены остатка.

**Есть:** фильтры парсятся корректно (`BinanceModels.cs:222–255`), округление и проверка `minQty`/`minNotional` для **входной** ноги (`OrderExecutor.cs:84–116`), отмена остатка с добором фактического объёма (`:258–277`).
**Добавлено в проходе 2 (вместе с P0.1):** округления tick/step и проверка `minQty`/`minNotional` для **стоп/тейк-ног** — `ProtectiveOrderPricing.TryBuild` (объём к stepSize, обе цены к tickSize в сторону исполнения, minNotional по худшей ноге, правило above/below относительно текущей цены).
**Нет:** обработки dust и аудита расхождения «отменённый остаток vs фактический филл»; объём защиты может быть меньше объёма позиции после округления к stepSize — этот «хвост» пока не логируется отдельной метрикой.

**Файлы:** `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Core/Models/Trading/ProtectiveOrderPricing.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs` (`SymbolPrecision`, `:58–59`, `:720–730`).

### ⬜ P1.4 Целостность данных после реконнекта WS
> Целостность данных после реконнекта WS: REST-дозагрузка свечей, детект разрывов, повторный прогрев; запрет входов на протухших данных.

**Сейчас:** есть только экспоненциальный reconnect (`BinanceWebSocketClient.cs:128–192`). Прогрев свечами делается один раз при старте (`TradingEngine.cs:142`); после переподключения дыры в истории не детектируются и не дозагружаются, «протухшие» данные входы не блокируют.

**Файлы:** `AITradingSystem.Data/Binance/BinanceWebSocketClient.cs`, `AITradingSystem.Services/Analysis/MarketAnalyzer.cs`, `AITradingSystem.Core/Indicators/IndicatorCalculator.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`.

### ⬜ P1.5 Фильтр ликвидности
> Фильтр ликвидности: спред/глубина/объём перед входом (BTTC/STRAX/FLR); метрика post-only-отказов.

**Сейчас:** широкий спред только **логируется** (`TradingEngine.cs`, `OnOrderBookReceived`, порог 0.5%), вход не блокирует. Признак post-only-отказа есть (`BinanceRestClient.cs:602`, `IsPostOnlyRejection`), но в метрики не агрегируется.

**Файлы:** `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `symbols.json`.

### 🟡 P1.6 Обработка 429/-1003 и бюджет весов
> Обработка 429/-1003 c `Retry-After`, бюджет весов запросов.

**Есть:** чтение `Retry-After` (`BinanceRestClient.cs:457`) и признание `-1003` ретраебельной ошибкой (`:472–473`).
**Нет:** явной ветки HTTP 429, учёта `X-MBX-USED-WEIGHT`/бюджета весов и планировщика, который притормаживает polling при приближении к лимиту.

**Файлы:** `AITradingSystem.Data/Binance/BinanceRestClient.cs`, новый `AITradingSystem.Data/Binance/RequestWeightBudget.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`.

### ⬜ P1.7 Портфельный риск
> Портфельный риск: кап суммарной экспозиции и корреляции (12 альтов ≈ ставка на BTC), дневной лимит на символ, пауза после серии убытков.

**Сейчас:** есть только `MaxOpenPositions = 3` и лимит на пару из `symbols.json` (`TradingConfig.cs`, `SymbolPositionLimits`). Экспозиция/корреляция/серия убытков не считаются (`grep Correlation/Exposure` — 0).

**Файлы:** `AITradingSystem.Core/RiskManagement/RiskManager.cs`, новый `PortfolioRiskManager.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Data/Storage/JsonTradeHistoryRepository.cs`.

### ⬜ P1.8 Мониторинг дрейфа часов
> Мониторинг дрейфа часов с алертом.

**Сейчас:** синхронизация времени есть (`BinanceRestClient.cs:317–340`, `_timeSyncLock`), но величина дрейфа не измеряется/не алертится; флаг закрытия свечи частично подстрахован вручную (`BinanceWebSocketClient.cs:279–281`).

**Файлы:** `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `TelegramAlertService.cs`.

---

## P2 — 🆕 сигнал и HOLD: убрать тройную осторожность

### ✅ P2.1 Диагностика по логам CALIBRATE/Rejected
> 🆕 Диагностика по логам CALIBRATE/Rejected: посчитать, где умирают сигналы — модель сама HOLD / BUY режется порогом / post-only не налился. Лечить причину, а не всё сразу.

**Выполнено 24.11.2026** по логу `trades-20261124.txt` (29 решений, 11 символов, 02:14–02:38).
**Артефакт:** [`docs/signal-funnel-20261124.md`](docs/signal-funnel-20261124.md) (новый файл). Исходный лог: `uploads/trades-20261124.txt` (вне репозитория).
**Изменённые файлы кода:** нет — пункт аналитический.

**Вывод (куда лечить):** все 29 сигналов умерли **на выходе модели**, а не на пороге и не на исполнении: `model_conf` avg **0.157**, median **0.10**, 16/29 залипли на нижней отсечке 0.10; `engine_prior` max **0.42**; `final` max **0.35** при пороге 0.55. Ни одного `Rejected`/ордера в логе нет — до исполнения дело не доходит.
Две причины, обе подтверждаются кодом:
1. **Двойной штраф** (P2.2): 28/29 обоснований HOLD ссылаются на слабый объём, 29/29 — на «конфликт» индикаторов, за которые prior уже умножен на ×0.8/×0.6.
2. **🆕 Баг данных, найденный при диагностике:** `volume_ratio` считается по **незакрытой** свече. `OnKlineReceived` кладёт в кэш каждый тик (`TradingEngine.cs:1028–1033`), снапшот берёт `candle.Volume` (`NormalizedIndicatorSnapshot.cs:109`) и делит на SMA20 закрытых свечей (`IndicatorCalculator.cs:44–48`). Отсюда `volume_ratio` 0.005–0.49 одновременно у **всех** 12 пар, включая BTC/ETH, и вечный штраф ×0.8 + рубрика −0.1…−0.2. Это надо чинить **до** перенастройки весов/порогов, иначе подбор пойдёт по испорченным данным.

**✅ Исправление `volume_ratio` выполнено 24.11.2026 (проход 11, шаг №1 очереди).** `IndicatorCalculator` фиксирует `LastClosedVolume` при обновлении закрытой свечой и предоставляет `VolumeRatio = LastClosedVolume / VolumeSma20`. `NormalizedIndicatorSnapshot` использует это значение вместо объёма переданной текущей свечи. Текущая WS-свеча по-прежнему обновляет цену/PnL, но её неполный объём больше не попадает в числитель отношения. Знаменатель сохраняет прежнее определение — SMA20 закрытых свечей, включая последнюю закрытую. При отсутствии данных и после `Reset()` отношение равно нулю. Двойной штраф в рубрике и веса/пороги в этом шаге не менялись — это следующие пункты очереди.

**Изменённые файлы исправления:** `AITradingSystem.Core/Indicators/IndicatorCalculator.cs`, `AITradingSystem.Core/Indicators/NormalizedIndicatorSnapshot.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs` (контракт кэша текущей свечи), `AITradingSystem.Tests/IndicatorTests.cs` (3 теста: частичный тик не меняет отношение, скользящее окно закрытых объёмов, очистка при сбросе). Тесты добавлены, но не запускались; сборки/компиляции не выполнялись.

---

### ⬜ P2.2 Убрать двойной штраф в промпте
> 🆕 Убрать двойной штраф в промпте (`PromptBuilder`): рубрика вычитает 0.1–0.2 за слабые ADX/объём, за которые prior уже умножен на 0.6–0.8. Модель должна давать независимую оценку (новости, структура рынка), а не пересчитывать prior.

**Сейчас:** рубрика literally велит стартовать с prior и вычитать за те же факторы: `PromptBuilder.cs:62` (start from `engine_prior_confidence`), `:64` (subtract 0.10–0.20 за conflicts / `adx_raw < 20` / `volume_ratio < 0.6` / BB), `:68` (пример «mixed → 0.30»). Штрафы движка: `SignalCalibrator.cs:120–160`.

**Файлы:** `AITradingSystem.Services/AI/PromptBuilder.cs`, `AITradingSystem.Services/Analysis/SignalCalibrator.cs` (что отдаём модели как факт, а не как оценку).

### ⬜ P2.3 Политика уверенности 0.7 / 0.3
> 🆕 Политика уверенности (`ConfidencePolicy`): уйти от Blend 50/50 — веса 0.7/0.3.

**Сейчас:** `final = 0.5m * modelConf + 0.5m * prior` (`SignalCalibrator.cs:264`), политика `Blend` в `appsettings.json:89`.
**Замечание из диагностики:** на текущем логе смена весов **не даёт ни одного входа** (при 0.7/0.3 максимум `final` = 0.42 против порога 0.55) — пункт имеет смысл только после P2.2 и фикса `volume_ratio`.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Common/Configuration/AIConfig.cs`, `AITradingSystem.UI/appsettings.json`.

### ⬜ P2.4 Порог MinConfidence из данных
> 🆕 Порог `MinConfidence` из данных: 0.55 сейчас взято с потолка; подобрать по expectancy после издержек на истории.

**Сейчас:** `MinConfidence = 0.55` — дефолт в `CalibrationContext` (`SignalCalibrator.cs:50`) и в `appsettings.json:81`; история сделок для подбора не используется.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Data/Storage/JsonTradeHistoryRepository.cs`, новый инструмент подбора (`tools/`), `AITradingSystem.UI/appsettings.json`.

### 🟡 P2.5 Расширить детект «дегенерата»
> 🆕 Расширить детект «дегенерата» (`SignalCalibrator`): пересмотр HOLD→вход при любом HOLD с сильным согласованным prior, а не только conf=0.45±0.02.

**Есть:** детект узкого окна `|modelConf − 0.45| ≤ 0.02` (`SignalCalibrator.cs:238–239`) и пересмотр `HOLD → вход` при `final >= MinConfidence` (`:281–293`).
**Нет:** срабатывания на прочих HOLD. В логе окно поймало ровно 1 случай из 29 (BNB, `source=Degenerate→Prior`), остальные 28 — `Blend`; при этом `prior >= 0.55` не было ни разу, так что пересмотр не мог сработать в принципе.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Tests/TradingLogicTests.cs` (кейсы на новый детект).

### ⬜ P2.6 Валидация весов скоринга
> 🆕 Валидация весов скоринга (EMA 0.30, Supertrend 0.20, штрафы ×0.6/0.8…): подтвердить/подогнать на истории; reliability diagram — уверенность должна соответствовать реальной частоте успеха.

**Сейчас:** веса зашиты константами (`SignalCalibrator.cs:78–84`: EMA 0.30 / Supertrend 0.20 / EMA-pos 0.15 / RSI 0.15 / MACD 0.10 / Stoch 0.05 / OBV 0.05), prior = `0.2 + 0.7·|score|` (`:168`). В логе `ema_align = 0` в 28/30 случаев → крупнейший вес не contributes, |score| ≤ 0.32 и prior структурно не превышает 0.42 < 0.55. Бэктеста/калибровочной кривой в решении нет.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Core/Indicators/NormalizedIndicatorSnapshot.cs:70–71` (`ema_align`), новый бэктест/отчёт (`tools/`), `AITradingSystem.Tests/`.

---

## Порядок работ (очередь от лёгких к тяжёлым; обновлена проходом 11)

**Принцип:** сортировка по объёму и связности правок, но жёсткие зависимости важнее размера. P0 закрыт полностью (7/7). Фикс `volume_ratio` выполнен проходом 11. Осталось **13 рабочих шагов**: 8 пунктов P1 + 5 пунктов P2. Размеры ориентировочные: **XS** — точечная правка; **S** — локальная правка/тесты; **M** — несколько связанных файлов; **L** — сквозной контур/подсистема; **XL** — исследование + инструменты + калибровка.

Диагностика P2.1 остаётся источником зависимостей: сначала фикс `volume_ratio`, затем P2.2, затем P2.3/P2.5, и только потом P2.4/P2.6. Подбор порога и весов не делается на испорченных данных и без учёта издержек.

| № | Шаг | Размер | Почему здесь / зависимости | Основные файлы |
|---|---|---|---|---|
| 1 | **✅ Фикс `volume_ratio` — выполнен, проход 11** | S | Объём для отношения берётся из последней закрытой свечи; блокировка для последующей калибровки снята. Изменённые файлы перечислены в P2.1 и журнале прохода 11. | `TradingEngine.cs`, `NormalizedIndicatorSnapshot.cs`, `IndicatorCalculator.cs`, `IndicatorTests.cs` |
| 2 | **P1.8 Мониторинг дрейфа часов** | S | Аддитивные метрики/алерт поверх уже существующей синхронизации времени; мало влияния на торговую логику. | `BinanceRestClient.cs`, `MetricsCollector.cs`, `TelegramAlertService.cs`, тесты |
| 3 | **P2.2 Убрать двойной штраф в промпте** | S | Локальная правка рубрики/фактов, но после фикса данных; модель должна давать независимую оценку, а не пересчитывать prior. | `PromptBuilder.cs`, `SignalCalibrator.cs`, тесты |
| 4 | **P2.3 Политика уверенности 0.7/0.3** | XS | Очень маленькая правка весов/конфига, но по зависимости идёт после P2.2. | `SignalCalibrator.cs`, `AIConfig.cs`, `appsettings.json`, тесты |
| 5 | **P2.5 Расширить детект «дегенерата»** | S–M | Логика HOLD→вход при сильном согласованном prior + тесты; после P2.2/P2.3, чтобы не усиливать старый двойной штраф. | `SignalCalibrator.cs`, тесты |
| 6 | **P1.5 Фильтр ликвидности** | M | Фильтр перед входом (спред/глубина/объём) + метрика post-only-отказов; несколько файлов, но контур понятный. | `TradingEngine.cs`, `OrderExecutor.cs`, `MetricsCollector.cs`, `TradingConfig.cs`, `symbols.json` |
| 7 | **P1.6 429/-1003 и бюджет весов** | M | Новый бюджет весов, чтение заголовков, притормаживание polling; конкуренция с очередью исполнения требует аккуратности. | `BinanceRestClient.cs`, новый `RequestWeightBudget.cs`, `MetricsCollector.cs`, конфиг/тесты |
| 8 | **P1.2 Комиссии в R/R и безубытке** | M | Денежная математика + ограничение проскальзывания на market-выходе; влияет на допуск сделки и историю. | `RiskManager.cs`, `OrderExecutor.cs`, `BinanceRestClient.cs`, конфиг/тесты |
| 9 | **P1.1 Slippage-модель в paper** | M | Филл по стакану и комиссии обеих ног в симуляции; нужно согласовать с реальным исполнением и историей. | `OrderExecutor.cs`, `OrderBook.cs`, `TradingConfig.cs`, тесты |
| 10 | **P1.3 Dust и аудит остатка после отмены** | M–L | Краевые случаи частичных филлов, отмены остатка, dust и расхождения защиты; много мелких проверок в исполнении. | `OrderExecutor.cs`, `ProtectiveOrderPricing.cs`, `BinanceRestClient.cs`, `TradingEngine.cs`, метрики/тесты |
| 11 | **P1.4 Целостность данных после реконнекта WS** | L | Сквозной контур: REST-дозагрузка свечей, детект разрывов, повторный прогрев, запрет входов на протухших данных. | `BinanceWebSocketClient.cs`, `MarketAnalyzer.cs`, `IndicatorCalculator.cs`, `TradingEngine.cs`, тесты |
| 12 | **P2.4 Порог MinConfidence из данных** | L | Подбор по expectancy после издержек; требует P1.2/P1.1, историю сделок и новый инструмент. Не делать раньше исправления данных/издержек. | `SignalCalibrator.cs`, `JsonTradeHistoryRepository.cs`, `tools/`, `appsettings.json`, тесты |
| 13 | **P1.7 Портфельный риск** | L–XL | Новая подсистема: суммарная экспозиция, корреляция, дневной лимит на символ, пауза после серии убытков; много связей с риск-менеджером/историей/UI. | новый `PortfolioRiskManager.cs`, `RiskManager.cs`, `TradingConfig.cs`, `appsettings.json`, `JsonTradeHistoryRepository.cs`, тесты |
| 14 | **P2.6 Валидация весов скоринга** | XL | Самый тяжёлый: бэктест/калибровочная кривая, reliability diagram, подтверждение весов на истории; после чистых данных, издержек и порога. | `SignalCalibrator.cs`, `NormalizedIndicatorSnapshot.cs`, `tools/`, тесты |

**Ближайший шаг:** №2 — P1.8, мониторинг дрейфа часов. Ожидается команда заказчика.  
**Правило очереди:** один шаг = один проход = отдельное сообщение заказчику; после шага трекер обновляется сразу, затем ожидается команда на продолжение.

---

## Журнал проходов

### Проход 2 — 24.11.2026 — P0.1 «Биржевые стоп-ордера»

| Действие | Файлы |
|---|---|
| Созданы | `AITradingSystem.Core/Models/Trading/ProtectiveOrderList.cs`, `AITradingSystem.Core/Models/Trading/ProtectiveOrderPricing.cs` |
| Изменены | `AITradingSystem.Core/Models/Trading/Position.cs`, `AITradingSystem.Data/Binance/IBinanceRestClient.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Data/Binance/BinanceModels.cs`, `AITradingSystem.Services/Trading/IOrderExecutor.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Tests/TradingLogicTests.cs` |
| Трекер | `SECUPD.md` (P0.1 → ✅, сводка P0 = 1/7, обновлён P1.3, добавлен журнал) |

Новые ключи конфигурации (`Trading`): `ExchangeProtectionEnabled=true`, `ProtectionLimitSlippage=0.003`, `ClosePositionIfProtectionFails=true`, `TrailingReplaceMinIntervalSeconds=30`, `TrailingReplaceMinStepPercent=0.15`.

Побочные эффекты интерфейса: `IOrderExecutor.UpdateStopLossAsync` теперь `Task<bool>` (было `Task<Order?>`) и реально ходит на биржу; добавлены `EnsureProtectionAsync`/`CancelProtectionAsync`. Внешних вызовов старого метода вне `TradingEngine` не было.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика).

### Проход 3 — 24.11.2026 — P0.2 «Независимый контур мониторинга»

| Действие | Файлы |
|---|---|
| Создан | `AITradingSystem.Services/Trading/PositionMonitor.cs` |
| Изменены | `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Services/Trading/PositionManager.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.UI/App.xaml.cs`, `AITradingSystem.Tests/TradingLogicTests.cs` |
| Трекер | `SECUPD.md` (P0.2 → ✅, сводка P0 = 2/7 и пересчёт P0/P1, обновлён остаток P0.1, порядок работ → P0.6, добавлен журнал) |

Новые ключи конфигурации (`Trading`): `PositionMonitorIntervalMs=500`, `PositionMonitorSweepSeconds=5`, `PositionMonitorMaxLatencyMs=2000`, `ProtectionRetryIntervalSeconds=15`.

Побочные эффекты интерфейса: конструктор `TradingEngine` получил параметр `PositionMonitor` (DI-регистрация добавлена в `App.xaml.cs`); `PositionManager` получил `GetPositionById`; из `TradingEngine` удалены `MonitorPositionAsync`/`EnsureExchangeProtectionAsync` — внешних вызовов у них не было. Поведенческое изменение: на `Pause` сопровождение позиций продолжается (раньше замирало вместе с циклом анализа).

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика).

### Проход 4 — 24.11.2026 — фундамент P0.3 «Очередь исполнения + идемпотентность»

| Действие | Файлы |
|---|---|
| Создан | `AITradingSystem.Services/Trading/ExecutionQueue.cs` |
| Изменены | `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Data/Binance/IBinanceRestClient.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.UI/App.xaml.cs`, `AITradingSystem.Tests/TradingLogicTests.cs` |
| Трекер | `SECUPD.md` (P0.3 → 🟡 с перечнем остатка, сводка P0 = 2 ✅ / 2 🟡 / 3 ⬜, обновлён остаток P0.2 и порядок работ, добавлен журнал) |

Новые ключи конфигурации (`Trading`): `ExecutionQueueMaxParallel=2`, `ExecutionIdempotencyTtlSeconds=600`, `ExecutionQueueWarnWaitMs=3000`.

Побочные эффекты интерфейса: конструктор `OrderExecutor` получил параметр `ExecutionQueue` (DI-регистрация добавлена); в `IBinanceRestClient` у `PlaceOrderAsync`/`PlaceMarketOrderAsync` появился необязательный `clientOrderId` **перед** `ct` — все вызовы (только в `OrderExecutor`) переведены на именованные аргументы; добавлена перегрузка `GetOrderAsync(symbol, string clientOrderId)`.

Найдено попутно: `SendRequestAsync` ретраит POST `/api/v3/order` при 5xx/-1000/-1001/-1007 и сетевых сбоях **без** `newClientOrderId` — это и был источник возможных дублей; закрыто п.5 пункта.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика).

### Проход 5 — 24.11.2026 — P0.3 «Очередь исполнения» доведён до ✅

| Действие | Файлы |
|---|---|
| Созданы | `AITradingSystem.Core/Models/Trading/ExecutionIntent.cs`, `AITradingSystem.Data/Storage/IExecutionJournal.cs`, `AITradingSystem.Data/Storage/JsonExecutionJournal.cs` |
| Изменены | `AITradingSystem.Services/Trading/ExecutionQueue.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.UI/App.xaml.cs`, `AITradingSystem.UI/ViewModels/DashboardViewModel.cs`, `AITradingSystem.UI/Views/DashboardView.xaml`, `AITradingSystem.Tests/TradingLogicTests.cs` |
| Трекер | `SECUPD.md` (P0.3 → ✅, сводка P0 = 3 ✅ / 1 🟡 / 3 ⬜, закрыт остаток P0.2, обновлён порядок работ, добавлен журнал) |

Новые ключи конфигурации (`Trading`): `ExecutionRetryMaxAttempts=3`, `ExecutionRetryBaseDelayMs=300`, `ExecutionRetryMaxDelayMs=5000`. Новый файл состояния: `data/state/execution_journal.json` (≤500 записей, незавершённые не вычищаются по TTL).

Побочные эффекты интерфейса: конструктор `ExecutionQueue` получил необязательный `IExecutionJournal`; конструкторы `TradingEngine` и `DashboardViewModel` получили `ExecutionQueue` (и `TradingConfig` для дашборда) — DI-регистрация добавлена в `App.xaml.cs`. Поведенческое изменение: `clientOrderId` больше не случайный, а детерминированный от параметров операции — повтор того же входа/закрытия/защиты в окне TTL не создаёт второй ордер.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика). P0.4 не начинался — ждёт команды заказчика.

### Проход 6 — 24.11.2026 — P0.4 «Персист DrawdownTracker»

| Действие | Файлы |
|---|---|
| Изменены | `AITradingSystem.Core/RiskManagement/DrawdownTracker.cs`, `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `AITradingSystem.Data/Storage/IStateRepository.cs`, `AITradingSystem.Data/Storage/JsonStateRepository.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Tests/TradingLogicTests.cs` |
| Трекер | `SECUPD.md` (P0.4 → ✅, сводка P0 = 4 ✅ / 0 🟡 / 3 ⬜, обновлены замечания к рабочему дереву и порядок работ, добавлен журнал) |

Новых ключей конфигурации нет. Новый файл состояния: `data/state/risk_state.json` (атомарная запись tmp+rename; при отсутствии — миграция с legacy `peak_balance.json`).

Побочные эффекты интерфейса: конструктор `TradingEngine` получил параметр `IStateRepository` (DI разрешает автоматически — регистрация `JsonStateRepository` уже была); конструкторы `RiskManager`/`DrawdownTracker` получили **опциональный** `exchangeUtcNow` (существующие вызовы, в т.ч. `RiskTests.cs`, совместимы); в `IStateRepository` добавлены `SaveRiskStateAsync`/`LoadRiskStateAsync`. Поведенческое изменение: paper-баланс при рестарте восстанавливается из `risk_state.json` вместо сброса к `PaperTradingInitialBalance`.

Распаковка в этом проходе: zip из репозитория уже содержал правки проходов 2–5; дерево распаковано прямо в корень клона `AITradingSystem/` (корень решения), `README.md` клона перезаписан версией из zip.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика). P0.6 не начинался — ждёт команды заказчика.

### Проход 7 — 24.11.2026 — фундамент P0.5–P0.7 (ранее не записан в SECUPD)

Обнаружен в коде при проверке заказчиком. Код уже содержал: `ReconciliationService` (инвентаризация + listenKey + executionReport), `ExecutionReport`, user-data WS/REST, kill-switch движка и паническую кнопку, двухшаговую блокировку сохранения Live и отдельные Live-ключи в `BinanceConfig`. Не было: DI-регистрации `ReconciliationService`, ключей в `appsettings.json`, команды/UI подтверждения Live, полей Live-ключей, сброса kill-switch, постоянного баннера REAL MONEY и панели реконсиляции.

| Действие | Файлы |
|---|---|
| Созданы | `AITradingSystem.Core/Models/Trading/ExecutionReport.cs`, `AITradingSystem.Services/Trading/ReconciliationService.cs` |
| Изменены | `AITradingSystem.Common/Configuration/TradingConfig.cs`, `BinanceConfig.cs`, `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `AITradingSystem.Data/Binance/BinanceModels.cs`, `BinanceRestClient.cs`, `IBinanceRestClient.cs`, `BinanceWebSocketClient.cs`, `IBinanceWebSocketClient.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.UI/ViewModels/TradingViewModel.cs`, `SettingsViewModel.cs`, `AITradingSystem.UI/Views/TradingView.xaml` |

Не делалось: сборки/компиляции, запуск тестов, коммит.

### Проход 8 — 24.11.2026 — учёт фундамента P0.5–P0.7 + доведение UI/DI

| Действие | Файлы |
|---|---|
| Изменены | `AITradingSystem.UI/App.xaml.cs` (DI `ReconciliationService`), `AITradingSystem.UI/appsettings.json` (`UserDataStreamEnabled`, `UserDataKeepAliveMinutes`, `KillSwitchAutoCloseOnRiskBreach`, `EncryptedLiveApiKey`, `EncryptedLiveApiSecret`), `AITradingSystem.UI/ViewModels/SettingsViewModel.cs` (`ConfirmLive`, сброс подтверждения, ввод/шифрование Live-ключей), `AITradingSystem.UI/Views/SettingsView.xaml` (+ `.xaml.cs`: блок подтверждения Live, поля ключей, PasswordBox), `AITradingSystem.UI/ViewModels/MainViewModel.cs` (постоянный REAL MONEY баннер, статус kill-switch), `AITradingSystem.UI/MainWindow.xaml` (привязки фона/цвета баннера), `AITradingSystem.UI/ViewModels/TradingViewModel.cs` (сброс kill-switch), `AITradingSystem.UI/Views/TradingView.xaml` (кнопка сброса), `AITradingSystem.UI/ViewModels/DashboardViewModel.cs` + `Views/DashboardView.xaml` (панель реконсиляции/user-data/kill-switch), `AITradingSystem.Tests/TradingLogicTests.cs` (4 теста фундамента) |
| Трекер | `SECUPD.md` (зафиксирован проход 7; P0.5 → 🟡 с остатком, P0.6/P0.7 → ✅, сводка P0 = 6 ✅ / 1 🟡 / 0 ⬜, порядок работ → завершение P0.5, добавлены журналы проходов 7–8) |

Новые ключи конфигурации, вынесенные в `appsettings.json`: `Trading:UserDataStreamEnabled=true`, `Trading:UserDataKeepAliveMinutes=30`, `Trading:KillSwitchAutoCloseOnRiskBreach=true`, `Binance:EncryptedLiveApiKey=""`, `Binance:EncryptedLiveApiSecret=""`.

Побочные эффекты интерфейса: `DashboardViewModel` получил параметр `ReconciliationService`; `SettingsViewModel` получил команду `ConfirmLive` и свойства ввода Live-ключей; `TradingViewModel` получил команду `ResetKillSwitch`. Поведенческое изменение: баннер REAL MONEY обновляется и на паузе/остановке; сохранение Live без второго шага заблокировано.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика). P0.5 не завершён — ждёт команды заказчика на следующий шаг.

### Проход 9 — 24.11.2026 — P0.5 проверка завершённости + учёт в трекере

По команде заказчика: P0.5 был завершён в коде, но запись в SECUPD.md не вносилась. Выполнена проверка всех четырёх пунктов остатка по фактическому коду — все реализованы и согласованы (колбэки зарегистрированы до старта, DI разрешается, ключи в appsettings, метрики в дашборде, тесты добавлены). **Код в этом проходе не менялся.**

| Действие | Файлы |
|---|---|
| Изменены | только `SECUPD.md` (P0.5 → ✅ с полным описанием и списком файлов завершения; сводка P0 = 7 ✅ / 0 🟡 / 0 ⬜; порядок работ → P1.6 / фикс `volume_ratio`; этот журнал) |
| Проверены (без правок) | `ReconciliationService.cs`, `TradingEngine.cs` (`ApplyExchangeFillAsync`/`AdoptOrphanPositionAsync`), `OrderExecutor.cs` (stream-first `WaitForFillAsync`), `Position.cs` (леджер `AppliedExchangeFills`), `TradingConfig.cs`/`appsettings.json` (3 ключа P0.5), `MetricsCollector.cs`, `DashboardViewModel.cs`, `BinanceWebSocketClient.cs`, `BinanceRestClient.cs`, `TradingLogicTests.cs` |

Ключи конфигурации P0.5, подтверждённые в `appsettings.json`: `UserDataStreamEnabled=true`, `UserDataKeepAliveMinutes=30`, `UserDataStreamHealthCheckSeconds=15`, `ReconciliationAdoptOrphanPositions=true`, `ReconciliationCancelOrphanBotOrders=true`.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика). Следующий шаг ждёт команды заказчика.

### Проход 10 — 24.11.2026 — очередь оставшихся работ от лёгких к тяжёлым

По команде заказчика оставшиеся работы упорядочены от лёгких/мелких к тяжёлым/большим. Учтены жёсткие зависимости из диагностики P2.1: фикс `volume_ratio` → P2.2 → P2.3/P2.5 → P2.4/P2.6; подбор порога/весов только после учёта издержек. **Код в этом проходе не менялся.**

| Действие | Файлы |
|---|---|
| Изменены | только `SECUPD.md` (сводка/замечание прохода 10, новый раздел «Порядок работ», этот журнал) |

Очередь: 1) фикс `volume_ratio`; 2) P1.8; 3) P2.2; 4) P2.3; 5) P2.5; 6) P1.5; 7) P1.6; 8) P1.2; 9) P1.1; 10) P1.3; 11) P1.4; 12) P2.4; 13) P1.7; 14) P2.6.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика). Первый шаг очереди ждёт команды заказчика.

### Проход 11 — 24.11.2026 — шаг №1: фикс `volume_ratio`

Клон репозитория получен; исходники из `AITradingSystem.zip` распакованы в корень клона (корень решения), `README.md` перезаписан версией из архива. Сам архив не пересобирался. SECUPD.md прочитан; выполнен первый пункт очереди из прохода 10 без изменения весов, рубрики и порогов.

**Изменения кода:** `IndicatorCalculator.LastClosedVolume` запоминает объём при `Update`, `IndicatorCalculator.VolumeRatio` делит его на `VolumeSma20`; окно и числитель очищаются при `Reset()`. Снапшот использует `calc.VolumeRatio`, а не `currentCandle.Volume`. В `TradingEngine.OnKlineReceived` зафиксирован контракт: текущая свеча нужна для цены/PnL, индикаторы и объём для отношения обновляются только закрытой свечой. Добавлены 3 регрессионных теста; не запускались.

| Действие | Файлы |
|---|---|
| Изменены до трекера | `AITradingSystem.Core/Indicators/IndicatorCalculator.cs`, `AITradingSystem.Core/Indicators/NormalizedIndicatorSnapshot.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Tests/IndicatorTests.cs` |
| Изменён сразу после кода | `SECUPD.md` (результат и файлы фикса в P2.1, сводка, очередь: осталось 13 шагов, этот журнал) |

Сборки/компиляции, запуск тестов и коммит не выполнялись. Кодовые правки сделаны в распакованном дереве; zip не пересобирался. **Шаг №1 завершён. Следующий шаг — №2, P1.8; ожидается команда заказчика на продолжение.**

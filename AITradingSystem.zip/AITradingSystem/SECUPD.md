# План доработок AITradingSystem — трекер выполнения

Источник: план пользователя (P0 / P1 / P2), скопирован дословно; добавлены статусы, ссылки на файлы и критерии приёмки.
Аудит выполнен: **24.11.2026**, по коду из `AITradingSystem.zip` (репозиторий `QuasarHeartofOmega/AITradingSystem`).

## Легенда

| Метка | Значение |
|---|---|
| ✅ | Выполнено — обязательно перечислены **изменённые файлы** |
| 🟡 | Частично — есть фундамент, но критерий пункта не выполнен |
| ⬜ | Не сделано — указаны файлы, которые предстоит менять |

**Правило ведения файла:** пункт переводится в ✅ только вместе со списком изменённых файлов (и, при наличии, коммитом). Пока кода нет — статус не меняется. Промежуточное состояние фиксируется как 🟡 с описанием, чего именно не хватает.

## Сводка на 24.11.2026 (после прохода 2 — P0.1)

| Блок | Готово | Частично | Не сделано |
|---|---|---|---|
| P0 — защита капитала | 1 / 7 | 2 | 4 |
| P1 — деньги и данные | 0 / 8 | 3 | 5 |
| P2 — сигнал и HOLD | 1 / 6 | 1 | 4 |

> **Проход 1 (аудит):** код не менялся, выполнен P2.1 — диагностика по логам (артефакт: [`docs/signal-funnel-20261124.md`](docs/signal-funnel-20261124.md)).
> **Проход 2 (этот):** выполнен **P0.1 — биржевые стоп-ордера OCO**, список изменённых файлов — в пункте и в журнале проходов ниже. Порядок работ соблюдён: P0.1 первый.
>
> **Замечания к рабочему дереву:**
> - В git-репозитории лежит только `AITradingSystem.zip`; исходники распакованы в `AITradingSystem/` (этот каталог — корень решения, все пути ниже относительны его). Правки внесены в распакованные файлы, zip не пересобирался.
> - Артефакт `docs/signal-funnel-20261124.md`, на который ссылается P2.1, **в снапшоте репозитория отсутствует** — каталога `docs/` нет. Выводы диагностики сохранены в тексте P2.1.
> - Сборки/компиляции в этом проходе не выполнялись (по требованию заказчика); тесты добавлены, но не запускались.

---

## P0 — защита капитала

### ✅ P0.1 Биржевые стоп-ордера
> Биржевые стоп-ордера: OCO (`STOP_LOSS_LIMIT` + `TAKE_PROFIT_LIMIT`) сразу после филла входа; трейлинг через cancel/replace (`OrderExecutor`, `BinanceRestClient`). Локальный SL — только дублёр. **Критерий: убить процесс с позицией → биржа закрывает сама.**

**Выполнено 24.11.2026 (проход 2).** Защита теперь ставится на самой бирже связкой OCO и переживает смерть процесса: ноги `STOP_LOSS_LIMIT` + `TAKE_PROFIT_LIMIT` остаются в стакане Binance, активация одной отменяет другую.

**Что сделано:**
1. **REST-слой:** `POST /api/v3/orderList/oco` (новый эндпоинт Binance, не legacy `/api/v3/order/oco`), `DELETE /api/v3/orderList`, `GET /api/v3/openOrderList`. Для SELL-защиты long: `aboveType=TAKE_PROFIT_LIMIT`, `belowType=STOP_LOSS_LIMIT`; для BUY — зеркально. У каждой связки/ноги свой `listClientOrderId`/`clientOrderId` (`oco-`/`sl-`/`tp-` + GUID, ≤36 символов).
2. **Постановка сразу после филла:** `TradingEngine.ProcessSymbolAsync` → `EnsureExchangeProtectionAsync` → `OrderExecutor.EnsureProtectionAsync` сразу после `AddPositionAsync`. Ориентир цены для правила OCO — mid стакана (актуальнее закрытия свечи).
3. **Fail-closed:** если OCO не встала в live — позиция закрывается market'ом (`Trading:ClosePositionIfProtectionFails=true`), правило «нет биржевой защиты → нет позиции». Тот же контроль применяется на каждом круге сопровождения, т.е. позиции, восстановленные из `positions.json` без защиты, либо получают OCO, либо закрываются.
4. **Трейлинг через cancel/replace:** `OrderExecutor.UpdateStopLossAsync` снимает старую связку и ставит новую с подтянутым стопом; локальный SL двигается **только после подтверждённой замены**. Троттлинг: `TrailingReplaceMinIntervalSeconds=30`, `TrailingReplaceMinStepPercent=0.15`. Если новая связка не встала — восстанавливается прежний стоп; если и это не удалось — позиция помечается незащищённой и закрывается движком.
5. **Закрытие:** перед MARKET-выходом OCO снимается (`CancelProtectionAsync`), иначе базовый актив заблокирован ногами и биржа отвечает -2010. Ответ «unknown order/list» (-2011) трактуется как «связки уже нет» (вероятно, сработала нога) и логируется `PROTECTION-GONE`.
6. **Округления защитных ног (задел под P1.3):** `ProtectiveOrderPricing.TryBuild` округляет объём к `stepSize`, обе цены к `tickSize` в сторону исполнения, проверяет `minQty` и `minNotional` по худшей ноге и правило Binance `TP.stopPrice > LastPrice > SL.stopPrice`. Лимитная цена отступает от триггера на `ProtectionLimitSlippage=0.3%`, чтобы сработавшая нога налилась.
7. **Персист:** `Position.Protection` (`ProtectiveOrderList`: orderListId, id/clientOrderId обеих ног, триггеры и лимитные цены, объём, статус) сохраняется в `positions.json` сразу после постановки/замены.
8. **Paper-режим:** защита симулируется (`IsSimulated=true`, на биржу ничего не отправляется), выходы по-прежнему считает локальный мониторинг.

**Изменённые файлы:**
- **новые:** `AITradingSystem.Core/Models/Trading/ProtectiveOrderList.cs`, `AITradingSystem.Core/Models/Trading/ProtectiveOrderPricing.cs`
- `AITradingSystem.Core/Models/Trading/Position.cs` (`Protection`, `HasExchangeProtection`, `SetProtection`)
- `AITradingSystem.Data/Binance/IBinanceRestClient.cs` (`PlaceOcoAsync`, `CancelOcoAsync`, `GetOpenOrderListsAsync`)
- `AITradingSystem.Data/Binance/BinanceRestClient.cs` (реализация OCO + `MapToProtection`; `BinanceApiException.IsUnknownOrderOrList`, `IsWouldImmediatelyTrigger`)
- `AITradingSystem.Data/Binance/BinanceModels.cs` (`BinanceOrderListResponse`, `BinanceOrderListRef`, `BinanceOrderResponse.StopPrice`)
- `AITradingSystem.Services/Trading/IOrderExecutor.cs` (`EnsureProtectionAsync`, `CancelProtectionAsync`, `UpdateStopLossAsync` → `Task<bool>`)
- `AITradingSystem.Services/Trading/OrderExecutor.cs` (постановка/замена/снятие OCO, cancel перед market-закрытием)
- `AITradingSystem.Services/Trading/TradingEngine.cs` (`EnsureExchangeProtectionAsync`, вызов после филла и в `MonitorPositionAsync`, трейлинг через executor, mid стакана как ориентир цены)
- `AITradingSystem.Common/Configuration/TradingConfig.cs` (`ExchangeProtectionEnabled`, `ProtectionLimitSlippage`, `ClosePositionIfProtectionFails`, `TrailingReplaceMinIntervalSeconds`, `TrailingReplaceMinStepPercent` + валидация)
- `AITradingSystem.UI/appsettings.json` (те же 5 ключей)
- `AITradingSystem.Tests/TradingLogicTests.cs` (5 тестов: правило above/below, отказ при стопе за рынком, округление/minNotional, порог значимости трейлинга, `HasExchangeProtection`)

**Критерий приёмки:** выполнен на уровне механики — ноги OCO живут на бирже независимо от процесса. Проверка «убить процесс» в живом окружении не проводилась (сборки/запуски запрещены в этом проходе).

**Остаточные ограничения (не входят в P0.1):**
- если биржа исполнила стоп, пока процесс был мёртв, после рестарта бот увидит позицию из `positions.json` и попытается закрыть её повторно — распознавание филлов через user-data stream/реконсиляцию делает **P0.5**;
- accompanied-мониторинг по-прежнему ходит раз в круг анализа (~7 мин на 12 пар) — независимый тик-контур делает **P0.2**;
- `GetOpenOrderListsAsync` возвращает только id связки/ног (Binance не отдаёт типы и цены в `openOrderList`) — разбор ног оставлен реконсиляции P0.5.

---

### ⬜ P0.2 Независимый контур мониторинга
> Независимый контур мониторинга: сопровождение позиций на каждый тик WS (≤1–2 с), без `await` LLM (`TradingEngine`).

**Сейчас:** один последовательный цикл. `MainLoopAsync` (`TradingEngine.cs:355`) → `ProcessSymbolsAsync` (`:384`) обходит символы по одному `await ProcessSymbolAsync`, внутри которого сначала мониторинг, затем инференс модели. По логу 24.11 проход по 12 парам занимает ~14 минут (02:14:51 → 02:38:35), т.е. позиция пересматривается раз в ~7 минут вместо 1–2 с. Обработчик `OnKlineReceived` (`:1028`) только обновляет кэш и PnL, сопровождения не делает.

**Файлы к изменению:** `AITradingSystem.Services/Trading/TradingEngine.cs` (вынести мониторинг в отдельный цикл/подписку на тик, отделить от LLM-конвейера), `AITradingSystem.Services/Trading/PositionManager.cs`.

---

### ⬜ P0.3 Очередь исполнения с приоритетами
> Очередь исполнения с приоритетами: закрытие/защита раньше входов; идемпотентность через `clientOrderId`.

**Сейчас:** очереди нет — ордера отправляются прямо из цикла анализа. `clientOrderId` генерируется (`OrderExecutor.cs:356`) и парсится (`BinanceRestClient.cs:521`), но как ключ идемпотентности/дедупликации при ретраях не используется.

**Файлы к изменению:** `AITradingSystem.Services/Trading/OrderExecutor.cs`, `IOrderExecutor.cs`, новый файл очереди (напр. `AITradingSystem.Services/Trading/ExecutionQueue.cs`), `AITradingSystem.Data/Binance/BinanceRestClient.cs` (передача `newClientOrderId`, повтор по тому же id).

---

### 🟡 P0.4 Персист DrawdownTracker
> Персист `DrawdownTracker` (пик, дневной старт) в `JsonStateRepository`, сброс по UTC биржи, восстановление при старте.

**Есть:** `JsonStateRepository.SavePeakBalanceAsync/LoadPeakBalanceAsync` (`JsonStateRepository.cs:66–97`) и `IStateRepository` — сохраняется **только пик**.
**Нет:** дневного старта (`_dayStartBalance`), даты дня, `MaxDrawdownPercent`; `DrawdownTracker` (`Core/RiskManagement/DrawdownTracker.cs`) целиком в памяти и создаётся заново в `RiskManager` — после рестарта дневной убыток обнуляется, лимит дня сбрасывается сам собой. Смена дня считается по `DateTime.UtcNow.Date` локального процесса, а не по времени биржи.

**Файлы к изменению:** `AITradingSystem.Core/RiskManagement/DrawdownTracker.cs` (снимок состояния/восстановление), `AITradingSystem.Data/Storage/IStateRepository.cs` + `JsonStateRepository.cs` (`SaveRiskStateAsync`), `AITradingSystem.Core/RiskManagement/RiskManager.cs:22`, `AITradingSystem.Services/Trading/TradingEngine.cs` (`StartAsync`).

---

### ⬜ P0.5 Реконсиляция + user-data stream
> Реконсиляция + user-data stream (`listenKey`/`executionReport`) вместо polling; подхват сиротских позиций/ордеров; учёт частичных филлов.

**Сейчас:** в коде нет ни `listenKey`, ни `executionReport` (grep по всему решению — 0 совпадений). Статус ордера узнаётся polling'ом `GetOrderAsync` с интервалом `OrderFillPollIntervalMs` (`OrderExecutor.cs:258–277`). Частичный филл учитывается (`OrderExecutor.cs`, отмена остатка + позиция на исполненный объём), но сиротские позиции/ордера после рестарта не подхватываются: восстанавливается только `positions.json`.

**Файлы к изменению:** `AITradingSystem.Data/Binance/BinanceWebSocketClient.cs` (+ `IBinanceWebSocketClient.cs`), `BinanceRestClient.cs` (`POST/PUT /api/v3/userDataStream`), `AITradingSystem.Services/Trading/ExchangeAccountService.cs`, `TradingEngine.cs` (`StartAsync` — реконсиляция), новый `AITradingSystem.Services/Trading/ReconciliationService.cs`.

---

### ⬜ P0.6 Kill-switch
> Kill-switch: авто-закрытие всех позиций при пробитии лимита просадки/дня (сейчас лимиты только запрещают новые входы) + паническая кнопка в UI.

**Сейчас:** подтверждено аудитом — `IsMaxDrawdownHit`/`IsDailyLossLimitHit` используются единственно в `RiskManager.cs:65–68` для отказа в **новом входе**. Ни авто-закрытия, ни кнопки паники нет (`grep KillSwitch/Panic` — 0 совпадений в коде и XAML).

**Файлы к изменению:** `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `DrawdownTracker.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs` (`CloseAllPositionsAsync`), `PositionManager.cs`, `AITradingSystem.UI/ViewModels/TradingViewModel.cs`, `AITradingSystem.UI/Views/TradingView.xaml`.

---

### ⬜ P0.7 Защита от случайного Live
> Защита от случайного Live: двухшаговое подтверждение, отдельные ключи/конфиги, несмываемый индикатор «REAL MONEY».

**Сейчас:** `Live` — просто третий элемент выпадающего списка `BinanceEnvironments = { "Demo", "Testnet", "Live" }` (`SettingsViewModel.cs:37`), переключается одним кликом без подтверждения; ключи общие для окружений; индикатора «REAL MONEY» в UI нет.

**Файлы к изменению:** `AITradingSystem.UI/ViewModels/SettingsViewModel.cs`, `MainViewModel.cs`, `AITradingSystem.UI/Views/SettingsView.xaml`, `MainWindow.xaml`, `AITradingSystem.Common/Configuration/BinanceConfig.cs` + `ConfigLoader.cs`, `AITradingSystem.UI/appsettings.json`.

---

## P1 — корректность денег и данных

### ⬜ P1.1 Slippage-модель в paper-режиме
> Slippage-модель в paper-режиме (филл по стакану, комиссии обеих ног).

**Сейчас:** paper-филл считается по цене сигнала с комиссией (`OrderExecutor.cs:119–122`, `:365`), стакан в симуляции не участвует; комиссии обеих ног в модель сделки не заложены. `grep Slippage` — 0 совпадений.

**Файлы:** `AITradingSystem.Services/Trading/OrderExecutor.cs` (`SimulatePaperOrder`, `ClosePositionAsync:175`), `AITradingSystem.Core/Models/MarketData/OrderBook.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`.

### ⬜ P1.2 Комиссии в R/R и безубытке
> Комиссии в R/R и безубытке; ограничение проскальзывания на market-выходе.

**Сейчас:** `RiskManager` считает R/R по чистым ценам (`RiskManager.cs:42`, `:86–89`), комиссия не входит; выход — `PlaceMarketOrderAsync` без ограничения проскальзывания (`OrderExecutor.cs:200`).

**Файлы:** `AITradingSystem.Core/RiskManagement/RiskManager.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`.

### 🟡 P1.3 Округления tick/step/minNotional для всех ног
> Округления tick/step/minNotional для всех ног включая OCO; dust; аудит частичного филла после отмены остатка.

**Есть:** фильтры парсятся корректно (`BinanceModels.cs:222–255`), округление и проверка `minQty`/`minNotional` для **входной** ноги (`OrderExecutor.cs:84–116`), отмена остатка с добором фактического объёма (`:258–277`).
**Добавлено в проходе 2 (вместе с P0.1):** округления tick/step и проверка `minQty`/`minNotional` для **стоп/тейк-ног** — `ProtectiveOrderPricing.TryBuild` (объём к stepSize, обе цены к tickSize в сторону исполнения, minNotional по худшей ноге, правило above/below относительно текущей цены).
**Нет:** обработки dust и аудита расхождения «отменённый остаток vs фактический филл»; объём защиты может быть меньше объёма позиции после округления к stepSize — этот «хвост» пока не логируется отдельной метрикой.

**Файлы:** `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Core/Models/Trading/ProtectiveOrderPricing.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs` (`SymbolPrecision`, `:58–59`, `:720–730`).

### ⬜ P1.4 Целостность данных после реконнекта WS
> Целостность данных после реконнекта WS: REST-дозагрузка свечей, детект разрывов, повторный прогрев; запрет входов на протухших данных.

**Сейчас:** есть только экспоненциальный reconnect (`BinanceWebSocketClient.cs:128–192`). Прогрев свечами делается один раз при старте (`TradingEngine.cs:142`); после переподключения дыры в истории не детектируются и не дозагружаются, «протухшие» данные входы не блокируют.

**Файлы:** `AITradingSystem.Data/Binance/BinanceWebSocketClient.cs`, `AITradingSystem.Services/Analysis/MarketAnalyzer.cs`, `AITradingSystem.Core/Indicators/IndicatorCalculator.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`.

### ⬜ P1.5 Фильтр ликвидности
> Фильтр ликвидности: спред/глубина/объём перед входом (BTTC/STRAX/FLR); метрика post-only-отказов.

**Сейчас:** широкий спред только **логируется** (`TradingEngine.cs`, `OnOrderBookReceived`, порог 0.5%), вход не блокирует. Признак post-only-отказа есть (`BinanceRestClient.cs:602`, `IsPostOnlyRejection`), но в метрики не агрегируется.

**Файлы:** `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `symbols.json`.

### 🟡 P1.6 Обработка 429/-1003 и бюджет весов
> Обработка 429/-1003 c `Retry-After`, бюджет весов запросов.

**Есть:** чтение `Retry-After` (`BinanceRestClient.cs:457`) и признание `-1003` ретраебельной ошибкой (`:472–473`).
**Нет:** явной ветки HTTP 429, учёта `X-MBX-USED-WEIGHT`/бюджета весов и планировщика, который притормаживает polling при приближении к лимиту.

**Файлы:** `AITradingSystem.Data/Binance/BinanceRestClient.cs`, новый `AITradingSystem.Data/Binance/RequestWeightBudget.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`.

### ⬜ P1.7 Портфельный риск
> Портфельный риск: кап суммарной экспозиции и корреляции (12 альтов ≈ ставка на BTC), дневной лимит на символ, пауза после серии убытков.

**Сейчас:** есть только `MaxOpenPositions = 3` и лимит на пару из `symbols.json` (`TradingConfig.cs`, `SymbolPositionLimits`). Экспозиция/корреляция/серия убытков не считаются (`grep Correlation/Exposure` — 0).

**Файлы:** `AITradingSystem.Core/RiskManagement/RiskManager.cs`, новый `PortfolioRiskManager.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Data/Storage/JsonTradeHistoryRepository.cs`.

### ⬜ P1.8 Мониторинг дрейфа часов
> Мониторинг дрейфа часов с алертом.

**Сейчас:** синхронизация времени есть (`BinanceRestClient.cs:317–340`, `_timeSyncLock`), но величина дрейфа не измеряется/не алертится; флаг закрытия свечи частично подстрахован вручную (`BinanceWebSocketClient.cs:279–281`).

**Файлы:** `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Services/Monitoring/MetricsCollector.cs`, `TelegramAlertService.cs`.

---

## P2 — 🆕 сигнал и HOLD: убрать тройную осторожность

### ✅ P2.1 Диагностика по логам CALIBRATE/Rejected
> 🆕 Диагностика по логам CALIBRATE/Rejected: посчитать, где умирают сигналы — модель сама HOLD / BUY режется порогом / post-only не налился. Лечить причину, а не всё сразу.

**Выполнено 24.11.2026** по логу `trades-20261124.txt` (29 решений, 11 символов, 02:14–02:38).
**Артефакт:** [`docs/signal-funnel-20261124.md`](docs/signal-funnel-20261124.md) (новый файл). Исходный лог: `uploads/trades-20261124.txt` (вне репозитория).
**Изменённые файлы кода:** нет — пункт аналитический.

**Вывод (куда лечить):** все 29 сигналов умерли **на выходе модели**, а не на пороге и не на исполнении: `model_conf` avg **0.157**, median **0.10**, 16/29 залипли на нижней отсечке 0.10; `engine_prior` max **0.42**; `final` max **0.35** при пороге 0.55. Ни одного `Rejected`/ордера в логе нет — до исполнения дело не доходит.
Две причины, обе подтверждаются кодом:
1. **Двойной штраф** (P2.2): 28/29 обоснований HOLD ссылаются на слабый объём, 29/29 — на «конфликт» индикаторов, за которые prior уже умножен на ×0.8/×0.6.
2. **🆕 Баг данных, найденный при диагностике:** `volume_ratio` считается по **незакрытой** свече. `OnKlineReceived` кладёт в кэш каждый тик (`TradingEngine.cs:1028–1033`), снапшот берёт `candle.Volume` (`NormalizedIndicatorSnapshot.cs:109`) и делит на SMA20 закрытых свечей (`IndicatorCalculator.cs:44–48`). Отсюда `volume_ratio` 0.005–0.49 одновременно у **всех** 12 пар, включая BTC/ETH, и вечный штраф ×0.8 + рубрика −0.1…−0.2. Это надо чинить **до** перенастройки весов/порогов, иначе подбор пойдёт по испорченным данным.

---

### ⬜ P2.2 Убрать двойной штраф в промпте
> 🆕 Убрать двойной штраф в промпте (`PromptBuilder`): рубрика вычитает 0.1–0.2 за слабые ADX/объём, за которые prior уже умножен на 0.6–0.8. Модель должна давать независимую оценку (новости, структура рынка), а не пересчитывать prior.

**Сейчас:** рубрика literally велит стартовать с prior и вычитать за те же факторы: `PromptBuilder.cs:62` (start from `engine_prior_confidence`), `:64` (subtract 0.10–0.20 за conflicts / `adx_raw < 20` / `volume_ratio < 0.6` / BB), `:68` (пример «mixed → 0.30»). Штрафы движка: `SignalCalibrator.cs:120–160`.

**Файлы:** `AITradingSystem.Services/AI/PromptBuilder.cs`, `AITradingSystem.Services/Analysis/SignalCalibrator.cs` (что отдаём модели как факт, а не как оценку).

### ⬜ P2.3 Политика уверенности 0.7 / 0.3
> 🆕 Политика уверенности (`ConfidencePolicy`): уйти от Blend 50/50 — веса 0.7/0.3.

**Сейчас:** `final = 0.5m * modelConf + 0.5m * prior` (`SignalCalibrator.cs:264`), политика `Blend` в `appsettings.json:89`.
**Замечание из диагностики:** на текущем логе смена весов **не даёт ни одного входа** (при 0.7/0.3 максимум `final` = 0.42 против порога 0.55) — пункт имеет смысл только после P2.2 и фикса `volume_ratio`.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Common/Configuration/AIConfig.cs`, `AITradingSystem.UI/appsettings.json`.

### ⬜ P2.4 Порог MinConfidence из данных
> 🆕 Порог `MinConfidence` из данных: 0.55 сейчас взято с потолка; подобрать по expectancy после издержек на истории.

**Сейчас:** `MinConfidence = 0.55` — дефолт в `CalibrationContext` (`SignalCalibrator.cs:50`) и в `appsettings.json:81`; история сделок для подбора не используется.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Data/Storage/JsonTradeHistoryRepository.cs`, новый инструмент подбора (`tools/`), `AITradingSystem.UI/appsettings.json`.

### 🟡 P2.5 Расширить детект «дегенерата»
> 🆕 Расширить детект «дегенерата» (`SignalCalibrator`): пересмотр HOLD→вход при любом HOLD с сильным согласованным prior, а не только conf=0.45±0.02.

**Есть:** детект узкого окна `|modelConf − 0.45| ≤ 0.02` (`SignalCalibrator.cs:238–239`) и пересмотр `HOLD → вход` при `final >= MinConfidence` (`:281–293`).
**Нет:** срабатывания на прочих HOLD. В логе окно поймало ровно 1 случай из 29 (BNB, `source=Degenerate→Prior`), остальные 28 — `Blend`; при этом `prior >= 0.55` не было ни разу, так что пересмотр не мог сработать в принципе.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Tests/TradingLogicTests.cs` (кейсы на новый детект).

### ⬜ P2.6 Валидация весов скоринга
> 🆕 Валидация весов скоринга (EMA 0.30, Supertrend 0.20, штрафы ×0.6/0.8…): подтвердить/подогнать на истории; reliability diagram — уверенность должна соответствовать реальной частоте успеха.

**Сейчас:** веса зашиты константами (`SignalCalibrator.cs:78–84`: EMA 0.30 / Supertrend 0.20 / EMA-pos 0.15 / RSI 0.15 / MACD 0.10 / Stoch 0.05 / OBV 0.05), prior = `0.2 + 0.7·|score|` (`:168`). В логе `ema_align = 0` в 28/30 случаев → крупнейший вес не contributes, |score| ≤ 0.32 и prior структурно не превышает 0.42 < 0.55. Бэктеста/калибровочной кривой в решении нет.

**Файлы:** `AITradingSystem.Services/Analysis/SignalCalibrator.cs`, `AITradingSystem.Core/Indicators/NormalizedIndicatorSnapshot.cs:70–71` (`ema_align`), новый бэктест/отчёт (`tools/`), `AITradingSystem.Tests/`.

---

## Порядок работ (вывод из диагностики)

1. **P0.1 → P0.2 → P0.6** — сначала сделать так, чтобы позиция переживала падение процесса и закрывалась по лимиту риска. Сейчас при 12 парах и ~7-минутном круге анализа капитал не защищён ничем, кроме живого процесса.
   **Статус:** P0.1 ✅ (проход 2). **Следующий шаг — P0.2** (независимый контур мониторинга на тик WS, без `await` LLM).
2. **Фикс `volume_ratio` (P2.1, находка) → P2.2 → P2.3/P2.5 → P2.4/P2.6** — сначала убрать порчу данных и двойной штраф, и только потом крутить веса/пороги: на испорченном входе любая калибровка подгоняется под артефакт.
3. **P0.3–P0.5, P0.7 и P1** — параллельно/после, по мере готовности исполнения и телеметрии.

---

## Журнал проходов

### Проход 2 — 24.11.2026 — P0.1 «Биржевые стоп-ордера»

| Действие | Файлы |
|---|---|
| Созданы | `AITradingSystem.Core/Models/Trading/ProtectiveOrderList.cs`, `AITradingSystem.Core/Models/Trading/ProtectiveOrderPricing.cs` |
| Изменены | `AITradingSystem.Core/Models/Trading/Position.cs`, `AITradingSystem.Data/Binance/IBinanceRestClient.cs`, `AITradingSystem.Data/Binance/BinanceRestClient.cs`, `AITradingSystem.Data/Binance/BinanceModels.cs`, `AITradingSystem.Services/Trading/IOrderExecutor.cs`, `AITradingSystem.Services/Trading/OrderExecutor.cs`, `AITradingSystem.Services/Trading/TradingEngine.cs`, `AITradingSystem.Common/Configuration/TradingConfig.cs`, `AITradingSystem.UI/appsettings.json`, `AITradingSystem.Tests/TradingLogicTests.cs` |
| Трекер | `SECUPD.md` (P0.1 → ✅, сводка P0 = 1/7, обновлён P1.3, добавлен журнал) |

Новые ключи конфигурации (`Trading`): `ExchangeProtectionEnabled=true`, `ProtectionLimitSlippage=0.003`, `ClosePositionIfProtectionFails=true`, `TrailingReplaceMinIntervalSeconds=30`, `TrailingReplaceMinStepPercent=0.15`.

Побочные эффекты интерфейса: `IOrderExecutor.UpdateStopLossAsync` теперь `Task<bool>` (было `Task<Order?>`) и реально ходит на биржу; добавлены `EnsureProtectionAsync`/`CancelProtectionAsync`. Внешних вызовов старого метода вне `TradingEngine` не было.

Не делалось: сборки/компиляции, запуск тестов, коммит (по требованию заказчика).

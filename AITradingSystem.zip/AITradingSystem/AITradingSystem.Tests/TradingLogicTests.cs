using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Services.Monitoring;
using AITradingSystem.Services.Trading;
using Microsoft.Extensions.Logging.Abstractions;

namespace AITradingSystem.Tests;

/// <summary>
/// Торговая логика: валидация сигнала, жизненный цикл позиции,
/// защита от «мгновенного» стопа и частичного закрытия.
/// </summary>
public class TradingLogicTests
{
    private static Position LongPosition(decimal entry = 100m, decimal sl = 98m, decimal tp = 106m) => new()
    {
        Symbol = "BTCUSDT",
        Side = OrderSide.Buy,
        Quantity = 1m,
        EntryPrice = entry,
        CurrentPrice = entry,
        StopLoss = sl,
        TakeProfit = tp,
        InitialStopLoss = sl,
        OpenedAt = new DateTime(2026, 11, 23, 12, 10, 0, DateTimeKind.Utc)
    };

    [Fact]
    public void Buy_Signal_Requires_Ordered_Prices()
    {
        var signal = new TradingSignal
        {
            Symbol = "BTCUSDT",
            Action = SignalAction.Buy,
            Confidence = 0.8m,
            EntryPrice = 100m,
            StopLoss = 101m, // выше входа — недопустимо для long
            TakeProfit = 106m
        };

        Assert.False(signal.IsValid(out var error));
        Assert.Contains("StopLoss", error);

        signal.StopLoss = 98m;
        Assert.True(signal.IsValid(out _));
        Assert.Equal(3m, signal.RiskRewardRatio);
    }

    [Fact]
    public void Hold_And_Close_Do_Not_Need_Prices()
    {
        var close = new TradingSignal { Action = SignalAction.Close, Confidence = 0.9m };
        Assert.True(close.IsValid(out _));
        Assert.Null(close.RiskRewardRatio);
    }

    [Fact]
    public void Candle_Started_Before_Entry_Is_Flagged()
    {
        var position = LongPosition();

        // Свеча 12:00 открылась до входа в 12:10 — её Low нельзя использовать для SL.
        Assert.True(position.CandleStartedBeforeEntry(new DateTime(2026, 11, 23, 12, 0, 0, DateTimeKind.Utc)));
        Assert.False(position.CandleStartedBeforeEntry(new DateTime(2026, 11, 23, 12, 15, 0, DateTimeKind.Utc)));
    }

    [Fact]
    public void StopLoss_Hit_Uses_Low_Of_Candle()
    {
        var position = LongPosition();

        Assert.True(position.IsStopLossHit(97m, 101m));
        Assert.False(position.IsStopLossHit(99m, 101m));
        Assert.True(position.IsTakeProfitHit(99m, 107m));
    }

    [Fact]
    public void Partial_Close_Keeps_Remainder_Open()
    {
        var position = LongPosition();
        position.EntryCommission = 0.1m;

        position.ReduceQuantity(0.4m);

        Assert.Equal(0.6m, position.Quantity);
        Assert.Equal(60m, position.Notional);

        position.UpdatePrice(110m);
        Assert.Equal(6m, position.UnrealizedPnL); // 0.6 * (110 - 100)
    }

    [Fact]
    public void Trailing_Stop_Only_Moves_Up_For_Long()
    {
        var position = LongPosition();

        Assert.False(position.UpdateTrailingStop(97m));
        Assert.True(position.UpdateTrailingStop(99m));
        Assert.Equal(99m, position.StopLoss);
    }

    [Fact]
    public void PositionSizer_Never_Exceeds_Balance()
    {
        var sizer = new PositionSizer(new TradingConfig { RiskPerTrade = 0.02 });

        // Стоп в 0.1% → «по риску» объём был бы 20 BTC, но баланс позволяет только 1.
        var quantity = sizer.CalculatePositionSize(100m, 100m, 99.9m, 1m);

        Assert.Equal(1m, quantity);
    }

    [Fact]
    public void PositionSizer_Zero_Stop_Distance_Returns_Zero()
    {
        var sizer = new PositionSizer(new TradingConfig());
        Assert.Equal(0m, sizer.CalculatePositionSize(1000m, 100m, 100m, 1m));
    }

    // === P0.1: биржевая защита OCO ===

    [Fact]
    public void Oco_Prices_For_Long_Satisfy_Binance_Above_Below_Rule()
    {
        var ok = ProtectiveOrderPricing.TryBuild(
            OrderSide.Buy, quantity: 1m, stopLoss: 98m, takeProfit: 106m, referencePrice: 100m,
            tickSize: 0.01m, stepSize: 0.001m, minQty: 0.001m, minNotional: 5m,
            limitSlippage: 0.003m, out var prices, out var error);

        Assert.True(ok, error);
        Assert.NotNull(prices);

        // SELL-защита long: TP.stopPrice (above) > LastPrice > SL.stopPrice (below)
        Assert.True(prices!.TakeProfitTrigger > 100m);
        Assert.True(prices.StopTrigger < 100m);

        // Лимитные цены отступают от триггера в сторону исполнения (для SELL — вниз).
        Assert.True(prices.StopLimit < prices.StopTrigger);
        Assert.True(prices.TakeProfitLimit < prices.TakeProfitTrigger);

        // Округление к tickSize: ни одна цена не «между тиками».
        Assert.Equal(0m, prices.StopLimit % 0.01m);
        Assert.Equal(0m, prices.TakeProfitLimit % 0.01m);
    }

    [Fact]
    public void Oco_Is_Rejected_When_Stop_Already_Beyond_Market()
    {
        // Цена ушла ниже стопа: OCO поставить нельзя — нужен market-выход, а не «голая» позиция.
        var ok = ProtectiveOrderPricing.TryBuild(
            OrderSide.Buy, 1m, stopLoss: 98m, takeProfit: 106m, referencePrice: 97m,
            0.01m, 0.001m, 0.001m, 5m, 0.003m, out var prices, out var error);

        Assert.False(ok);
        Assert.Null(prices);
        Assert.Contains("market", error);
    }

    [Fact]
    public void Oco_Quantity_Rounds_To_Step_And_Checks_MinNotional()
    {
        var ok = ProtectiveOrderPricing.TryBuild(
            OrderSide.Buy, quantity: 0.123456m, stopLoss: 98m, takeProfit: 106m, referencePrice: 100m,
            tickSize: 0.01m, stepSize: 0.001m, minQty: 0.001m, minNotional: 5m,
            limitSlippage: 0.003m, out var prices, out _);

        Assert.True(ok);
        Assert.Equal(0.123m, prices!.Quantity);

        // Обе ноги должны проходить minNotional: 0.123 * ~97.7 = 12 < 50.
        var tooSmall = ProtectiveOrderPricing.TryBuild(
            OrderSide.Buy, 0.123456m, 98m, 106m, 100m,
            0.01m, 0.001m, 0.001m, minNotional: 50m, 0.003m, out _, out var error);

        Assert.False(tooSmall);
        Assert.Contains("minNotional", error);
    }

    [Fact]
    public void Trailing_Replace_Requires_Significant_Improvement()
    {
        // 0.05% улучшения — меньше порога 0.15%: биржу не дёргаем.
        Assert.False(ProtectiveOrderPricing.IsStopImprovementSignificant(OrderSide.Buy, 98m, 98.05m, 0.15m));

        // 0.51% — заменяем связку.
        Assert.True(ProtectiveOrderPricing.IsStopImprovementSignificant(OrderSide.Buy, 98m, 98.5m, 0.15m));

        // Ухудшение стопа для long недопустимо ни при каком пороге.
        Assert.False(ProtectiveOrderPricing.IsStopImprovementSignificant(OrderSide.Buy, 98m, 97m, 0m));
    }

    [Fact]
    public void Position_Without_Protection_Is_Not_Exchange_Protected()
    {
        var position = LongPosition();
        Assert.False(position.HasExchangeProtection);

        position.SetProtection(new ProtectiveOrderList { IsSimulated = true });
        Assert.False(position.HasExchangeProtection); // paper-симуляция не защищает от падения процесса

        position.SetProtection(new ProtectiveOrderList { OrderListId = 42 });
        Assert.True(position.HasExchangeProtection);
    }

    // === P0.2: независимый тик-контур сопровождения ===

    [Fact]
    public void Exit_Price_Uses_Executable_Side_Of_Book()
    {
        var tick = new PositionMonitor.MarketTick(Last: 100m, Bid: 99.5m, Ask: 100.5m, UpdatedAtUtc: DateTime.UtcNow);

        // Long закрывается SELL'ом → получим bid, а не «красивую» середину.
        Assert.Equal(99.5m, PositionMonitor.ResolveExitPrice(OrderSide.Buy, tick));
        Assert.Equal(100.5m, PositionMonitor.ResolveExitPrice(OrderSide.Sell, tick));

        // Нет стакана — последняя цена; нет и её — середина.
        Assert.Equal(100m, PositionMonitor.ResolveExitPrice(OrderSide.Buy, tick with { Bid = 0m, Ask = 0m }));
        Assert.Equal(100m, PositionMonitor.ResolveExitPrice(
            OrderSide.Buy, new PositionMonitor.MarketTick(0m, 99m, 101m, DateTime.UtcNow)));
    }

    [Fact]
    public void Tick_Below_Stop_Triggers_Exit_Without_Waiting_For_Candle()
    {
        var position = LongPosition();
        var candle = new OHLCV
        {
            Symbol = "BTCUSDT",
            OpenTime = position.OpenedAt.AddMinutes(-5), // свеча началась ДО входа
            Low = 99m, High = 101m, Close = 100m
        };

        // Тик above stop — выхода нет, экстремумы старой свечи не считаются.
        var idle = PositionMonitor.EvaluateExits(position, 99.9m, candle);
        Assert.False(idle.StopLossHit);
        Assert.False(idle.TakeProfitHit);

        // Тик пробил стоп — выход сразу, не дожидаясь закрытия свечи и цикла анализа.
        var hit = PositionMonitor.EvaluateExits(position, 97.9m, candle);
        Assert.True(hit.StopLossHit);

        var tp = PositionMonitor.EvaluateExits(position, 106.5m, candle);
        Assert.True(tp.TakeProfitHit);
    }

    [Fact]
    public void Candle_Started_After_Entry_Contributes_Extremes()
    {
        var position = LongPosition();
        var candle = new OHLCV
        {
            Symbol = "BTCUSDT",
            OpenTime = position.OpenedAt.AddMinutes(1), // свеча началась ПОСЛЕ входа
            Low = 97m, High = 100m, Close = 99m
        };

        // Последний тик 99, но внутри свечи уже был прокол 97 — стоп обязан сработать.
        var hit = PositionMonitor.EvaluateExits(position, 99m, candle);
        Assert.True(hit.StopLossHit);
    }

    [Fact]
    public void No_Tick_And_No_Candle_Does_Not_Fabricate_Exit()
    {
        var position = LongPosition();
        var result = PositionMonitor.EvaluateExits(position, 0m, null);

        Assert.False(result.StopLossHit);
        Assert.False(result.TakeProfitHit);
    }

    [Fact]
    public void PositionMonitor_Config_Validation_Rejects_Unsafe_Intervals()
    {
        var config = new TradingConfig
        {
            Symbols = new List<string> { "BTCUSDT" },
            PositionMonitorIntervalMs = 50
        };
        Assert.Throws<InvalidOperationException>(() => config.Validate());

        config.PositionMonitorIntervalMs = 500;
        config.PositionMonitorSweepSeconds = 0;
        Assert.Throws<InvalidOperationException>(() => config.Validate());

        config.PositionMonitorSweepSeconds = 5;
        config.ProtectionRetryIntervalSeconds = 0;
        Assert.Throws<InvalidOperationException>(() => config.Validate());

        config.ProtectionRetryIntervalSeconds = 15;
        config.Validate();
    }

    // === P0.3 (фундамент): очередь исполнения с приоритетами и идемпотентностью ===

    private static ExecutionQueue NewQueue(int maxParallel = 1)
    {
        var config = new TradingConfig
        {
            Symbols = new List<string> { "BTCUSDT" },
            ExecutionQueueMaxParallel = maxParallel
        };
        return new ExecutionQueue(config, new MetricsCollector(), NullLogger<ExecutionQueue>.Instance);
    }

    [Fact]
    public async Task Close_Is_Executed_Before_Earlier_Queued_Entry()
    {
        await using var queue = NewQueue();
        var order = new List<string>();
        var gate = new TaskCompletionSource();
        var started = new TaskCompletionSource();

        // Первая операция занимает единственный слот, остальные копятся в очереди.
        var blocker = queue.SubmitAsync("BTCUSDT", ExecutionPriority.Entry, "block", async _ =>
        {
            started.SetResult();
            await gate.Task;
            lock (order) order.Add("block");
            return 1;
        });

        await started.Task; // слот гарантированно занят, дальше — чистая проверка приоритетов

        var entry = queue.SubmitAsync("ETHUSDT", ExecutionPriority.Entry, "entry", _ =>
        {
            lock (order) order.Add("entry");
            return Task.FromResult(2);
        });

        var close = queue.SubmitAsync("BNBUSDT", ExecutionPriority.Close, "close", _ =>
        {
            lock (order) order.Add("close");
            return Task.FromResult(3);
        });

        gate.SetResult();
        await Task.WhenAll(blocker, entry, close);

        Assert.Equal(new[] { "block", "close", "entry" }, order);
    }

    [Fact]
    public async Task Same_ClientOrderId_Does_Not_Send_Second_Order()
    {
        await using var queue = NewQueue();
        var sends = 0;

        Task<int> Send() => queue.SubmitAsync("BTCUSDT", ExecutionPriority.Entry, "ent-same", _ =>
        {
            Interlocked.Increment(ref sends);
            return Task.FromResult(42);
        });

        var first = await Send();
        var second = await Send(); // тот же ключ — результат из кэша, отправки нет

        Assert.Equal(42, first);
        Assert.Equal(42, second);
        Assert.Equal(1, sends);
        Assert.Equal(1, queue.ReplayedResults);
    }

    [Fact]
    public async Task One_Operation_Per_Symbol_In_Flight()
    {
        await using var queue = NewQueue(maxParallel: 4);
        var concurrent = 0;
        var maxConcurrent = 0;

        async Task<int> Work()
        {
            var now = Interlocked.Increment(ref concurrent);
            if (now > Volatile.Read(ref maxConcurrent))
                Interlocked.Exchange(ref maxConcurrent, now);

            await Task.Delay(20);
            Interlocked.Decrement(ref concurrent);
            return 1;
        }

        await Task.WhenAll(Enumerable.Range(0, 4)
            .Select(_ => queue.SubmitAsync("BTCUSDT", ExecutionPriority.Entry, null, _ => Work())));

        Assert.Equal(1, maxConcurrent);
    }
}

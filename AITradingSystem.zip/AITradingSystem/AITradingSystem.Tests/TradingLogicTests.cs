using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Core.RiskManagement;

namespace AITradingSystem.Tests;

/// <summary>
/// Торговая логика: валидация сигнала, жизненный цикл позиции,
/// защита от «мгновенного» стопа и частичного закрытия.
/// </summary>
public class TradingLogicTests
{
    private static Position LongPosition(decimal entry = 100m, decimal sl = 98m, decimal tp = 106m) => new()
    {
        Symbol = "BTCUSDT",
        Side = OrderSide.Buy,
        Quantity = 1m,
        EntryPrice = entry,
        CurrentPrice = entry,
        StopLoss = sl,
        TakeProfit = tp,
        InitialStopLoss = sl,
        OpenedAt = new DateTime(2026, 11, 23, 12, 10, 0, DateTimeKind.Utc)
    };

    [Fact]
    public void Buy_Signal_Requires_Ordered_Prices()
    {
        var signal = new TradingSignal
        {
            Symbol = "BTCUSDT",
            Action = SignalAction.Buy,
            Confidence = 0.8m,
            EntryPrice = 100m,
            StopLoss = 101m, // выше входа — недопустимо для long
            TakeProfit = 106m
        };

        Assert.False(signal.IsValid(out var error));
        Assert.Contains("StopLoss", error);

        signal.StopLoss = 98m;
        Assert.True(signal.IsValid(out _));
        Assert.Equal(3m, signal.RiskRewardRatio);
    }

    [Fact]
    public void Hold_And_Close_Do_Not_Need_Prices()
    {
        var close = new TradingSignal { Action = SignalAction.Close, Confidence = 0.9m };
        Assert.True(close.IsValid(out _));
        Assert.Null(close.RiskRewardRatio);
    }

    [Fact]
    public void Candle_Started_Before_Entry_Is_Flagged()
    {
        var position = LongPosition();

        // Свеча 12:00 открылась до входа в 12:10 — её Low нельзя использовать для SL.
        Assert.True(position.CandleStartedBeforeEntry(new DateTime(2026, 11, 23, 12, 0, 0, DateTimeKind.Utc)));
        Assert.False(position.CandleStartedBeforeEntry(new DateTime(2026, 11, 23, 12, 15, 0, DateTimeKind.Utc)));
    }

    [Fact]
    public void StopLoss_Hit_Uses_Low_Of_Candle()
    {
        var position = LongPosition();

        Assert.True(position.IsStopLossHit(97m, 101m));
        Assert.False(position.IsStopLossHit(99m, 101m));
        Assert.True(position.IsTakeProfitHit(99m, 107m));
    }

    [Fact]
    public void Partial_Close_Keeps_Remainder_Open()
    {
        var position = LongPosition();
        position.EntryCommission = 0.1m;

        position.ReduceQuantity(0.4m);

        Assert.Equal(0.6m, position.Quantity);
        Assert.Equal(60m, position.Notional);

        position.UpdatePrice(110m);
        Assert.Equal(6m, position.UnrealizedPnL); // 0.6 * (110 - 100)
    }

    [Fact]
    public void Trailing_Stop_Only_Moves_Up_For_Long()
    {
        var position = LongPosition();

        Assert.False(position.UpdateTrailingStop(97m));
        Assert.True(position.UpdateTrailingStop(99m));
        Assert.Equal(99m, position.StopLoss);
    }

    [Fact]
    public void PositionSizer_Never_Exceeds_Balance()
    {
        var sizer = new PositionSizer(new TradingConfig { RiskPerTrade = 0.02 });

        // Стоп в 0.1% → «по риску» объём был бы 20 BTC, но баланс позволяет только 1.
        var quantity = sizer.CalculatePositionSize(100m, 100m, 99.9m, 1m);

        Assert.Equal(1m, quantity);
    }

    [Fact]
    public void PositionSizer_Zero_Stop_Distance_Returns_Zero()
    {
        var sizer = new PositionSizer(new TradingConfig());
        Assert.Equal(0m, sizer.CalculatePositionSize(1000m, 100m, 100m, 1m));
    }
}

using AITradingSystem.Core.Indicators;
using AITradingSystem.Core.Models.MarketData;

namespace AITradingSystem.Tests;

public class IndicatorTests
{
    private static OHLCV Candle(decimal close, decimal high, decimal low, decimal volume = 100m, int minute = 0) => new()
    {
        Symbol = "BTCUSDT",
        Open = close,
        High = high,
        Low = low,
        Close = close,
        Volume = volume,
        OpenTime = new DateTime(2025, 1, 1, 0, minute, 0, DateTimeKind.Utc),
        CloseTime = new DateTime(2025, 1, 1, 0, minute, 59, DateTimeKind.Utc)
    };

    [Fact]
    public void EMA_Converges_To_Constant_Price()
    {
        var ema = new EMA(20);
        for (int i = 0; i < 300; i++)
            ema.Update(Candle(100m, 101m, 99m, minute: i % 60));

        Assert.True(ema.IsReady);
        Assert.Equal(100m, ema.GetValue(), 2);
    }

    [Fact]
    public void RSI_All_Up_Moves_Approaches_100()
    {
        var rsi = new RSI(14);
        for (int i = 0; i < 100; i++)
            rsi.Update(Candle(100m + i, 101m + i, 99m + i, minute: i % 60));

        Assert.True(rsi.IsReady);
        Assert.Equal(100m, rsi.GetValue(), 0);
    }

    [Fact]
    public void RSI_Stays_In_Range()
    {
        var rsi = new RSI(14);
        var rnd = new Random(42);
        var price = 100m;
        for (int i = 0; i < 500; i++)
        {
            price += (decimal)(rnd.NextDouble() - 0.5) * 5m;
            rsi.Update(Candle(price, price + 1m, price - 1m, minute: i % 60));
            Assert.InRange(rsi.GetValue(), 0m, 100m);
        }
    }

    [Fact]
    public void Calculator_AllReady_After_300_Candles()
    {
        var calc = new IndicatorCalculator("BTCUSDT");
        var rnd = new Random(7);
        var price = 50000m;
        for (int i = 0; i < 300; i++)
        {
            price += (decimal)(rnd.NextDouble() - 0.5) * 200m;
            calc.Update(Candle(price, price + 50m, price - 50m, volume: 10m + i, minute: i % 60));
        }

        Assert.True(calc.AllReady);

        var snapshot = calc.GetNormalizedSnapshot(Candle(price, price + 50m, price - 50m));
        var dict = snapshot.ToDictionary();

        Assert.True(dict.ContainsKey("price"));
        Assert.True(dict.ContainsKey("atr_pct"));
        Assert.InRange(dict["rsi"], -1m, 1m);
        Assert.InRange(dict["adx"], 0m, 1m);
        Assert.InRange(dict["stoch_rsi_k"], 0m, 1m);
        Assert.InRange(dict["obv_trend"], -1m, 1m);
    }

    [Fact]
    public void StochRSI_D_Differs_From_K_When_Moving()
    {
        var stoch = new StochasticRsi(14, 14, 3, 3);
        var rnd = new Random(11);
        var price = 100m;
        for (int i = 0; i < 200; i++)
        {
            price += (decimal)(rnd.NextDouble() - 0.5) * 4m;
            stoch.Update(Candle(price, price + 1m, price - 1m, minute: i % 60));
        }

        Assert.InRange(stoch.K, 0m, 100m);
        Assert.InRange(stoch.D, 0m, 100m);
    }
}

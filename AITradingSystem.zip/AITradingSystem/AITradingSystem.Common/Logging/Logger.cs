﻿using Serilog;
using Serilog.Events;
using AITradingSystem.Common.Configuration;

namespace AITradingSystem.Common.Logging;

/// <summary>
/// Централизованная инициализация логгера (FR-8.1).
/// </summary>
public static class Logger
{
    private static bool _initialized;
    private static readonly object _lock = new();

    /// <summary>
    /// Инициализирует глобальный логгер Serilog.
    /// Должен быть вызван один раз при старте приложения.
    /// </summary>
    public static void Initialize(LoggingConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);
        config.Validate();

        lock (_lock)
        {
            if (_initialized)
            {
                throw new InvalidOperationException("Логгер уже инициализирован.");
            }

            if (!Enum.TryParse<LogEventLevel>(config.MinimumLevel, true, out var level))
            {
                level = LogEventLevel.Information;
            }

            Directory.CreateDirectory(config.LogPath);

            var loggerConfig = new LoggerConfiguration()
                .MinimumLevel.Is(level)
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .MinimumLevel.Override("System", LogEventLevel.Warning)
                .Enrich.FromLogContext()
                .Enrich.WithThreadId()
                .Enrich.WithMachineName()
                .Enrich.WithProperty("Application", "AITradingSystem");

            if (config.WriteToConsole)
            {
                loggerConfig.WriteTo.Console(
                    outputTemplate: "[{Timestamp:HH:mm:ss} {Level:u3}] [{ThreadId}] {Message:lj}{NewLine}{Exception}");
            }

            if (config.WriteToFile)
            {
                // Основной лог — все уровни согласно конфигу
                loggerConfig.WriteTo.File(
                    path: System.IO.Path.Combine(config.LogPath, "trading-.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: config.RetainedFileCount,
                    fileSizeLimitBytes: (long)config.MaxFileSizeMb * 1024 * 1024,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] [{ThreadId}] {SourceContext} {Message:lj}{NewLine}{Exception}",
                    shared: true);

                // Отдельный лог только для торговых событий (Information+)
                loggerConfig.WriteTo.File(
                    path: System.IO.Path.Combine(config.LogPath, "trades-.log"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: 30,
                    restrictedToMinimumLevel: LogEventLevel.Information,
                    outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff} {Message:lj}{NewLine}");
            }

            Log.Logger = loggerConfig.CreateLogger();
            _initialized = true;

            Log.Information("Логгер инициализирован. Level: {Level}, Path: {Path}",
                config.MinimumLevel, config.LogPath);
        }
    }

    /// <summary>
    /// Корректное завершение работы логгера.
    /// </summary>
    public static void Shutdown()
    {
        lock (_lock)
        {
            if (!_initialized) return;

            Log.Information("Логгер завершает работу.");
            Log.CloseAndFlush();
            _initialized = false;
        }
    }
}
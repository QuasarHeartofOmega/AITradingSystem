﻿using System.Security.Cryptography;
using System.Text;
using System.Runtime.InteropServices;

namespace AITradingSystem.Common.Security;

/// <summary>
/// Шифрование/дешифрование API-ключей (NFR-3.1).
/// На Windows используется DPAPI (привязка к пользователю).
/// На других ОС — AES-256-GCM с ключом, производным от имени пользователя.
/// </summary>
public static class ApiKeyEncryptor
{
    private const int AesKeySize = 256;
    private const int AesIvSize = 12;
    private const int AesTagSize = 16;

    /// <summary>
    /// Шифрует строку.
    /// </summary>
    public static string Encrypt(string plainText)
    {
        if (string.IsNullOrEmpty(plainText))
            return string.Empty;

        var plainBytes = Encoding.UTF8.GetBytes(plainText);

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            // DPAPI — привязка к текущему пользователю Windows
            var encrypted = ProtectedData.Protect(
                plainBytes,
                optionalEntropy: null,
                scope: DataProtectionScope.CurrentUser);
            return Convert.ToBase64String(encrypted);
        }
        else
        {
            return EncryptAesGcm(plainBytes);
        }
    }

    /// <summary>
    /// Дешифрует строку.
    /// </summary>
    public static string Decrypt(string cipherText)
    {
        if (string.IsNullOrWhiteSpace(cipherText))
            return string.Empty; // Безопасно возвращаем пустую строку, если ключа нет

        try
        {
            var cipherBytes = Convert.FromBase64String(cipherText);

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                var decrypted = ProtectedData.Unprotect(
                    cipherBytes,
                    optionalEntropy: null,
                    scope: DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(decrypted);
            }
            else
            {
                return DecryptAesGcm(cipherBytes);
            }
        }
        catch (FormatException)
        {
            throw new CryptographicException(
                "API Key в appsettings.json не является корректной Base64 строкой. " +
                "Убедитесь, что вы зашифровали ключ с помощью ApiKeyEncryptor, а не вставили его в открытом виде.");
        }
        catch (CryptographicException ex)
        {
            throw new CryptographicException(
                $"Не удалось расшифровать API Key. Возможно, ключ был зашифрован под другим пользователем Windows. " +
                $"Оригинальная ошибка: {ex.Message}");
        }
    }

    private static string EncryptAesGcm(byte[] plainBytes)
    {
        var key = DeriveKey();
        var iv = RandomNumberGenerator.GetBytes(AesIvSize);
        var tag = new byte[AesTagSize];
        var cipherBytes = new byte[plainBytes.Length];

        using var aes = new AesGcm(key, AesTagSize);
        aes.Encrypt(iv, plainBytes, cipherBytes, tag);

        // Формат: IV (12) + Tag (16) + CipherText
        var result = new byte[iv.Length + tag.Length + cipherBytes.Length];
        Buffer.BlockCopy(iv, 0, result, 0, iv.Length);
        Buffer.BlockCopy(tag, 0, result, iv.Length, tag.Length);
        Buffer.BlockCopy(cipherBytes, 0, result, iv.Length + tag.Length, cipherBytes.Length);

        return Convert.ToBase64String(result);
    }

    private static string DecryptAesGcm(byte[] data)
    {
        if (data.Length < AesIvSize + AesTagSize)
            throw new CryptographicException("Недопустимый формат зашифрованных данных.");

        var key = DeriveKey();
        var iv = new byte[AesIvSize];
        var tag = new byte[AesTagSize];
        var cipherBytes = new byte[data.Length - AesIvSize - AesTagSize];

        Buffer.BlockCopy(data, 0, iv, 0, AesIvSize);
        Buffer.BlockCopy(data, AesIvSize, tag, 0, AesTagSize);
        Buffer.BlockCopy(data, AesIvSize + AesTagSize, cipherBytes, 0, cipherBytes.Length);

        var plainBytes = new byte[cipherBytes.Length];
        using var aes = new AesGcm(key, AesTagSize);
        aes.Decrypt(iv, cipherBytes, tag, plainBytes);

        return Encoding.UTF8.GetString(plainBytes);
    }

    /// <summary>
    /// Производный ключ от имени пользователя и машины.
    /// </summary>
    private static byte[] DeriveKey()
    {
        var salt = Encoding.UTF8.GetBytes("AITradingSystem_v1_" + Environment.MachineName);
        var password = Encoding.UTF8.GetBytes(Environment.UserName);

        using var pbkdf2 = new Rfc2898DeriveBytes(
            password, salt,
            iterations: 100_000,
            HashAlgorithmName.SHA256);

        return pbkdf2.GetBytes(AesKeySize / 8);
    }
}
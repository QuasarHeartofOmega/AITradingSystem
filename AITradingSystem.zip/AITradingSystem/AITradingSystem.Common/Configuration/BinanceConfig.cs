﻿namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Конфигурация подключения к Binance (FR-6, NFR-3).
/// </summary>
public sealed class BinanceConfig
{
    /// <summary>
    /// Зашифрованный API Key (NFR-3.1).
    /// </summary>
    public string EncryptedApiKey { get; set; } = string.Empty;

    /// <summary>
    /// Зашифрованный API Secret (NFR-3.1).
    /// </summary>
    public string EncryptedApiSecret { get; set; } = string.Empty;

    /// <summary>
    /// Использование тестовой сети Binance (testnet.binance.vision).
    /// По умолчанию true для безопасности при разработке.
    /// </summary>
    public bool UseTestnet { get; set; } = true;

    /// <summary>
    /// Base URL для REST API.
    /// </summary>
    public string RestBaseUrl => UseTestnet
        ? "https://testnet.binance.vision"
        : "https://api.binance.com";

    /// <summary>
    /// Base URL для WebSocket.
    /// </summary>
    public string WebSocketBaseUrl => UseTestnet
        ? "wss://testnet.binance.vision/ws"
        : "wss://stream.binance.com:9443/ws";

    /// <summary>
    /// Таймаут HTTP-запросов в миллисекундах.
    /// </summary>
    public int HttpTimeoutMs { get; set; } = 10_000;

    /// <summary>
    /// Максимальное количество повторных попыток при ошибке (FR-6.4).
    /// </summary>
    public int MaxRetries { get; set; } = 3;

    /// <summary>
    /// Начальная задержка между retry в мс (экспоненциальный backoff).
    /// </summary>
    public int RetryBaseDelayMs { get; set; } = 500;

    public void Validate()
    {
        if (UseTestnet) return; // Для testnet ключи могут быть пустыми при первом запуске

        if (string.IsNullOrWhiteSpace(EncryptedApiKey) ||
            string.IsNullOrWhiteSpace(EncryptedApiSecret))
        {
            throw new InvalidOperationException(
                "API ключи не настроены. Используйте UI для ввода ключей в режиме Live.");
        }

        if (HttpTimeoutMs < 1000 || HttpTimeoutMs > 60_000)
            throw new InvalidOperationException("HttpTimeoutMs должен быть в диапазоне [1000; 60000]");
    }
}
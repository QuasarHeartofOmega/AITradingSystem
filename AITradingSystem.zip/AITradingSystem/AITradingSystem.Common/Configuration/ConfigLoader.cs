using System.Text.Json;
using Microsoft.Extensions.Configuration;

namespace AITradingSystem.Common.Configuration;

public static class ConfigLoader
{
    /// <summary>
    /// symbols.json — основной источник списка пар и их лимитов, если содержит непустой Symbols.
    /// Иначе используется appsettings/environment override. Повреждённый symbols.json — ошибка запуска,
    /// чтобы не начать торговлю с неожиданным списком. Валидация против биржи выполняется при старте движка.
    /// </summary>
    public static AppConfig Load(string basePath, string? environment = null)
    {
        if (string.IsNullOrWhiteSpace(basePath)) throw new ArgumentException("basePath не может быть пустым.", nameof(basePath));
        if (!Directory.Exists(basePath)) throw new DirectoryNotFoundException($"Директория не найдена: {basePath}");
        var builder = new ConfigurationBuilder().SetBasePath(basePath)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
        if (!string.IsNullOrWhiteSpace(environment))
            builder.AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true);
        var configuration = builder.Build();
        var config = new AppConfig();
        configuration.GetSection("Trading").Bind(config.Trading);
        configuration.GetSection("Binance").Bind(config.Binance);
        configuration.GetSection("AI").Bind(config.AI);
        configuration.GetSection("News").Bind(config.News);
        configuration.GetSection("Telegram").Bind(config.Telegram);
        configuration.GetSection("Logging").Bind(config.Logging);

        var path = Path.Combine(basePath, "symbols.json");
        if (File.Exists(path))
        {
            using var document = JsonDocument.Parse(File.ReadAllText(path));
            var root = document.RootElement;
            var quotes = ReadStrings(root, "QuoteAssets");
            if (quotes.Count > 0) config.Trading.QuoteAssets = quotes;
            var watch = ReadStrings(root, "WatchAssets");
            if (watch.Count > 0) config.Trading.WatchAssets = watch;
            if (root.TryGetProperty("Symbols", out var array) && array.ValueKind == JsonValueKind.Array)
            {
                var symbols = new List<string>();
                decimal enabledLimitSum = 0m;
                foreach (var item in array.EnumerateArray())
                {
                    if (item.ValueKind == JsonValueKind.String) { symbols.Add(item.GetString()!); continue; }
                    if (item.ValueKind != JsonValueKind.Object ||
                        !item.TryGetProperty("Enabled", out var enabled) || enabled.ValueKind != JsonValueKind.False)
                    {
                        if (item.TryGetProperty("Symbol", out var symbol) && symbol.ValueKind == JsonValueKind.String)
                    {
                        var name = SymbolNaming.NormalizeSymbol(symbol.GetString(), config.Trading.QuoteAssets);
                        if (name is null) continue;
                        symbols.Add(name);
                        if (item.TryGetProperty("MaxPositionPercent", out var limit) && limit.TryGetDecimal(out var percent))
                        {
                            if (percent <= 0 || percent > 100) throw new InvalidOperationException($"MaxPositionPercent {name} должен быть в (0; 100].");
                            config.Trading.SymbolPositionLimits[name] = percent;
                            enabledLimitSum += percent;
                        }
                        if (item.TryGetProperty("PriceDecimals", out var decimals) && decimals.TryGetInt32(out var precision) && precision is >= 0 and <= 12)
                            config.Trading.SymbolPriceDecimals[name] = precision;
                    }
                    }
                }
                if (enabledLimitSum > 100) throw new InvalidOperationException($"Сумма лимитов активных пар {enabledLimitSum}% превышает 100%.");
                if (symbols.Count > 0) config.Trading.Symbols = symbols;
            }
        }
        config.Validate();
        return config;
    }

    private static List<string> ReadStrings(JsonElement root, string name) =>
        root.TryGetProperty(name, out var array) && array.ValueKind == JsonValueKind.Array
            ? array.EnumerateArray().Where(x => x.ValueKind == JsonValueKind.String).Select(x => x.GetString()!).ToList()
            : new();
}

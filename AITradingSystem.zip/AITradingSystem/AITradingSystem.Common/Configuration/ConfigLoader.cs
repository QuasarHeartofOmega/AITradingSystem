﻿using Microsoft.Extensions.Configuration;

namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Загрузчик конфигурации из JSON-файлов.
/// </summary>
public static class ConfigLoader
{
    /// <summary>
    /// Загружает и валидирует конфигурацию.
    /// </summary>
    /// <param name="basePath">Путь к директории с appsettings.json.</param>
    /// <param name="environment">Окружение (Development, Production). Опционально.</param>
    public static AppConfig Load(string basePath, string? environment = null)
    {
        if (string.IsNullOrWhiteSpace(basePath))
            throw new ArgumentException("basePath не может быть пустым.", nameof(basePath));

        if (!Directory.Exists(basePath))
            throw new DirectoryNotFoundException($"Директория не найдена: {basePath}");

        var builder = new ConfigurationBuilder()
            .SetBasePath(basePath)
            .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

        if (!string.IsNullOrWhiteSpace(environment))
        {
            builder.AddJsonFile($"appsettings.{environment}.json", optional: true, reloadOnChange: true);
        }

        var configuration = builder.Build();
        var config = new AppConfig();

        configuration.GetSection("Trading").Bind(config.Trading);
        configuration.GetSection("Binance").Bind(config.Binance);
        configuration.GetSection("AI").Bind(config.AI);
        configuration.GetSection("News").Bind(config.News);
        configuration.GetSection("Telegram").Bind(config.Telegram);
        configuration.GetSection("Logging").Bind(config.Logging);

        config.Validate();

        return config;
    }
}
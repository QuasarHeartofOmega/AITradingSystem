﻿namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Конфигурация источника новостей (FR-2).
/// </summary>
public sealed class NewsConfig
{
    /// <summary>
    /// API ключ CryptoPanic (FR-2.1).
    /// </summary>
    public string CryptoPanicApiKey { get; set; } = string.Empty;

    /// <summary>
    /// Интервал обновления новостей в минутах (FR-2.2).
    /// </summary>
    public int UpdateIntervalMinutes { get; set; } = 5;

    /// <summary>
    /// Максимальное количество новостей на один актив за цикл.
    /// </summary>
    public int MaxNewsPerSymbol { get; set; } = 10;

    /// <summary>
    /// Включен ли анализ новостей.
    /// </summary>
    public bool Enabled { get; set; } = true;

    public void Validate()
    {
        if (UpdateIntervalMinutes < 1 || UpdateIntervalMinutes > 60)
            throw new InvalidOperationException(
                $"UpdateIntervalMinutes должен быть в диапазоне [1; 60].");

        if (MaxNewsPerSymbol < 1 || MaxNewsPerSymbol > 50)
            throw new InvalidOperationException(
                $"MaxNewsPerSymbol должен быть в диапазоне [1; 50].");
    }
}
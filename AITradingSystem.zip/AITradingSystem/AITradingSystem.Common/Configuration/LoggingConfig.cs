﻿namespace AITradingSystem.Common.Configuration;

public sealed class LoggingConfig
{
    public string MinimumLevel { get; set; } = "Information";
    public string LogPath { get; set; } = "logs";
    public bool WriteToConsole { get; set; } = true;
    public bool WriteToFile { get; set; } = true;

    /// <summary>
    /// Максимальный размер одного лог-файла в МБ.
    /// </summary>
    public int MaxFileSizeMb { get; set; } = 50;

    /// <summary>
    /// Количество хранимых лог-файлов.
    /// </summary>
    public int RetainedFileCount { get; set; } = 10;

    public void Validate()
    {
        var validLevels = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "Verbose", "Debug", "Information", "Warning", "Error", "Fatal"
        };
        if (!validLevels.Contains(MinimumLevel))
            throw new InvalidOperationException($"Недопустимый уровень логирования: {MinimumLevel}");

        if (string.IsNullOrWhiteSpace(LogPath))
            throw new InvalidOperationException("LogPath не указан.");

        if (MaxFileSizeMb < 1 || MaxFileSizeMb > 1000)
            throw new InvalidOperationException("MaxFileSizeMb должен быть в диапазоне [1; 1000].");
    }
}
namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Параметры торговой стратегии и риск-менеджмента.
/// Соответствуют требованиям FR-5.1 - FR-5.7.
/// </summary>
public sealed class TradingConfig
{
    /// <summary>
    /// Список торговых пар. Загружается из symbols.json через SymbolRegistryService.
    /// Здесь задаются только значения по умолчанию, если symbols.json отсутствует.
    /// </summary>
    public List<string> Symbols { get; set; } = new();
    public List<string> WatchAssets { get; set; } = new();
    public List<string> QuoteAssets { get; set; } = new(SymbolNaming.DefaultQuotes);
    public Dictionary<string, int> SymbolPriceDecimals { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public Dictionary<string, decimal> SymbolPositionLimits { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public int AccountRefreshIntervalSeconds { get; set; } = 20;
    public decimal MinExchangePositionNotional { get; set; } = 1m;

    /// <summary>
    /// Процент риска от депозита на одну сделку (FR-5.1).
    /// Диапазон: 0.001 (0.1%) — 0.05 (5%).
    /// </summary>
    public double RiskPerTrade { get; set; } = 0.02;

    /// <summary>
    /// Максимальная просадка, при которой торговля останавливается (FR-5.6).
    /// </summary>
    public double MaxDrawdown { get; set; } = 0.10;

    /// <summary>
    /// Дневной лимит убытков (FR-5.7).
    /// </summary>
    public double DailyLossLimit { get; set; } = 0.05;

    /// <summary>
    /// Множитель ATR для расчета Stop-Loss (FR-5.3).
    /// SL = Entry - N * ATR.
    /// </summary>
    public double StopLossAtrMultiplier { get; set; } = 2.0;

    /// <summary>
    /// Минимальное соотношение Risk/Reward (FR-5.4).
    /// </summary>
    public double MinRiskRewardRatio { get; set; } = 2.0;

    /// <summary>
    /// Включен ли Trailing Stop (FR-5.5).
    /// </summary>
    public bool EnableTrailingStop { get; set; } = true;

    /// <summary>
    /// Множитель ATR для подтягивания Trailing Stop.
    /// </summary>
    public double TrailingStopAtrMultiplier { get; set; } = 1.5;

    /// <summary>
    /// Интервал свечей для анализа (1m, 5m, 15m, 1h, 4h, 1d).
    /// </summary>
    public string CandleInterval { get; set; } = "15m";

    /// <summary>
    /// Глубина истории свечей для расчета индикаторов.
    /// Должна быть достаточной для EMA(200) + буфер.
    /// </summary>
    public int HistoryCandlesCount { get; set; } = 300;

    /// <summary>
    /// Период обновления стакана ордеров в секундах (FR-1.3).
    /// </summary>
    public int OrderBookUpdateIntervalSeconds { get; set; } = 3;

    /// <summary>
    /// Включен ли режим paper trading (NFR-5.2).
    /// </summary>
    public bool PaperTradingMode { get; set; } = false;

    /// <summary>
    /// Начальный баланс для paper trading (USDT).
    /// </summary>
    public decimal PaperTradingInitialBalance { get; set; } = 10000m;

    /// <summary>
    /// Комиссия симулируемых сделок в paper-режиме (0.001 = 0.1% как на споте Binance).
    /// </summary>
    public decimal PaperCommissionRate { get; set; } = 0.001m;

    /// <summary>
    /// Разрешить шорт. На споте Binance шортить нельзя, поэтому по умолчанию false:
    /// сигнал SELL без открытой позиции игнорируется, с открытой — закрывает её.
    /// </summary>
    public bool AllowShort { get; set; } = false;

    /// <summary>
    /// Сколько секунд ждать исполнения лимитного (Post-Only) ордера на вход.
    /// По истечении неисполненный остаток отменяется, позиция открывается только на исполненный объём.
    /// </summary>
    public int OrderFillTimeoutSeconds { get; set; } = 60;

    /// <summary>Интервал опроса статуса ордера, мс.</summary>
    public int OrderFillPollIntervalMs { get; set; } = 1500;

    /// <summary>Входить MARKET-ордером вместо Post-Only лимитного (быстрее, но комиссия taker).</summary>
    public bool UseMarketEntry { get; set; } = false;

    /// <summary>
    /// Спрашивать AI об уже открытой позиции (закрыть/держать) с этим интервалом, секунд.
    /// </summary>
    public int PositionReviewIntervalSeconds { get; set; } = 120;

    /// <summary>Разрешить AI закрывать позицию сигналом CLOSE/SELL.</summary>
    public bool AiCanClosePositions { get; set; } = true;

    /// <summary>Интервал основного цикла анализа, секунд.</summary>
    public int AnalysisIntervalSeconds { get; set; } = 5;

    /// <summary>Максимум одновременно открытых позиций.</summary>
    public int MaxOpenPositions { get; set; } = 3;

    /// <summary>
    /// Минимальная пауза между запросами к ИИ по одному символу, секунд (B11).
    /// При 12+ символах и медленном инференсе очередь не забивается одним символом.
    /// 0 — без паузы (анализировать каждый цикл).
    /// </summary>
    public int SymbolAnalysisCooldownSeconds { get; set; } = 60;

    /// <summary>
    /// Валидация конфигурации. Вызывается при загрузке.
    /// </summary>
    public void Validate()
    {
        if (RiskPerTrade <= 0 || RiskPerTrade > 0.05)
            throw new InvalidOperationException(
                $"RiskPerTrade должен быть в диапазоне (0; 0.05]. Текущее: {RiskPerTrade}");

        if (MaxDrawdown <= 0 || MaxDrawdown >= 1)
            throw new InvalidOperationException(
                $"MaxDrawdown должен быть в диапазоне (0; 1). Текущее: {MaxDrawdown}");

        if (DailyLossLimit <= 0 || DailyLossLimit >= 1)
            throw new InvalidOperationException(
                $"DailyLossLimit должен быть в диапазоне (0; 1). Текущее: {DailyLossLimit}");

        if (StopLossAtrMultiplier <= 0)
            throw new InvalidOperationException(
                $"StopLossAtrMultiplier должен быть > 0. Текущее: {StopLossAtrMultiplier}");

        if (MinRiskRewardRatio < 1)
            throw new InvalidOperationException(
                $"MinRiskRewardRatio должен быть >= 1. Текущее: {MinRiskRewardRatio}");

        QuoteAssets = SymbolNaming.NormalizeAssets(QuoteAssets);
        if (QuoteAssets.Count == 0) throw new InvalidOperationException("QuoteAssets не может быть пустым.");
        WatchAssets = SymbolNaming.NormalizeAssets(WatchAssets);
        var normalized = new List<string>();
        foreach (var raw in Symbols ?? new List<string>())
        {
            var symbol = SymbolNaming.NormalizeSymbol(raw, QuoteAssets);
            if (symbol is null)
            {
                Serilog.Log.Warning("Пропущен некорректный символ {Symbol}: неизвестная котировка или формат", raw);
                continue;
            }
            if (!normalized.Contains(symbol)) normalized.Add(symbol);
        }
        Symbols = normalized;
        if (Symbols.Count == 0)
            throw new InvalidOperationException("После нормализации список торговых пар пуст.");
        if (Symbols.Count > 32)
            throw new InvalidOperationException($"Максимум 32 торговые пары. Указано: {Symbols.Count}");
        if (AccountRefreshIntervalSeconds < 5 || AccountRefreshIntervalSeconds > 300)
            throw new InvalidOperationException("AccountRefreshIntervalSeconds должен быть в диапазоне [5; 300].");
        if (MinExchangePositionNotional < 0)
            throw new InvalidOperationException("MinExchangePositionNotional должен быть >= 0.");

        var validIntervals = new HashSet<string>
        {
            "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d"
        };
        if (!validIntervals.Contains(CandleInterval))
            throw new InvalidOperationException(
                $"Недопустимый интервал свечей: {CandleInterval}");

        if (HistoryCandlesCount < 200)
            throw new InvalidOperationException(
                $"HistoryCandlesCount должен быть >= 200 для корректного расчета EMA(200). " +
                $"Текущее: {HistoryCandlesCount}");

        if (HistoryCandlesCount > 1000)
            throw new InvalidOperationException(
                "HistoryCandlesCount должен быть <= 1000 (лимит Binance /api/v3/klines).");

        if (PaperCommissionRate < 0 || PaperCommissionRate > 0.01m)
            throw new InvalidOperationException("PaperCommissionRate должен быть в диапазоне [0; 0.01].");

        if (OrderFillTimeoutSeconds < 1 || OrderFillTimeoutSeconds > 3600)
            throw new InvalidOperationException("OrderFillTimeoutSeconds должен быть в диапазоне [1; 3600].");

        if (OrderFillPollIntervalMs < 200 || OrderFillPollIntervalMs > 30_000)
            throw new InvalidOperationException("OrderFillPollIntervalMs должен быть в диапазоне [200; 30000].");

        if (PositionReviewIntervalSeconds < 5 || PositionReviewIntervalSeconds > 86_400)
            throw new InvalidOperationException("PositionReviewIntervalSeconds должен быть в диапазоне [5; 86400].");

        if (AnalysisIntervalSeconds < 1 || AnalysisIntervalSeconds > 3600)
            throw new InvalidOperationException("AnalysisIntervalSeconds должен быть в диапазоне [1; 3600].");

        if (MaxOpenPositions < 1 || MaxOpenPositions > 32)
            throw new InvalidOperationException("MaxOpenPositions должен быть в диапазоне [1; 32].");

        if (SymbolAnalysisCooldownSeconds < 0 || SymbolAnalysisCooldownSeconds > 3600)
            throw new InvalidOperationException(
                $"SymbolAnalysisCooldownSeconds должен быть в диапазоне [0; 3600]. Текущее: {SymbolAnalysisCooldownSeconds}");
    }
}
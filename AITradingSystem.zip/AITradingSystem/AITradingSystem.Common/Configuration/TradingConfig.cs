﻿namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Параметры торговой стратегии и риск-менеджмента.
/// Соответствуют требованиям FR-5.1 - FR-5.7.
/// </summary>
public sealed class TradingConfig
{
    /// <summary>
    /// Список торговых пар. Загружается из symbols.json через SymbolRegistryService.
    /// Здесь задаются только значения по умолчанию, если symbols.json отсутствует.
    /// </summary>
    public List<string> Symbols { get; set; } = new();

    /// <summary>
    /// Процент риска от депозита на одну сделку (FR-5.1).
    /// Диапазон: 0.001 (0.1%) — 0.05 (5%).
    /// </summary>
    public double RiskPerTrade { get; set; } = 0.02;

    /// <summary>
    /// Максимальная просадка, при которой торговля останавливается (FR-5.6).
    /// </summary>
    public double MaxDrawdown { get; set; } = 0.10;

    /// <summary>
    /// Дневной лимит убытков (FR-5.7).
    /// </summary>
    public double DailyLossLimit { get; set; } = 0.05;

    /// <summary>
    /// Множитель ATR для расчета Stop-Loss (FR-5.3).
    /// SL = Entry - N * ATR.
    /// </summary>
    public double StopLossAtrMultiplier { get; set; } = 2.0;

    /// <summary>
    /// Минимальное соотношение Risk/Reward (FR-5.4).
    /// </summary>
    public double MinRiskRewardRatio { get; set; } = 2.0;

    /// <summary>
    /// Включен ли Trailing Stop (FR-5.5).
    /// </summary>
    public bool EnableTrailingStop { get; set; } = true;

    /// <summary>
    /// Множитель ATR для подтягивания Trailing Stop.
    /// </summary>
    public double TrailingStopAtrMultiplier { get; set; } = 1.5;

    /// <summary>
    /// Интервал свечей для анализа (1m, 5m, 15m, 1h, 4h, 1d).
    /// </summary>
    public string CandleInterval { get; set; } = "15m";

    /// <summary>
    /// Глубина истории свечей для расчета индикаторов.
    /// Должна быть достаточной для EMA(200) + буфер.
    /// </summary>
    public int HistoryCandlesCount { get; set; } = 300;

    /// <summary>
    /// Период обновления стакана ордеров в секундах (FR-1.3).
    /// </summary>
    public int OrderBookUpdateIntervalSeconds { get; set; } = 3;

    /// <summary>
    /// Включен ли режим paper trading (NFR-5.2).
    /// </summary>
    public bool PaperTradingMode { get; set; } = false;

    /// <summary>
    /// Начальный баланс для paper trading (USDT).
    /// </summary>
    public decimal PaperTradingInitialBalance { get; set; } = 10000m;

    /// <summary>
    /// Валидация конфигурации. Вызывается при загрузке.
    /// </summary>
    public void Validate()
    {
        if (RiskPerTrade <= 0 || RiskPerTrade > 0.05)
            throw new InvalidOperationException(
                $"RiskPerTrade должен быть в диапазоне (0; 0.05]. Текущее: {RiskPerTrade}");

        if (MaxDrawdown <= 0 || MaxDrawdown >= 1)
            throw new InvalidOperationException(
                $"MaxDrawdown должен быть в диапазоне (0; 1). Текущее: {MaxDrawdown}");

        if (DailyLossLimit <= 0 || DailyLossLimit >= 1)
            throw new InvalidOperationException(
                $"DailyLossLimit должен быть в диапазоне (0; 1). Текущее: {DailyLossLimit}");

        if (StopLossAtrMultiplier <= 0)
            throw new InvalidOperationException(
                $"StopLossAtrMultiplier должен быть > 0. Текущее: {StopLossAtrMultiplier}");

        if (MinRiskRewardRatio < 1)
            throw new InvalidOperationException(
                $"MinRiskRewardRatio должен быть >= 1. Текущее: {MinRiskRewardRatio}");

        if (Symbols is null || Symbols.Count == 0)
            throw new InvalidOperationException("Список торговых пар не может быть пустым.");

        if (Symbols.Count > 10)
            throw new InvalidOperationException(
                $"Максимум 10 торговых пар. Указано: {Symbols.Count}");

        var validIntervals = new HashSet<string>
        {
            "1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "12h", "1d"
        };
        if (!validIntervals.Contains(CandleInterval))
            throw new InvalidOperationException(
                $"Недопустимый интервал свечей: {CandleInterval}");

        if (HistoryCandlesCount < 200)
            throw new InvalidOperationException(
                $"HistoryCandlesCount должен быть >= 200 для корректного расчета EMA(200). " +
                $"Текущее: {HistoryCandlesCount}");
    }
}
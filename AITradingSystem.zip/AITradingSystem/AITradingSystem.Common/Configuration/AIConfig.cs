﻿namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Конфигурация AI-модели Qwen 14B (FR-4, NFR-1.1).
/// </summary>
public sealed class AIConfig
{
    /// <summary>
    /// Путь к файлу модели в формате GGUF.
    /// </summary>
    public string ModelPath { get; set; } = "models/qwen3-14b-q4_k_m.gguf";

    /// <summary>
    /// Размер контекстного окна (FR-4 ограничение).
    /// Ограничено 8192 для экономии VRAM.
    /// </summary>
    public int ContextSize { get; set; } = 8192;

    /// <summary>
    /// Количество слоев модели, размещаемых на GPU (FR-4.1).
    /// Для 12GB VRAM и Q4_K_M оптимально ~35.
    /// По умолчанию 0: в решении установлен CPU-бэкенд (LLamaSharp.Backend.Cpu),
    /// для GPU нужен LLamaSharp.Backend.Cuda12 и NVIDIA GPU.
    /// </summary>
    public int GpuLayers { get; set; }

    /// <summary>
    /// Temperature для генерации.
    /// Ниже = более детерминированные ответы (важно для JSON).
    /// </summary>
    public float Temperature { get; set; } = 0.3f;

    /// <summary>
    /// Top-P (nucleus sampling).
    /// </summary>
    public float TopP { get; set; } = 0.9f;

    /// <summary>
    /// Максимальное количество токенов в ответе (FR-4.3).
    /// </summary>
    public int MaxTokens { get; set; } = 500;

    /// <summary>
    /// Максимальное время инференса в мс (NFR-1.1).
    /// </summary>
    public int InferenceTimeoutMs { get; set; } = 120_000;

    /// <summary>
    /// Количество попыток при невалидном JSON (FR-4.4).
    /// </summary>
    public int MaxRetriesOnInvalidJson { get; set; } = 3;

    /// <summary>
    /// Путь к нативной библиотеке llama.cpp: каталог с llama.dll/ggml*.dll
    /// или полный путь к llama.dll. Если null — библиотеки ищутся рядом с exe
    /// и в runtimes/&lt;rid&gt;/native/&lt;avx&gt; (см. LlamaNativeLoader).
    /// </summary>
    public string? NativeLibraryPath { get; set; }

    /// <summary>
    /// Режим рассуждений Qwen3 (thinking). По умолчанию выключен:
    /// иначе модель тратит лимит токенов на &lt;think&gt; и не успевает выдать JSON.
    /// </summary>
    public bool EnableThinking { get; set; }

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(ModelPath))
            throw new InvalidOperationException("ModelPath не указан.");

        if (ContextSize < 2048 || ContextSize > 32768)
            throw new InvalidOperationException(
                $"ContextSize должен быть в диапазоне [2048; 32768]. Текущее: {ContextSize}");

        if (GpuLayers < 0)
            throw new InvalidOperationException("GpuLayers не может быть отрицательным.");

        if (Temperature < 0 || Temperature > 2)
            throw new InvalidOperationException(
                $"Temperature должен быть в диапазоне [0; 2]. Текущее: {Temperature}");

        if (MaxTokens < 100 || MaxTokens > 4096)
            throw new InvalidOperationException(
                $"MaxTokens должен быть в диапазоне [100; 4096]. Текущее: {MaxTokens}");

        // Верхняя граница поднята: на CPU модель 14B выдаёт ~2-6 токенов/с,
        // и 30 секунд на ответ физически не хватает.
        if (InferenceTimeoutMs < 500 || InferenceTimeoutMs > 900_000)
            throw new InvalidOperationException(
                $"InferenceTimeoutMs должен быть в диапазоне [500; 900000]. Текущее: {InferenceTimeoutMs}");

        if (MaxRetriesOnInvalidJson < 1 || MaxRetriesOnInvalidJson > 10)
            throw new InvalidOperationException(
                $"MaxRetriesOnInvalidJson должен быть в диапазоне [1; 10].");
    }
}
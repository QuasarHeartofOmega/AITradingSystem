﻿namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Конфигурация AI-модели Qwen 14B (FR-4, NFR-1.1).
/// </summary>
public sealed class AIConfig
{
    /// <summary>
    /// Путь к файлу модели в формате GGUF.
    /// </summary>
    public string ModelPath { get; set; } = "models/qwen-14b-q4_k_m.gguf";

    /// <summary>
    /// Размер контекстного окна (FR-4 ограничение).
    /// Ограничено 8192 для экономии VRAM.
    /// </summary>
    public int ContextSize { get; set; } = 8192;

    /// <summary>
    /// Количество слоев модели, размещаемых на GPU (FR-4.1).
    /// Для 12GB VRAM и Q4_K_M оптимально ~35.
    /// </summary>
    public int GpuLayers { get; set; } = 35;

    /// <summary>
    /// Temperature для генерации.
    /// Ниже = более детерминированные ответы (важно для JSON).
    /// </summary>
    public float Temperature { get; set; } = 0.3f;

    /// <summary>
    /// Top-P (nucleus sampling).
    /// </summary>
    public float TopP { get; set; } = 0.9f;

    /// <summary>
    /// Максимальное количество токенов в ответе (FR-4.3).
    /// </summary>
    public int MaxTokens { get; set; } = 500;

    /// <summary>
    /// Максимальное время инференса в мс (NFR-1.1).
    /// </summary>
    public int InferenceTimeoutMs { get; set; } = 2000;

    /// <summary>
    /// Количество попыток при невалидном JSON (FR-4.4).
    /// </summary>
    public int MaxRetriesOnInvalidJson { get; set; } = 3;

    /// <summary>
    /// Путь к нативной библиотеке llama (cuda).
    /// Если null — используется дефолтный из пакета LLamaSharp.Backend.Cuda12.
    /// </summary>
    public string? NativeLibraryPath { get; set; }

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(ModelPath))
            throw new InvalidOperationException("ModelPath не указан.");

        if (ContextSize < 2048 || ContextSize > 32768)
            throw new InvalidOperationException(
                $"ContextSize должен быть в диапазоне [2048; 32768]. Текущее: {ContextSize}");

        if (GpuLayers < 0)
            throw new InvalidOperationException("GpuLayers не может быть отрицательным.");

        if (Temperature < 0 || Temperature > 2)
            throw new InvalidOperationException(
                $"Temperature должен быть в диапазоне [0; 2]. Текущее: {Temperature}");

        if (MaxTokens < 100 || MaxTokens > 4096)
            throw new InvalidOperationException(
                $"MaxTokens должен быть в диапазоне [100; 4096]. Текущее: {MaxTokens}");

        if (InferenceTimeoutMs < 500 || InferenceTimeoutMs > 30_000)
            throw new InvalidOperationException(
                $"InferenceTimeoutMs должен быть в диапазоне [500; 30000].");

        if (MaxRetriesOnInvalidJson < 1 || MaxRetriesOnInvalidJson > 10)
            throw new InvalidOperationException(
                $"MaxRetriesOnInvalidJson должен быть в диапазоне [1; 10].");
    }
}
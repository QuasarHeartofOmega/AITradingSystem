namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Вычислительный бэкенд llama.cpp.
/// Auto   — выбрать по железу: NVIDIA → CUDA, AMD/Intel → Vulkan, иначе CPU.
/// Cuda12 — NVIDIA, CUDA 12 (LLamaSharp.Backend.Cuda12).
/// Cuda11 — NVIDIA, CUDA 11 (LLamaSharp.Backend.Cuda11).
/// Vulkan — универсальный GPU-бэкенд (AMD Radeon/ROCm-независимый, NVIDIA, Intel).
/// Cpu    — только CPU (LLamaSharp.Backend.Cpu).
/// </summary>
public enum AiBackend
{
    Auto = 0,
    Cpu = 1,
    Cuda12 = 2,
    Cuda11 = 3,
    Vulkan = 4
}

/// <summary>
/// Конфигурация AI-модели Qwen (FR-4, NFR-1.1).
/// </summary>
public sealed class AIConfig
{
    /// <summary>Путь к файлу модели в формате GGUF.</summary>
    public string ModelPath { get; set; } = "models/qwen3-14b-q4_k_m.gguf";

    /// <summary>Размер контекстного окна.</summary>
    public int ContextSize { get; set; } = 8192;

    /// <summary>
    /// Бэкенд инференса: Auto | Cpu | Cuda12 | Cuda11 | Vulkan.
    /// Auto определяет GPU по железу и откатывается на CPU, если GPU-библиотек нет.
    /// </summary>
    public string Backend { get; set; } = "Auto";

    /// <summary>
    /// Количество слоёв модели на GPU. -1 = все слои (рекомендуется для GPU),
    /// 0 = только CPU. При Backend=Auto и найденном GPU значение -1 подставляется автоматически.
    /// </summary>
    public int GpuLayers { get; set; } = -1;

    /// <summary>
    /// Количество потоков CPU. 0 = авто (по числу физических ядер).
    /// </summary>
    public int Threads { get; set; } = 0;

    /// <summary>
    /// Использовать memory-mapped загрузку весов (быстрее старт, меньше RAM).
    /// </summary>
    public bool UseMemorymap { get; set; } = true;

    /// <summary>
    /// Батч обработки промпта. Больше = быстрее на GPU, больше VRAM.
    /// </summary>
    public int BatchSize { get; set; } = 512;

    /// <summary>Temperature для генерации.</summary>
    public float Temperature { get; set; } = 0.3f;

    /// <summary>Top-P (nucleus sampling).</summary>
    public float TopP { get; set; } = 0.9f;

    /// <summary>Максимальное количество токенов в финальном ответе (без блока рассуждений).</summary>
    public int MaxTokens { get; set; } = 600;

    /// <summary>Максимальное время инференса в мс (NFR-1.1).</summary>
    public int InferenceTimeoutMs { get; set; } = 180_000;

    /// <summary>Количество попыток при невалидном JSON (FR-4.4).</summary>
    public int MaxRetriesOnInvalidJson { get; set; } = 3;

    /// <summary>
    /// Путь к нативной библиотеке llama.cpp: каталог с llama.dll/ggml*.dll
    /// или полный путь к llama.dll. Если null — поиск рядом с exe и в runtimes/&lt;rid&gt;/native.
    /// </summary>
    public string? NativeLibraryPath { get; set; }

    /// <summary>
    /// Режим рассуждений (thinking): модель сначала думает, затем выдаёт JSON.
    /// Снижает число ошибок в решении; блок рассуждений логируется в logs/ai-*.log.
    /// </summary>
    public bool EnableThinking { get; set; } = true;

    /// <summary>
    /// Бюджет токенов на рассуждения. Добавляется к MaxTokens при EnableThinking=true.
    /// </summary>
    public int ThinkingBudgetTokens { get; set; } = 1024;

    /// <summary>
    /// Повторно спрашивать модель с указанием ошибки, если JSON не распарсился
    /// («ремонт» ответа вместо слепого повтора того же промпта).
    /// </summary>
    public bool RepairInvalidJson { get; set; } = true;

    /// <summary>
    /// Минимальная уверенность сигнала, ниже которой он считается Hold.
    /// </summary>
    public decimal MinConfidence { get; set; } = 0.55m;

    /// <summary>Итоговый бэкенд с учётом значения по умолчанию.</summary>
    public AiBackend ResolvedBackend =>
        Enum.TryParse<AiBackend>(Backend?.Trim(), true, out var parsed) ? parsed : AiBackend.Auto;

    /// <summary>Сколько токенов разрешить генерации с учётом рассуждений.</summary>
    public int EffectiveMaxTokens => EnableThinking
        ? Math.Min(MaxTokens + ThinkingBudgetTokens, 8192)
        : MaxTokens;

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(ModelPath))
            throw new InvalidOperationException("ModelPath не указан.");

        if (ContextSize < 2048 || ContextSize > 131072)
            throw new InvalidOperationException(
                $"ContextSize должен быть в диапазоне [2048; 131072]. Текущее: {ContextSize}");

        if (GpuLayers < -1)
            throw new InvalidOperationException("GpuLayers должен быть >= -1 (-1 = все слои на GPU).");

        if (Threads < 0 || Threads > 512)
            throw new InvalidOperationException("Threads должен быть в диапазоне [0; 512].");

        if (BatchSize < 32 || BatchSize > 8192)
            throw new InvalidOperationException("BatchSize должен быть в диапазоне [32; 8192].");

        if (Temperature < 0 || Temperature > 2)
            throw new InvalidOperationException(
                $"Temperature должен быть в диапазоне [0; 2]. Текущее: {Temperature}");

        if (MaxTokens < 100 || MaxTokens > 4096)
            throw new InvalidOperationException(
                $"MaxTokens должен быть в диапазоне [100; 4096]. Текущее: {MaxTokens}");

        if (ThinkingBudgetTokens < 0 || ThinkingBudgetTokens > 8192)
            throw new InvalidOperationException("ThinkingBudgetTokens должен быть в диапазоне [0; 8192].");

        if (InferenceTimeoutMs < 500 || InferenceTimeoutMs > 900_000)
            throw new InvalidOperationException(
                $"InferenceTimeoutMs должен быть в диапазоне [500; 900000]. Текущее: {InferenceTimeoutMs}");

        if (MaxRetriesOnInvalidJson < 1 || MaxRetriesOnInvalidJson > 10)
            throw new InvalidOperationException("MaxRetriesOnInvalidJson должен быть в диапазоне [1; 10].");

        if (!string.IsNullOrWhiteSpace(Backend) &&
            !Enum.TryParse<AiBackend>(Backend.Trim(), true, out _))
            throw new InvalidOperationException(
                $"AI:Backend должен быть Auto, Cpu, Cuda12, Cuda11 или Vulkan. Текущее: {Backend}");

        if (MinConfidence < 0 || MinConfidence > 1)
            throw new InvalidOperationException("MinConfidence должен быть в диапазоне [0; 1].");
    }
}

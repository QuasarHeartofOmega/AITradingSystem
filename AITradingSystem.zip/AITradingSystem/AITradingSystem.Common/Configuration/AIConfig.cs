namespace AITradingSystem.Common.Configuration;

/// <summary>
/// Вычислительный бэкенд llama.cpp.
/// Auto   — выбрать по железу: NVIDIA → CUDA, AMD/Intel → Vulkan, иначе CPU.
/// Cuda12 — NVIDIA, CUDA 12 (LLamaSharp.Backend.Cuda12).
/// Cuda11 — NVIDIA, CUDA 11 (LLamaSharp.Backend.Cuda11).
/// Vulkan — универсальный GPU-бэкенд (AMD Radeon/ROCm-независимый, NVIDIA, Intel).
/// Cpu    — только CPU (LLamaSharp.Backend.Cpu).
/// </summary>
public enum AiBackend
{
    Auto = 0,
    Cpu = 1,
    Cuda12 = 2,
    Cuda11 = 3,
    Vulkan = 4
}

/// <summary>
/// Конфигурация AI-модели Qwen (FR-4, NFR-1.1).
/// </summary>
public sealed class AIConfig
{
    /// <summary>Путь к файлу модели в формате GGUF.</summary>
    public string ModelPath { get; set; } = "models/qwen3-14b-q4_k_m.gguf";

    /// <summary>Размер контекстного окна.</summary>
    public int ContextSize { get; set; } = 8192;

    /// <summary>
    /// Бэкенд инференса: Auto | Cpu | Cuda12 | Cuda11 | Vulkan.
    /// Auto определяет GPU по железу и откатывается на CPU, если GPU-библиотек нет.
    /// </summary>
    public string Backend { get; set; } = "Auto";

    /// <summary>
    /// Количество слоёв модели на GPU. -1 = все слои (рекомендуется для GPU),
    /// 0 = только CPU. При Backend=Auto и найденном GPU значение -1 подставляется автоматически.
    /// </summary>
    public int GpuLayers { get; set; } = -1;

    /// <summary>
    /// Количество потоков CPU. 0 = авто (по числу физических ядер).
    /// </summary>
    public int Threads { get; set; } = 0;

    /// <summary>
    /// Использовать memory-mapped загрузку весов (быстрее старт, меньше RAM).
    /// </summary>
    public bool UseMemorymap { get; set; } = true;

    /// <summary>
    /// Батч обработки промпта. Больше = быстрее на GPU, больше VRAM.
    /// </summary>
    public int BatchSize { get; set; } = 512;

    /// <summary>Temperature для генерации.</summary>
    public float Temperature { get; set; } = 0.3f;

    /// <summary>Top-P (nucleus sampling).</summary>
    public float TopP { get; set; } = 0.9f;

    /// <summary>Максимальное количество токенов в финальном ответе (без блока рассуждений).</summary>
    public int MaxTokens { get; set; } = 600;

    /// <summary>Максимальное время инференса в мс (NFR-1.1).</summary>
    public int InferenceTimeoutMs { get; set; } = 180_000;

    /// <summary>Количество попыток при невалидном JSON (FR-4.4).</summary>
    public int MaxRetriesOnInvalidJson { get; set; } = 3;

    /// <summary>
    /// Путь к нативной библиотеке llama.cpp: каталог с llama.dll/ggml*.dll
    /// или полный путь к llama.dll. Если null — поиск рядом с exe и в runtimes/&lt;rid&gt;/native.
    /// </summary>
    public string? NativeLibraryPath { get; set; }

    /// <summary>
    /// Режим рассуждений (thinking): модель сначала думает, затем выдаёт JSON.
    /// Снижает число ошибок в решении; блок рассуждений логируется в logs/ai-*.log.
    /// </summary>
    public bool EnableThinking { get; set; } = true;

    /// <summary>
    /// Бюджет токенов на рассуждения. Добавляется к MaxTokens при EnableThinking=true.
    /// Thinking НЕ отключается: урезаем только бюджет (1024 → 384), модель думает всегда.
    /// </summary>
    public int ThinkingBudgetTokens { get; set; } = 384;

    /// <summary>
    /// Повторно спрашивать модель с указанием ошибки, если JSON не распарсился
    /// («ремонт» ответа вместо слепого повтора того же промпта).
    /// </summary>
    public bool RepairInvalidJson { get; set; } = true;

    /// <summary>
    /// Минимальная уверенность сигнала, ниже которой он считается Hold.
    /// Применяется к FINAL confidence после калибратора (см. ConfidencePolicy).
    /// P2.4: значение по умолчанию — fallback «с потолка»; рабочий порог подбирается
    /// по expectancy после издержек на истории (ConfidenceThresholdTuner) и, при
    /// MinConfidenceAutoTuneEnabled=true, подставляется сюда в пределах коридора ниже.
    /// </summary>
    public decimal MinConfidence { get; set; } = 0.55m;

    // ------------------------------------------------------------------
    // P2.4. Подбор порога MinConfidence по expectancy после издержек
    // ------------------------------------------------------------------

    /// <summary>
    /// Разрешить контуру подбора порога по истории сделок (разбор, лог, метрики).
    /// Выключено — подбор не выполняется вовсе.
    /// </summary>
    public bool MinConfidenceTuneEnabled { get; set; } = true;

    /// <summary>
    /// Автоматически применять рекомендованный порог к MinConfidence.
    /// По умолчанию ВЫКЛ: контур только рекомендует, решение об изменении порога — за оператором.
    /// </summary>
    public bool MinConfidenceAutoTuneEnabled { get; set; } = false;

    /// <summary>Период разбора истории, минуты.</summary>
    public int MinConfidenceTuneIntervalMinutes { get; set; } = 60;

    /// <summary>Нижняя граница коридора подбора: ниже неё порог не опускается никогда.</summary>
    public decimal MinConfidenceFloor { get; set; } = 0.45m;

    /// <summary>Верхняя граница коридора подбора.</summary>
    public decimal MinConfidenceCeiling { get; set; } = 0.80m;

    /// <summary>Шаг сетки порогов при подборе.</summary>
    public decimal MinConfidenceTuneStep { get; set; } = 0.05m;

    /// <summary>Минимум пригодных сделок в истории, чтобы вообще что-то рекомендовать.</summary>
    public int MinConfidenceTuneMinTrades { get; set; } = 40;

    /// <summary>Минимум сделок выше порога-кандидата, чтобы точка считалась значимой.</summary>
    public int MinConfidenceTuneMinBucketTrades { get; set; } = 15;

    // ------------------------------------------------------------------
    // A7. GPU AutoFit / native / confidence policy
    // ------------------------------------------------------------------

    /// <summary>
    /// Авторасчёт GpuLayers/ContextSize по свободной VRAM и метаданным GGUF (A2/A5).
    /// false — использовать GpuLayers/ContextSize из конфига как есть (старое поведение).
    /// </summary>
    public bool AutoFitGpu { get; set; } = true;

    /// <summary>Запас VRAM (MiB) под рабочий стол Windows, драйвер и непредвиденные буферы.</summary>
    public int VramReserveMb { get; set; } = 1024;

    /// <summary>
    /// Минимум слоёв на GPU, при котором оффлоад имеет смысл.
    /// Если AutoFit насчитал меньше — сразу CPU + предупреждение (частичный оффлоад не окупается).
    /// </summary>
    public int MinGpuLayers { get; set; } = 8;

    /// <summary>Разрешить чистый откат на CPU при OOM/неудаче GPU-загрузки (с явной причиной в логе).</summary>
    public bool AllowCpuFallback { get; set; } = true;

    /// <summary>
    /// FlashAttention в llama.cpp: меньше VRAM под attention-буферы, быстрее префилл.
    /// Пробрасывается в ModelParams, если свойство доступно в LLamaSharp 0.30.
    /// </summary>
    public bool FlashAttention { get; set; } = true;

    /// <summary>Тип KV-кэша: F16 | Q8_0 (для расчёта VRAM и, если поддержано, для llama).</summary>
    public string KvCacheType { get; set; } = "F16";

    /// <summary>Уровень нативного лога llama.cpp (llama_log_set): Off | Error | Warn | Info | Debug.</summary>
    public string NativeLogLevel { get; set; } = "Info";

    /// <summary>
    /// Политика итоговой уверенности: ModelOnly | Blend | EngineOverride (см. B9 SignalCalibrator).
    /// Blend: final = w*model + (1-w)*engine_prior, где w = BlendModelWeight (P2.3, по умолчанию 0.7);
    /// дегенерат модели (HOLD conf≈0.45) → prior.
    /// </summary>
    public string ConfidencePolicy { get; set; } = "Blend";

    /// <summary>
    /// P2.3: вес уверенности модели в политике Blend; вес prior движка = 1 − BlendModelWeight.
    /// По умолчанию 0.7/0.3 в пользу независимой оценки модели: после P2.2 рубрика модели
    /// больше не пересчитывает prior, поэтому её мнение весит больше. 0.5 — прежнее поведение 50/50.
    /// На ModelOnly/EngineOverride и на дегенерат HOLD≈0.45 не влияет.
    /// </summary>
    public decimal BlendModelWeight { get; set; } = 0.7m;

    /// <summary>Итоговый бэкенд с учётом значения по умолчанию.</summary>
    public AiBackend ResolvedBackend =>
        Enum.TryParse<AiBackend>(Backend?.Trim(), true, out var parsed) ? parsed : AiBackend.Auto;

    /// <summary>Итоговая политика уверенности (невалидное значение → Blend).</summary>
    public ConfidencePolicy ResolvedConfidencePolicy =>
        Enum.TryParse<ConfidencePolicy>(ConfidencePolicy?.Trim(), true, out var parsed)
            ? parsed
            : Configuration.ConfidencePolicy.Blend;

    /// <summary>Сколько токенов разрешить генерации с учётом рассуждений.</summary>
    public int EffectiveMaxTokens => EnableThinking
        ? Math.Min(MaxTokens + ThinkingBudgetTokens, 8192)
        : MaxTokens;

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(ModelPath))
            throw new InvalidOperationException("ModelPath не указан.");

        if (ContextSize < 2048 || ContextSize > 131072)
            throw new InvalidOperationException(
                $"ContextSize должен быть в диапазоне [2048; 131072]. Текущее: {ContextSize}");

        if (GpuLayers < -1)
            throw new InvalidOperationException("GpuLayers должен быть >= -1 (-1 = все слои на GPU).");

        if (Threads < 0 || Threads > 512)
            throw new InvalidOperationException("Threads должен быть в диапазоне [0; 512].");

        if (BatchSize < 32 || BatchSize > 8192)
            throw new InvalidOperationException("BatchSize должен быть в диапазоне [32; 8192].");

        if (Temperature < 0 || Temperature > 2)
            throw new InvalidOperationException(
                $"Temperature должен быть в диапазоне [0; 2]. Текущее: {Temperature}");

        if (MaxTokens < 100 || MaxTokens > 4096)
            throw new InvalidOperationException(
                $"MaxTokens должен быть в диапазоне [100; 4096]. Текущее: {MaxTokens}");

        if (ThinkingBudgetTokens < 0 || ThinkingBudgetTokens > 8192)
            throw new InvalidOperationException("ThinkingBudgetTokens должен быть в диапазоне [0; 8192].");

        if (InferenceTimeoutMs < 500 || InferenceTimeoutMs > 900_000)
            throw new InvalidOperationException(
                $"InferenceTimeoutMs должен быть в диапазоне [500; 900000]. Текущее: {InferenceTimeoutMs}");

        if (MaxRetriesOnInvalidJson < 1 || MaxRetriesOnInvalidJson > 10)
            throw new InvalidOperationException("MaxRetriesOnInvalidJson должен быть в диапазоне [1; 10].");

        if (!string.IsNullOrWhiteSpace(Backend) &&
            !Enum.TryParse<AiBackend>(Backend.Trim(), true, out _))
            throw new InvalidOperationException(
                $"AI:Backend должен быть Auto, Cpu, Cuda12, Cuda11 или Vulkan. Текущее: {Backend}");

        if (MinConfidence < 0 || MinConfidence > 1)
            throw new InvalidOperationException("MinConfidence должен быть в диапазоне [0; 1].");

        if (VramReserveMb < 0 || VramReserveMb > 16384)
            throw new InvalidOperationException(
                $"VramReserveMb должен быть в диапазоне [0; 16384]. Текущее: {VramReserveMb}");

        if (MinGpuLayers < 0 || MinGpuLayers > 256)
            throw new InvalidOperationException(
                $"MinGpuLayers должен быть в диапазоне [0; 256]. Текущее: {MinGpuLayers}");

        if (!string.IsNullOrWhiteSpace(NativeLogLevel) &&
            NativeLogLevel.Trim().ToLowerInvariant() is not ("off" or "error" or "warn" or "warning" or "info" or "debug"))
            throw new InvalidOperationException(
                $"AI:NativeLogLevel должен быть Off, Error, Warn, Info или Debug. Текущее: {NativeLogLevel}");

        if (!string.IsNullOrWhiteSpace(KvCacheType) &&
            KvCacheType.Trim().ToUpperInvariant() is not ("F16" or "Q8_0" or "Q4_0"))
            throw new InvalidOperationException(
                $"AI:KvCacheType должен быть F16, Q8_0 или Q4_0. Текущее: {KvCacheType}");

        if (!string.IsNullOrWhiteSpace(ConfidencePolicy) &&
            !Enum.TryParse<ConfidencePolicy>(ConfidencePolicy.Trim(), true, out _))
            throw new InvalidOperationException(
                $"AI:ConfidencePolicy должен быть ModelOnly, Blend или EngineOverride. Текущее: {ConfidencePolicy}");

        if (BlendModelWeight < 0 || BlendModelWeight > 1)
            throw new InvalidOperationException(
                $"AI:BlendModelWeight должен быть в диапазоне [0; 1]. Текущее: {BlendModelWeight}");

        if (MinConfidenceFloor < 0 || MinConfidenceFloor > 1)
            throw new InvalidOperationException(
                $"AI:MinConfidenceFloor должен быть в диапазоне [0; 1]. Текущее: {MinConfidenceFloor}");

        if (MinConfidenceCeiling < MinConfidenceFloor || MinConfidenceCeiling > 1)
            throw new InvalidOperationException(
                $"AI:MinConfidenceCeiling должен быть в диапазоне [MinConfidenceFloor; 1]. Текущее: {MinConfidenceCeiling}");

        if (MinConfidenceTuneStep <= 0 || MinConfidenceTuneStep > 0.5m)
            throw new InvalidOperationException(
                $"AI:MinConfidenceTuneStep должен быть в диапазоне (0; 0.5]. Текущее: {MinConfidenceTuneStep}");

        if (MinConfidenceTuneIntervalMinutes < 1 || MinConfidenceTuneIntervalMinutes > 1440)
            throw new InvalidOperationException(
                $"AI:MinConfidenceTuneIntervalMinutes должен быть в диапазоне [1; 1440]. Текущее: {MinConfidenceTuneIntervalMinutes}");

        if (MinConfidenceTuneMinTrades < 10 || MinConfidenceTuneMinTrades > 100000)
            throw new InvalidOperationException(
                $"AI:MinConfidenceTuneMinTrades должен быть в диапазоне [10; 100000]. Текущее: {MinConfidenceTuneMinTrades}");

        if (MinConfidenceTuneMinBucketTrades < 5 || MinConfidenceTuneMinBucketTrades > MinConfidenceTuneMinTrades)
            throw new InvalidOperationException(
                $"AI:MinConfidenceTuneMinBucketTrades должен быть в диапазоне [5; MinConfidenceTuneMinTrades]. Текущее: {MinConfidenceTuneMinBucketTrades}");
    }
}

/// <summary>Политика итоговой уверенности сигнала (B9).</summary>
public enum ConfidencePolicy
{
    /// <summary>Как сейчас: уверенность модели без калибровки.</summary>
    ModelOnly = 0,

    /// <summary>final = w*model + (1-w)*engine_prior (w = AI:BlendModelWeight, по умолчанию 0.7); дегенерат модели → engine_prior.</summary>
    Blend = 1,

    /// <summary>final = engine_prior всегда (математика решает).</summary>
    EngineOverride = 2
}

﻿using System.Text.Json.Serialization;

namespace AITradingSystem.Data.Binance;

/// <summary>
/// DTO для WebSocket stream Binance.
/// Базовый класс для всех потоковых сообщений.
/// </summary>
public class BinanceStreamMessage
{
    [JsonPropertyName("e")]
    public string EventType { get; set; } = string.Empty;

    [JsonPropertyName("E")]
    public long EventTime { get; set; }

    [JsonPropertyName("s")]
    public string Symbol { get; set; } = string.Empty;
}

/// <summary>
/// Trade stream (агрегированные сделки).
/// </summary>
public sealed class BinanceTradeStream : BinanceStreamMessage
{
    [JsonPropertyName("t")]
    public long TradeId { get; set; }

    [JsonPropertyName("p")]
    public string Price { get; set; } = string.Empty;

    [JsonPropertyName("q")]
    public string Quantity { get; set; } = string.Empty;

    [JsonPropertyName("T")]
    public long TradeTime { get; set; }

    [JsonPropertyName("m")]
    public bool IsBuyerMaker { get; set; }
}

/// <summary>
/// Kline/Candlestick stream.
/// </summary>
public sealed class BinanceKlineStream : BinanceStreamMessage
{
    [JsonPropertyName("k")]
    public BinanceKlineData Kline { get; set; } = new();
}

public sealed class BinanceKlineData
{
    [JsonPropertyName("t")]
    public long OpenTime { get; set; }

    [JsonPropertyName("T")]
    public long CloseTime { get; set; }

    [JsonPropertyName("s")]
    public string Symbol { get; set; } = string.Empty;

    [JsonPropertyName("i")]
    public string Interval { get; set; } = string.Empty;

    [JsonPropertyName("o")]
    public string Open { get; set; } = string.Empty;

    [JsonPropertyName("c")]
    public string Close { get; set; } = string.Empty;

    [JsonPropertyName("h")]
    public string High { get; set; } = string.Empty;

    [JsonPropertyName("l")]
    public string Low { get; set; } = string.Empty;

    [JsonPropertyName("v")]
    public string Volume { get; set; } = string.Empty;

    [JsonPropertyName("q")]
    public string QuoteVolume { get; set; } = string.Empty;

    [JsonPropertyName("n")]
    public int TradesCount { get; set; }

    [JsonPropertyName("x")]
    public bool IsClosed { get; set; }
}

/// <summary>
/// Partial book depth stream (@depth20) — готовый снимок топ-20 уровней стакана.
/// Символ в payload отсутствует — берется из имени стрима.
/// </summary>
public sealed class BinancePartialDepthStream
{
    [JsonPropertyName("lastUpdateId")]
    public long LastUpdateId { get; set; }

    [JsonPropertyName("bids")]
    public List<List<string>> Bids { get; set; } = new();

    [JsonPropertyName("asks")]
    public List<List<string>> Asks { get; set; } = new();
}

/// <summary>
/// REST API: Order response.
/// </summary>
public sealed class BinanceOrderResponse
{
    [JsonPropertyName("symbol")]
    public string Symbol { get; set; } = string.Empty;

    [JsonPropertyName("orderId")]
    public long OrderId { get; set; }

    [JsonPropertyName("clientOrderId")]
    public string ClientOrderId { get; set; } = string.Empty;

    [JsonPropertyName("transactTime")]
    public long TransactTime { get; set; }

    [JsonPropertyName("price")]
    public string Price { get; set; } = string.Empty;

    [JsonPropertyName("origQty")]
    public string OrigQty { get; set; } = string.Empty;

    [JsonPropertyName("executedQty")]
    public string ExecutedQty { get; set; } = string.Empty;

    [JsonPropertyName("cummulativeQuoteQty")]
    public string CummulativeQuoteQty { get; set; } = string.Empty;

    [JsonPropertyName("status")]
    public string Status { get; set; } = string.Empty;

    [JsonPropertyName("timeInForce")]
    public string TimeInForce { get; set; } = string.Empty;

    [JsonPropertyName("type")]
    public string Type { get; set; } = string.Empty;

    [JsonPropertyName("side")]
    public string Side { get; set; } = string.Empty;

    [JsonPropertyName("fills")]
    public List<BinanceFill> Fills { get; set; } = new();
}

public sealed class BinanceFill
{
    [JsonPropertyName("price")]
    public string Price { get; set; } = string.Empty;

    [JsonPropertyName("qty")]
    public string Qty { get; set; } = string.Empty;

    [JsonPropertyName("commission")]
    public string Commission { get; set; } = string.Empty;

    [JsonPropertyName("commissionAsset")]
    public string CommissionAsset { get; set; } = string.Empty;
}

/// <summary>
/// REST API: Account information.
/// </summary>
public sealed class BinanceAccountInfo
{
    [JsonPropertyName("balances")]
    public List<BinanceBalance> Balances { get; set; } = new();

    [JsonPropertyName("updateTime")]
    public long UpdateTime { get; set; }
}

public sealed class BinanceBalance
{
    [JsonPropertyName("asset")]
    public string Asset { get; set; } = string.Empty;

    [JsonPropertyName("free")]
    public string Free { get; set; } = string.Empty;

    [JsonPropertyName("locked")]
    public string Locked { get; set; } = string.Empty;
}

/// <summary>
/// REST API: Exchange info (symbol filters).
/// </summary>
public sealed class BinanceExchangeInfo
{
    [JsonPropertyName("symbols")]
    public List<BinanceSymbolInfo> Symbols { get; set; } = new();
}

public sealed class BinanceSymbolInfo
{
    [JsonPropertyName("symbol")]
    public string Symbol { get; set; } = string.Empty;

    [JsonPropertyName("status")]
    public string Status { get; set; } = string.Empty;

    [JsonPropertyName("baseAsset")]
    public string BaseAsset { get; set; } = string.Empty;

    [JsonPropertyName("quoteAsset")]
    public string QuoteAsset { get; set; } = string.Empty;

    [JsonPropertyName("filters")]
    public List<BinanceFilter> Filters { get; set; } = new();

    public decimal StepSize => GetFilterValue("LOT_SIZE", "stepSize");
    public decimal MinQty => GetFilterValue("LOT_SIZE", "minQty");
    public decimal TickSize => GetFilterValue("PRICE_FILTER", "tickSize");
    public decimal MinNotional => GetFilterValue("NOTIONAL", "minNotional");

    private decimal GetFilterValue(string filterType, string fieldName)
    {
        var filter = Filters.FirstOrDefault(f => f.FilterType == filterType);
        if (filter is null) return 0;

        return fieldName switch
        {
            "stepSize" => filter.StepSize,
            "minQty" => filter.MinQty,
            "tickSize" => filter.TickSize,
            "minNotional" => filter.MinNotional,
            _ => 0
        };
    }
}

public sealed class BinanceFilter
{
    [JsonPropertyName("filterType")]
    public string FilterType { get; set; } = string.Empty;

    [JsonPropertyName("stepSize")]
    public decimal StepSize { get; set; }

    [JsonPropertyName("minQty")]
    public decimal MinQty { get; set; }

    [JsonPropertyName("tickSize")]
    public decimal TickSize { get; set; }

    [JsonPropertyName("minNotional")]
    public decimal MinNotional { get; set; }
}

/// <summary>
/// REST API: Historical klines.
/// </summary>
public sealed class BinanceKline
{
    public long OpenTime { get; set; }
    public decimal Open { get; set; }
    public decimal High { get; set; }
    public decimal Low { get; set; }
    public decimal Close { get; set; }
    public decimal Volume { get; set; }
    public long CloseTime { get; set; }
    public decimal QuoteVolume { get; set; }
    public int TradesCount { get; set; }
}
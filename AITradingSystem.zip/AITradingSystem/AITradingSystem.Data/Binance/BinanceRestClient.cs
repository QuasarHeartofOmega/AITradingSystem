﻿using System.Globalization;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Common.Security;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using Microsoft.Extensions.Logging;
using TaskExtensions = AITradingSystem.Common.Extensions.TaskExtensions; // ← ДОБАВИТЬ ЭТУ СТРОКУ


namespace AITradingSystem.Data.Binance;

/// <summary>
/// REST клиент Binance с retry-логикой (FR-6.4).
/// </summary>
public sealed class BinanceRestClient : IBinanceRestClient
{
    private readonly BinanceConfig _config;
    private readonly HttpClient _httpClient;
    private readonly ILogger<BinanceRestClient> _logger;
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public BinanceRestClient(
        BinanceConfig config,
        ILogger<BinanceRestClient> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(_config.RestBaseUrl),
            Timeout = TimeSpan.FromMilliseconds(_config.HttpTimeoutMs)
        };
        var decryptedKey = ApiKeyEncryptor.Decrypt(_config.EncryptedApiKey);
        if (!string.IsNullOrWhiteSpace(decryptedKey))
        {
            _httpClient.DefaultRequestHeaders.Add("X-MBX-APIKEY", decryptedKey);
        }
        else
        {
            _logger.LogWarning("API Key не задан или пуст. Работа возможна только в режиме чтения или Paper Trading.");
        }
    }

    public async Task<List<string>> GetValidSymbolsAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceExchangeInfo>(
            "/api/v3/exchangeInfo",
            HttpMethod.Get,
            signed: false,
            ct: ct);

        return response.Symbols
            .Where(s => s.Status == "TRADING")
            .Select(s => s.Symbol)
            .ToList();
    }

    public async Task<BinanceSymbolInfo?> GetSymbolInfoAsync(string symbol, CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceExchangeInfo>(
            "/api/v3/exchangeInfo",
            HttpMethod.Get,
            signed: false,
            ct: ct);

        return response.Symbols.FirstOrDefault(s =>
            s.Symbol.Equals(symbol, StringComparison.OrdinalIgnoreCase));
    }

    public async Task<List<OHLCV>> GetKlinesAsync(
        string symbol,
        string interval,
        int limit,
        CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&interval={interval}&limit={limit}";
        // Binance возвращает массив массивов со смешанными типами (long + string),
        // поэтому парсим через JsonElement, а не Convert.ToXxx (JsonElement не IConvertible).
        var response = await SendRequestAsync<List<JsonElement[]>>(
            $"/api/v3/klines?{query}",
            HttpMethod.Get,
            signed: false,
            ct: ct);

        return response.Select(k => new OHLCV
        {
            Symbol = symbol,
            OpenTime = DateTimeExtensions.FromUnixMilliseconds(k[0].GetInt64()),
            Open = decimal.Parse(k[1].GetString()!, CultureInfo.InvariantCulture),
            High = decimal.Parse(k[2].GetString()!, CultureInfo.InvariantCulture),
            Low = decimal.Parse(k[3].GetString()!, CultureInfo.InvariantCulture),
            Close = decimal.Parse(k[4].GetString()!, CultureInfo.InvariantCulture),
            Volume = decimal.Parse(k[5].GetString()!, CultureInfo.InvariantCulture),
            CloseTime = DateTimeExtensions.FromUnixMilliseconds(k[6].GetInt64()),
            QuoteVolume = decimal.Parse(k[7].GetString()!, CultureInfo.InvariantCulture),
            TradesCount = k[8].GetInt32()
        }).ToList();
    }

    public async Task<AccountBalance> GetAccountBalanceAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceAccountInfo>(
            "/api/v3/account",
            HttpMethod.Get,
            signed: true,
            ct: ct);

        var balance = new AccountBalance
        {
            Timestamp = DateTime.UtcNow
        };

        foreach (var b in response.Balances)
        {
            var free = decimal.Parse(b.Free, CultureInfo.InvariantCulture);
            var locked = decimal.Parse(b.Locked, CultureInfo.InvariantCulture);

            if (free > 0 || locked > 0)
            {
                balance.UpdateAsset(b.Asset, free, locked);
            }
        }

        return balance;
    }

    public async Task<Order> PlaceOrderAsync(
        string symbol,
        OrderSide side,
        decimal quantity,
        decimal price,
        bool postOnly = true,
        CancellationToken ct = default)
    {
        // Post-Only на споте Binance — это тип ордера LIMIT_MAKER
        // (ордер отклоняется, если исполнился бы как taker).
        var queryParams = new Dictionary<string, string>
        {
            ["symbol"] = symbol,
            ["side"] = side.ToString().ToUpper(),
            ["type"] = postOnly ? "LIMIT_MAKER" : "LIMIT",
            ["quantity"] = quantity.ToInvariantString(),
            ["price"] = price.ToInvariantString()
        };

        if (!postOnly)
        {
            queryParams["timeInForce"] = "GTC";
        }

        var query = string.Join("&", queryParams.Select(p => $"{p.Key}={p.Value}"));

        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}",
            HttpMethod.Post,
            signed: true,
            ct: ct);

        return MapToOrder(response);
    }

    public async Task<Order> PlaceMarketOrderAsync(
        string symbol,
        OrderSide side,
        decimal quantity,
        CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&side={side.ToString().ToUpper()}&type=MARKET&quantity={quantity.ToInvariantString()}";

        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}",
            HttpMethod.Post,
            signed: true,
            ct: ct);

        return MapToOrder(response);
    }

    public async Task CancelOrderAsync(string symbol, long orderId, CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&orderId={orderId}";
        await SendRequestAsync<object>(
            $"/api/v3/order?{query}",
            HttpMethod.Delete,
            signed: true,
            ct: ct);
    }

    public async Task<Order> GetOrderAsync(string symbol, long orderId, CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&orderId={orderId}";
        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}",
            HttpMethod.Get,
            signed: true,
            ct: ct);

        return MapToOrder(response);
    }

    public async Task<List<Order>> GetOpenOrdersAsync(string? symbol = null, CancellationToken ct = default)
    {
        var query = symbol != null ? $"symbol={symbol}" : string.Empty;
        var response = await SendRequestAsync<List<BinanceOrderResponse>>(
            $"/api/v3/openOrders?{query}",
            HttpMethod.Get,
            signed: true,
            ct: ct);

        return response.Select(MapToOrder).ToList();
    }

    private async Task<T> SendRequestAsync<T>(
        string endpoint,
        HttpMethod method,
        bool signed,
        CancellationToken ct)
    {
        var url = endpoint;

        if (signed)
        {
            var timestamp = DateTime.UtcNow.ToUnixMilliseconds();
            var separator = url.Contains('?') ? "&" : "?";

            // Явно указываем recvWindow=60000 (60 секунд) для защиты от сетевых задержек и ошибки -1021
            url = $"{url}{separator}timestamp={timestamp}&recvWindow=60000";

            var signature = CreateSignature(url.Contains('?')
                ? url.Substring(url.IndexOf('?') + 1)
                : string.Empty);
            url = $"{url}&signature={signature}";
        }

        return await TaskExtensions.RetryAsync(
            async () =>
            {
                var request = new HttpRequestMessage(method, url);
                var response = await _httpClient.SendAsync(request, ct);

                var content = await response.Content.ReadAsStringAsync(ct);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Binance API error: {StatusCode} {Content}",
                        response.StatusCode, content);
                    throw new HttpRequestException($"Binance API error: {content}");
                }

                return JsonSerializer.Deserialize<T>(content, _jsonOptions)
                    ?? throw new InvalidOperationException("Response is null");
            },
            _config.MaxRetries,
            _config.RetryBaseDelayMs,
            onRetry: (attempt, ex) =>
            {
                _logger.LogWarning(ex, "Retry attempt {Attempt} for {Endpoint}", attempt, endpoint);
            },
            ct: ct);
    }

    private string CreateSignature(string queryString)
    {
        var apiSecret = ApiKeyEncryptor.Decrypt(_config.EncryptedApiSecret);
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(apiSecret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(queryString));
        return BitConverter.ToString(hash).Replace("-", "").ToLower();
    }

    private Order MapToOrder(BinanceOrderResponse response)
    {
        return new Order
        {
            Id = response.OrderId.ToString(),
            ClientOrderId = response.ClientOrderId,
            Symbol = response.Symbol,
            Side = response.Side.ToLower() == "buy" ? OrderSide.Buy : OrderSide.Sell,
            Type = OrderType.Limit,
            Status = MapOrderStatus(response.Status),
            Price = decimal.Parse(response.Price, CultureInfo.InvariantCulture),
            OriginalQuantity = decimal.Parse(response.OrigQty, CultureInfo.InvariantCulture),
            ExecutedQuantity = decimal.Parse(response.ExecutedQty, CultureInfo.InvariantCulture),
            FilledQuoteQuantity = decimal.Parse(response.CummulativeQuoteQty, CultureInfo.InvariantCulture),
            BinanceOrderId = response.OrderId,
            CreatedAt = DateTimeExtensions.FromUnixMilliseconds(response.TransactTime),
            Commission = response.Fills?.Sum(f => decimal.Parse(f.Commission, CultureInfo.InvariantCulture)) ?? 0m,
            CommissionAsset = response.Fills?.FirstOrDefault()?.CommissionAsset ?? "USDT"
        };
    }

    private OrderStatus MapOrderStatus(string status)
    {
        return status.ToUpper() switch
        {
            "NEW" => OrderStatus.New,
            "PARTIALLY_FILLED" => OrderStatus.PartiallyFilled,
            "FILLED" => OrderStatus.Filled,
            "CANCELED" => OrderStatus.Canceled,
            "REJECTED" => OrderStatus.Rejected,
            "EXPIRED" => OrderStatus.Expired,
            _ => OrderStatus.New
        };
    }
}
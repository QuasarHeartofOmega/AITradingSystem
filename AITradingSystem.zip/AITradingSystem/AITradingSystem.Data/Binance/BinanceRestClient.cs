using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Common.Logging;
using AITradingSystem.Common.Security;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Data.Binance;

/// <summary>
/// REST клиент Binance (FR-6.4) с поддержкой Live / Spot Testnet / Demo Mode (demo.binance.com).
///
/// Что важно в парсинге:
///  - klines — массив массивов со смешанными типами (long + string), читаем через JsonElement;
///  - exchangeInfo.filters — числа приходят строками, включён AllowReadingFromString;
///  - ошибки API разбираются как {"code":..,"msg":..}, ретраи только для транзиентных сбоев;
///  - время подписи синхронизируется с /api/v3/time (иначе -1021).
/// Каждый запрос/ответ пишется в logs/exchange-*.log.
/// </summary>
public sealed class BinanceRestClient : IBinanceRestClient, IDisposable
{
    private readonly BinanceConfig _config;
    private readonly HttpClient _httpClient;
    private readonly ILogger<BinanceRestClient> _logger;
    private readonly string? _apiKey;
    private readonly string? _apiSecret;
    private readonly SemaphoreSlim _timeSyncLock = new(1, 1);

    private long _serverTimeOffsetMs;
    private bool _timeSynced;

    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        NumberHandling = System.Text.Json.Serialization.JsonNumberHandling.AllowReadingFromString
    };

    public BinanceRestClient(
        BinanceConfig config,
        ILogger<BinanceRestClient> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(_config.RestBaseUrl),
            Timeout = TimeSpan.FromMilliseconds(_config.HttpTimeoutMs)
        };
        _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("AITradingSystem/1.0");

        _apiKey = TryDecrypt(_config.EncryptedApiKey);
        _apiSecret = TryDecrypt(_config.EncryptedApiSecret);

        if (!string.IsNullOrWhiteSpace(_apiKey))
            _httpClient.DefaultRequestHeaders.Add("X-MBX-APIKEY", _apiKey);
        else
            _logger.LogWarning(
                "API Key не задан. Окружение {Env}: доступны только публичные данные и Paper Trading.",
                _config.ResolvedEnvironment);

        ExchangeLog.Environment(_config.ResolvedEnvironment.ToString(), _config.RestBaseUrl, _config.MarketStreamBaseUrl);
    }

    /// <summary>Текущее окружение (Live/Testnet/Demo).</summary>
    public string EnvironmentName => _config.ResolvedEnvironment.ToString();

    private string? TryDecrypt(string encrypted)
    {
        if (string.IsNullOrWhiteSpace(encrypted)) return null;

        try
        {
            var value = ApiKeyEncryptor.Decrypt(encrypted);
            return string.IsNullOrWhiteSpace(value) ? null : value;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Не удалось расшифровать API-ключ (DPAPI привязан к пользователю Windows). " +
                "Перезашифруйте ключ через SecretEncryptor на этой машине.");
            return null;
        }
    }

    public async Task<List<string>> GetValidSymbolsAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceExchangeInfo>(
            "/api/v3/exchangeInfo", HttpMethod.Get, signed: false, ct: ct, marketData: true);

        return response.Symbols
            .Where(s => string.Equals(s.Status, "TRADING", StringComparison.OrdinalIgnoreCase))
            .Select(s => s.Symbol)
            .ToList();
    }

    public async Task<BinanceSymbolInfo?> GetSymbolInfoAsync(string symbol, CancellationToken ct = default)
    {
        // symbols=["BTCUSDT"] — точечный запрос вместо всего exchangeInfo (~2 МБ).
        var query = $"symbols=%5B%22{Uri.EscapeDataString(symbol.ToUpperInvariant())}%22%5D";
        var response = await SendRequestAsync<BinanceExchangeInfo>(
            $"/api/v3/exchangeInfo?{query}", HttpMethod.Get, signed: false, ct: ct, marketData: true);

        var info = response.Symbols.FirstOrDefault(s =>
            s.Symbol.Equals(symbol, StringComparison.OrdinalIgnoreCase));

        if (info is null)
            _logger.LogWarning("Символ {Symbol} не найден в exchangeInfo ({Env})", symbol, EnvironmentName);
        else
            _logger.LogDebug(
                "Фильтры {Symbol}: step={Step} tick={Tick} minQty={MinQty} minNotional={MinNotional}",
                symbol, info.StepSize, info.TickSize, info.MinQty, info.MinNotional);

        return info;
    }

    public async Task<List<OHLCV>> GetKlinesAsync(
        string symbol,
        string interval,
        int limit,
        CancellationToken ct = default)
    {
        limit = Math.Clamp(limit, 1, 1000);
        var query = $"symbol={symbol.ToUpperInvariant()}&interval={interval}&limit={limit}";

        var response = await SendRequestAsync<List<JsonElement[]>>(
            $"/api/v3/klines?{query}", HttpMethod.Get, signed: false, ct: ct, marketData: true);

        var result = new List<OHLCV>(response.Count);
        var skipped = 0;

        foreach (var k in response)
        {
            if (k.Length < 9)
            {
                skipped++;
                continue;
            }

            try
            {
                result.Add(new OHLCV
                {
                    Symbol = symbol.ToUpperInvariant(),
                    OpenTime = DateTimeExtensions.FromUnixMilliseconds(ReadInt64(k[0])),
                    Open = ReadDecimal(k[1]),
                    High = ReadDecimal(k[2]),
                    Low = ReadDecimal(k[3]),
                    Close = ReadDecimal(k[4]),
                    Volume = ReadDecimal(k[5]),
                    CloseTime = DateTimeExtensions.FromUnixMilliseconds(ReadInt64(k[6])),
                    QuoteVolume = ReadDecimal(k[7]),
                    TradesCount = (int)ReadInt64(k[8])
                });
            }
            catch (Exception ex)
            {
                skipped++;
                _logger.LogWarning(ex, "Пропущена некорректная свеча {Symbol}", symbol);
            }
        }

        if (skipped > 0)
            _logger.LogWarning("Klines {Symbol}: пропущено {Skipped} некорректных строк из {Total}",
                symbol, skipped, response.Count);

        _logger.LogDebug("Klines {Symbol} {Interval}: получено {Count} свечей, последняя закрыта={Closed}",
            symbol, interval, result.Count, result.Count > 0 && result[^1].IsClosed);

        return result;
    }

    public async Task<AccountBalance> GetAccountBalanceAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceAccountInfo>(
            "/api/v3/account", HttpMethod.Get, signed: true, ct: ct);

        var balance = new AccountBalance { Timestamp = DateTime.UtcNow };

        foreach (var b in response.Balances)
        {
            var free = ParseDecimal(b.Free);
            var locked = ParseDecimal(b.Locked);

            if (free > 0 || locked > 0)
                balance.UpdateAsset(b.Asset, free, locked);
        }

        _logger.LogInformation("Баланс {Env}: {Usdt} USDT доступно", EnvironmentName, balance.AvailableUSDT);
        return balance;
    }

    public async Task<Order> PlaceOrderAsync(
        string symbol,
        OrderSide side,
        decimal quantity,
        decimal price,
        bool postOnly = true,
        CancellationToken ct = default)
    {
        var queryParams = new Dictionary<string, string>
        {
            ["symbol"] = symbol.ToUpperInvariant(),
            ["side"] = side.ToString().ToUpperInvariant(),
            // Post-Only на споте — LIMIT_MAKER: ордер отклоняется, если исполнился бы как taker.
            ["type"] = postOnly ? "LIMIT_MAKER" : "LIMIT",
            ["quantity"] = quantity.ToInvariantString(),
            ["price"] = price.ToInvariantString(),
            ["newOrderRespType"] = "FULL"
        };

        if (!postOnly)
            queryParams["timeInForce"] = "GTC";

        var query = BuildQuery(queryParams);

        ExchangeLog.Order("SUBMIT", symbol, side.ToString(), quantity, price, postOnly ? "LIMIT_MAKER" : "LIMIT GTC");

        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}", HttpMethod.Post, signed: true, ct: ct);

        var order = MapToOrder(response);
        ExchangeLog.Order("ACCEPTED", symbol, side.ToString(), order.ExecutedQuantity, order.Price,
            $"id={order.Id} status={order.Status} filled={order.FillPercent:F1}%");
        return order;
    }

    public async Task<Order> PlaceMarketOrderAsync(
        string symbol,
        OrderSide side,
        decimal quantity,
        CancellationToken ct = default)
    {
        var query = BuildQuery(new Dictionary<string, string>
        {
            ["symbol"] = symbol.ToUpperInvariant(),
            ["side"] = side.ToString().ToUpperInvariant(),
            ["type"] = "MARKET",
            ["quantity"] = quantity.ToInvariantString(),
            ["newOrderRespType"] = "FULL"
        });

        ExchangeLog.Order("SUBMIT-MARKET", symbol, side.ToString(), quantity, 0m);

        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}", HttpMethod.Post, signed: true, ct: ct);

        var order = MapToOrder(response);
        ExchangeLog.Order("FILLED-MARKET", symbol, side.ToString(), order.ExecutedQuantity,
            order.AverageFillPrice ?? 0m, $"id={order.Id} status={order.Status}");
        return order;
    }

    public async Task CancelOrderAsync(string symbol, long orderId, CancellationToken ct = default)
    {
        var query = $"symbol={symbol.ToUpperInvariant()}&orderId={orderId}";
        await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}", HttpMethod.Delete, signed: true, ct: ct);

        ExchangeLog.Order("CANCELED", symbol, "-", 0m, 0m, $"id={orderId}");
    }

    public async Task<Order> GetOrderAsync(string symbol, long orderId, CancellationToken ct = default)
    {
        var query = $"symbol={symbol.ToUpperInvariant()}&orderId={orderId}";
        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}", HttpMethod.Get, signed: true, ct: ct);

        return MapToOrder(response);
    }

    public async Task<List<Order>> GetOpenOrdersAsync(string? symbol = null, CancellationToken ct = default)
    {
        var query = symbol != null ? $"symbol={symbol.ToUpperInvariant()}" : string.Empty;
        var url = string.IsNullOrEmpty(query) ? "/api/v3/openOrders" : $"/api/v3/openOrders?{query}";

        var response = await SendRequestAsync<List<BinanceOrderResponse>>(
            url, HttpMethod.Get, signed: true, ct: ct);

        return response.Select(MapToOrder).ToList();
    }

    /// <summary>Серверное время биржи (для синхронизации подписи).</summary>
    public async Task<long> GetServerTimeAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceServerTime>(
            "/api/v3/time", HttpMethod.Get, signed: false, ct: ct, marketData: true);
        return response.ServerTime;
    }

    private async Task EnsureTimeSyncedAsync(CancellationToken ct)
    {
        if (!_config.SyncServerTime || _timeSynced) return;

        await _timeSyncLock.WaitAsync(ct);
        try
        {
            if (_timeSynced) return;

            var localBefore = DateTime.UtcNow.ToUnixMilliseconds();
            var serverTime = await GetServerTimeAsync(ct);
            var localAfter = DateTime.UtcNow.ToUnixMilliseconds();
            var latency = (localAfter - localBefore) / 2;

            _serverTimeOffsetMs = serverTime - localBefore - latency;
            _timeSynced = true;

            _logger.LogInformation("Синхронизация времени с Binance: смещение {Offset} мс (RTT {Rtt} мс)",
                _serverTimeOffsetMs, localAfter - localBefore);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось синхронизировать время с сервером — используем локальные часы");
            _timeSynced = true; // не блокируем торговлю из-за недоступности /time
        }
        finally
        {
            _timeSyncLock.Release();
        }
    }

    private async Task<T> SendRequestAsync<T>(
        string endpoint,
        HttpMethod method,
        bool signed,
        CancellationToken ct,
        bool marketData = false)
    {
        if (signed && string.IsNullOrWhiteSpace(_apiSecret))
            throw new InvalidOperationException(
                $"Для подписанных запросов нужен API Secret (окружение {EnvironmentName}). " +
                "Введите ключи в настройках или включите Paper Trading.");

        if (signed)
            await EnsureTimeSyncedAsync(ct);

        // Публичные рыночные данные можно брать с mainnet (актуально для testnet).
        var absoluteBase = marketData && _config.UseMainnetMarketData
            ? _config.MarketRestBaseUrl
            : _config.RestBaseUrl;

        var attempt = 0;
        var maxAttempts = Math.Max(1, _config.MaxRetries + 1);
        Exception? lastError = null;

        while (attempt < maxAttempts)
        {
            ct.ThrowIfCancellationRequested();
            attempt++;

            var url = endpoint;
            if (signed)
            {
                var timestamp = DateTime.UtcNow.ToUnixMilliseconds() + _serverTimeOffsetMs;
                var separator = url.Contains('?') ? "&" : "?";
                url = $"{url}{separator}timestamp={timestamp}&recvWindow={_config.RecvWindowMs}";
                var payload = url[(url.IndexOf('?') + 1)..];
                url = $"{url}&signature={CreateSignature(payload)}";
            }

            var fullUrl = $"{absoluteBase.TrimEnd('/')}{url}";
            var sw = Stopwatch.StartNew();

            try
            {
                using var request = new HttpRequestMessage(method, new Uri(fullUrl));
                ExchangeLog.Request(method.Method, fullUrl);

                using var response = await _httpClient.SendAsync(request, ct);
                var content = await response.Content.ReadAsStringAsync(ct);
                sw.Stop();

                ExchangeLog.Response(method.Method, fullUrl, (int)response.StatusCode,
                    sw.Elapsed.TotalMilliseconds, content);

                if (response.IsSuccessStatusCode)
                {
                    var parsed = JsonSerializer.Deserialize<T>(content, _jsonOptions);
                    if (parsed is null)
                        throw new InvalidOperationException($"Binance вернул пустой/некорректный JSON для {endpoint}");
                    return parsed;
                }

                var (apiCode, apiMessage) = ParseApiError(content);
                ExchangeLog.ApiError(method.Method, fullUrl, (int)response.StatusCode, content, apiCode, apiMessage);

                // -1021: часы уехали — пересинхронизируем и повторим.
                if (apiCode == -1021)
                {
                    _timeSynced = false;
                    await EnsureTimeSyncedAsync(ct);
                }

                var transient = IsTransient(response.StatusCode, apiCode);
                var error = new BinanceApiException((int)response.StatusCode, apiCode, apiMessage, content);

                if (!transient || attempt >= maxAttempts)
                    throw error;

                lastError = error;
                var delay = GetRetryDelay(attempt, response);
                ExchangeLog.Retry(fullUrl, attempt, maxAttempts, $"{(int)response.StatusCode} {apiMessage}");
                await Task.Delay(delay, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch (BinanceApiException)
            {
                throw;
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException)
            {
                sw.Stop();
                lastError = ex;

                if (attempt >= maxAttempts)
                {
                    _logger.LogError(ex, "Запрос {Endpoint} провалился после {Attempts} попыток", endpoint, attempt);
                    throw;
                }

                var delay = TimeSpan.FromMilliseconds(_config.RetryBaseDelayMs * Math.Pow(2, attempt - 1));
                ExchangeLog.Retry(fullUrl, attempt, maxAttempts, ex.Message);
                await Task.Delay(delay, ct);
            }
        }

        throw lastError ?? new InvalidOperationException($"Запрос {endpoint} не выполнен");
    }

    private TimeSpan GetRetryDelay(int attempt, HttpResponseMessage response)
    {
        if (response.Headers.TryGetValues("Retry-After", out var values))
        {
            var raw = values.FirstOrDefault();
            if (int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var seconds) && seconds > 0)
                return TimeSpan.FromSeconds(Math.Min(seconds, 120));
        }

        return TimeSpan.FromMilliseconds(Math.Min(_config.RetryBaseDelayMs * Math.Pow(2, attempt - 1), 30_000));
    }

    private static bool IsTransient(HttpStatusCode status, int? apiCode)
    {
        if (status == HttpStatusCode.TooManyRequests || (int)status == 418) return true;
        if ((int)status >= 500) return true;

        // -1000/-1001/-1003/-1006/-1007 — внутренние/сетевые/лимитные ошибки Binance.
        return apiCode is -1000 or -1001 or -1003 or -1006 or -1007;
    }

    private static (int? Code, string? Message) ParseApiError(string content)
    {
        try
        {
            using var doc = JsonDocument.Parse(content);
            if (doc.RootElement.ValueKind != JsonValueKind.Object) return (null, null);

            int? code = doc.RootElement.TryGetProperty("code", out var c) && c.TryGetInt32(out var ci) ? ci : null;
            string? msg = doc.RootElement.TryGetProperty("msg", out var m) ? m.GetString() : null;
            return (code, msg);
        }
        catch (JsonException)
        {
            return (null, null);
        }
    }

    private string CreateSignature(string queryString)
    {
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(_apiSecret ?? string.Empty));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(queryString));
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static string BuildQuery(Dictionary<string, string> parameters) =>
        string.Join("&", parameters.Select(p => $"{p.Key}={Uri.EscapeDataString(p.Value)}"));

    private Order MapToOrder(BinanceOrderResponse response)
    {
        var executed = ParseDecimal(response.ExecutedQty);
        var quote = ParseDecimal(response.CummulativeQuoteQty);
        var commission = response.Fills?.Sum(f => ParseDecimal(f.Commission)) ?? 0m;

        // Если биржа не прислала cummulativeQuoteQty (некоторые площадки/типы),
        // считаем среднюю цену по fills.
        if (quote <= 0 && response.Fills is { Count: > 0 })
        {
            quote = response.Fills.Sum(f => ParseDecimal(f.Price) * ParseDecimal(f.Qty));
            if (executed <= 0)
                executed = response.Fills.Sum(f => ParseDecimal(f.Qty));
        }

        return new Order
        {
            Id = response.OrderId.ToString(CultureInfo.InvariantCulture),
            ClientOrderId = response.ClientOrderId,
            Symbol = response.Symbol,
            Side = string.Equals(response.Side, "BUY", StringComparison.OrdinalIgnoreCase) ? OrderSide.Buy : OrderSide.Sell,
            Type = MapOrderType(response.Type),
            Status = MapOrderStatus(response.Status),
            Price = ParseDecimal(response.Price),
            OriginalQuantity = ParseDecimal(response.OrigQty),
            ExecutedQuantity = executed,
            FilledQuoteQuantity = quote,
            BinanceOrderId = response.OrderId,
            CreatedAt = response.TransactTime > 0
                ? DateTimeExtensions.FromUnixMilliseconds(response.TransactTime)
                : DateTime.UtcNow,
            Commission = commission,
            CommissionAsset = response.Fills?.FirstOrDefault()?.CommissionAsset ?? string.Empty,
            IsPostOnly = string.Equals(response.Type, "LIMIT_MAKER", StringComparison.OrdinalIgnoreCase)
        };
    }

    private static OrderType MapOrderType(string type) => type.ToUpperInvariant() switch
    {
        "MARKET" => OrderType.Market,
        "STOP_LOSS" or "STOP_LOSS_LIMIT" or "TAKE_PROFIT" or "TAKE_PROFIT_LIMIT" => OrderType.StopLoss,
        _ => OrderType.Limit
    };

    private static OrderStatus MapOrderStatus(string status) => status.ToUpperInvariant() switch
    {
        "NEW" => OrderStatus.New,
        "PARTIALLY_FILLED" => OrderStatus.PartiallyFilled,
        "FILLED" => OrderStatus.Filled,
        "CANCELED" or "PENDING_CANCEL" => OrderStatus.Canceled,
        "REJECTED" => OrderStatus.Rejected,
        "EXPIRED" or "EXPIRED_IN_MATCH" => OrderStatus.Expired,
        _ => OrderStatus.New
    };

    /// <summary>Binance отдаёт числа и строками, и числами — читаем оба варианта.</summary>
    private static decimal ReadDecimal(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Number => element.GetDecimal(),
        JsonValueKind.String => ParseDecimal(element.GetString()),
        _ => 0m
    };

    private static long ReadInt64(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.Number => element.GetInt64(),
        JsonValueKind.String => long.TryParse(element.GetString(), NumberStyles.Integer,
            CultureInfo.InvariantCulture, out var v) ? v : 0L,
        _ => 0L
    };

    private static decimal ParseDecimal(string? text) =>
        decimal.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : 0m;

    public void Dispose()
    {
        _httpClient.Dispose();
        _timeSyncLock.Dispose();
    }
}

/// <summary>Ошибка Binance API с кодом и текстом (для корректной обработки в исполнителе ордеров).</summary>
public sealed class BinanceApiException : HttpRequestException
{
    public int HttpStatus { get; }
    public int? ApiCode { get; }
    public string ApiMessage { get; }
    public string RawBody { get; }

    public BinanceApiException(int httpStatus, int? apiCode, string? apiMessage, string rawBody)
        : base($"Binance API error {(int)httpStatus} code={apiCode?.ToString(CultureInfo.InvariantCulture) ?? "-"}: {apiMessage}")
    {
        HttpStatus = httpStatus;
        ApiCode = apiCode;
        ApiMessage = apiMessage ?? string.Empty;
        RawBody = rawBody;
    }

    /// <summary>Нарушение Post-Only (ордер исполнился бы как taker).</summary>
    public bool IsPostOnlyRejection =>
        ApiCode == -2010 && ApiMessage.Contains("post only", StringComparison.OrdinalIgnoreCase);

    /// <summary>Недостаточно средств.</summary>
    public bool IsInsufficientBalance => ApiCode == -2010 || ApiCode == -1013;
}

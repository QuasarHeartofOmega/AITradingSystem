﻿using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Common.Security;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using Microsoft.Extensions.Logging;
using TaskExtensions = AITradingSystem.Common.Extensions.TaskExtensions; // ← ДОБАВИТЬ ЭТУ СТРОКУ


namespace AITradingSystem.Data.Binance;

/// <summary>
/// REST клиент Binance с retry-логикой (FR-6.4).
/// </summary>
public sealed class BinanceRestClient : IBinanceRestClient
{
    private readonly BinanceConfig _config;
    private readonly HttpClient _httpClient;
    private readonly ILogger<BinanceRestClient> _logger;
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public BinanceRestClient(
        BinanceConfig config,
        ILogger<BinanceRestClient> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(_config.RestBaseUrl),
            Timeout = TimeSpan.FromMilliseconds(_config.HttpTimeoutMs)
        };
        var decryptedKey = ApiKeyEncryptor.Decrypt(_config.EncryptedApiKey);
        if (!string.IsNullOrWhiteSpace(decryptedKey))
        {
            _httpClient.DefaultRequestHeaders.Add("X-MBX-APIKEY", decryptedKey);
        }
        else
        {
            _logger.LogWarning("API Key не задан или пуст. Работа возможна только в режиме чтения или Paper Trading.");
        }
    }

    public async Task<List<string>> GetValidSymbolsAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceExchangeInfo>(
            "/api/v3/exchangeInfo",
            HttpMethod.Get,
            signed: false,
            ct: ct);

        return response.Symbols
            .Where(s => s.Status == "TRADING")
            .Select(s => s.Symbol)
            .ToList();
    }

    public async Task<BinanceSymbolInfo?> GetSymbolInfoAsync(string symbol, CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceExchangeInfo>(
            "/api/v3/exchangeInfo",
            HttpMethod.Get,
            signed: false,
            ct: ct);

        return response.Symbols.FirstOrDefault(s =>
            s.Symbol.Equals(symbol, StringComparison.OrdinalIgnoreCase));
    }

    public async Task<List<OHLCV>> GetKlinesAsync(
        string symbol,
        string interval,
        int limit,
        CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&interval={interval}&limit={limit}";
        var response = await SendRequestAsync<List<List<object>>>(
            $"/api/v3/klines?{query}",
            HttpMethod.Get,
            signed: false,
            ct: ct);

        return response.Select(k => new OHLCV
        {
            Symbol = symbol,
            OpenTime = DateTimeExtensions.FromUnixMilliseconds(Convert.ToInt64(k[0])),
            Open = Convert.ToDecimal(k[1]),
            High = Convert.ToDecimal(k[2]),
            Low = Convert.ToDecimal(k[3]),
            Close = Convert.ToDecimal(k[4]),
            Volume = Convert.ToDecimal(k[5]),
            CloseTime = DateTimeExtensions.FromUnixMilliseconds(Convert.ToInt64(k[6])),
            QuoteVolume = Convert.ToDecimal(k[7]),
            TradesCount = Convert.ToInt32(k[8])
        }).ToList();
    }

    public async Task<AccountBalance> GetAccountBalanceAsync(CancellationToken ct = default)
    {
        var response = await SendRequestAsync<BinanceAccountInfo>(
            "/api/v3/account",
            HttpMethod.Get,
            signed: true,
            ct: ct);

        var balance = new AccountBalance
        {
            Timestamp = DateTime.UtcNow
        };

        foreach (var b in response.Balances)
        {
            var free = decimal.Parse(b.Free);
            var locked = decimal.Parse(b.Locked);

            if (free > 0 || locked > 0)
            {
                balance.UpdateAsset(b.Asset, free, locked);
            }
        }

        return balance;
    }

    public async Task<Order> PlaceOrderAsync(
        string symbol,
        OrderSide side,
        decimal quantity,
        decimal price,
        bool postOnly = true,
        CancellationToken ct = default)
    {
        var queryParams = new Dictionary<string, string>
        {
            ["symbol"] = symbol,
            ["side"] = side.ToString().ToUpper(),
            ["type"] = "LIMIT",
            ["timeInForce"] = "GTC",
            ["quantity"] = quantity.ToInvariantString(),
            ["price"] = price.ToInvariantString()
        };

        if (postOnly)
        {
            queryParams["selfTradePreventionMode"] = "EXPIRE_TAKER";
        }

        var query = string.Join("&", queryParams.Select(p => $"{p.Key}={p.Value}"));

        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}",
            HttpMethod.Post,
            signed: true,
            ct: ct);

        return MapToOrder(response);
    }

    public async Task CancelOrderAsync(string symbol, long orderId, CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&orderId={orderId}";
        await SendRequestAsync<object>(
            $"/api/v3/order?{query}",
            HttpMethod.Delete,
            signed: true,
            ct: ct);
    }

    public async Task<Order> GetOrderAsync(string symbol, long orderId, CancellationToken ct = default)
    {
        var query = $"symbol={symbol}&orderId={orderId}";
        var response = await SendRequestAsync<BinanceOrderResponse>(
            $"/api/v3/order?{query}",
            HttpMethod.Get,
            signed: true,
            ct: ct);

        return MapToOrder(response);
    }

    public async Task<List<Order>> GetOpenOrdersAsync(string? symbol = null, CancellationToken ct = default)
    {
        var query = symbol != null ? $"symbol={symbol}" : string.Empty;
        var response = await SendRequestAsync<List<BinanceOrderResponse>>(
            $"/api/v3/openOrders?{query}",
            HttpMethod.Get,
            signed: true,
            ct: ct);

        return response.Select(MapToOrder).ToList();
    }

    private async Task<T> SendRequestAsync<T>(
        string endpoint,
        HttpMethod method,
        bool signed,
        CancellationToken ct)
    {
        var url = endpoint;

        if (signed)
        {
            var timestamp = DateTime.UtcNow.ToUnixMilliseconds();
            var separator = url.Contains('?') ? "&" : "?";

            // Явно указываем recvWindow=60000 (60 секунд) для защиты от сетевых задержек и ошибки -1021
            url = $"{url}{separator}timestamp={timestamp}&recvWindow=60000";

            var signature = CreateSignature(url.Contains('?')
                ? url.Substring(url.IndexOf('?') + 1)
                : string.Empty);
            url = $"{url}&signature={signature}";
        }

        return await TaskExtensions.RetryAsync(
            async () =>
            {
                var request = new HttpRequestMessage(method, url);
                var response = await _httpClient.SendAsync(request, ct);

                var content = await response.Content.ReadAsStringAsync(ct);

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError("Binance API error: {StatusCode} {Content}",
                        response.StatusCode, content);
                    throw new HttpRequestException($"Binance API error: {content}");
                }

                return JsonSerializer.Deserialize<T>(content, _jsonOptions)
                    ?? throw new InvalidOperationException("Response is null");
            },
            _config.MaxRetries,
            _config.RetryBaseDelayMs,
            onRetry: (attempt, ex) =>
            {
                _logger.LogWarning(ex, "Retry attempt {Attempt} for {Endpoint}", attempt, endpoint);
            },
            ct: ct);
    }

    private string CreateSignature(string queryString)
    {
        var apiSecret = ApiKeyEncryptor.Decrypt(_config.EncryptedApiSecret);
        using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(apiSecret));
        var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(queryString));
        return BitConverter.ToString(hash).Replace("-", "").ToLower();
    }

    private Order MapToOrder(BinanceOrderResponse response)
    {
        return new Order
        {
            Id = response.OrderId.ToString(),
            ClientOrderId = response.ClientOrderId,
            Symbol = response.Symbol,
            Side = response.Side.ToLower() == "buy" ? OrderSide.Buy : OrderSide.Sell,
            Type = OrderType.Limit,
            Status = MapOrderStatus(response.Status),
            Price = decimal.Parse(response.Price),
            OriginalQuantity = decimal.Parse(response.OrigQty),
            ExecutedQuantity = decimal.Parse(response.ExecutedQty),
            FilledQuoteQuantity = decimal.Parse(response.CummulativeQuoteQty),
            BinanceOrderId = response.OrderId,
            CreatedAt = DateTimeExtensions.FromUnixMilliseconds(response.TransactTime),
            Commission = response.Fills.Sum(f => decimal.Parse(f.Commission)),
            CommissionAsset = response.Fills.FirstOrDefault()?.CommissionAsset ?? "USDT"
        };
    }

    private OrderStatus MapOrderStatus(string status)
    {
        return status.ToUpper() switch
        {
            "NEW" => OrderStatus.New,
            "PARTIALLY_FILLED" => OrderStatus.PartiallyFilled,
            "FILLED" => OrderStatus.Filled,
            "CANCELED" => OrderStatus.Canceled,
            "REJECTED" => OrderStatus.Rejected,
            "EXPIRED" => OrderStatus.Expired,
            _ => OrderStatus.New
        };
    }
}
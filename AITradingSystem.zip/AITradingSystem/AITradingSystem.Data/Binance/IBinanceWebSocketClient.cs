using AITradingSystem.Core.Models.MarketData;

namespace AITradingSystem.Data.Binance;

/// <summary>
/// Интерфейс WebSocket клиента Binance (FR-1.1, FR-1.2, FR-1.3).
/// </summary>
public interface IBinanceWebSocketClient : IAsyncDisposable
{
    /// <summary>
    /// Событие: новая свеча (закрытая или обновленная).
    /// </summary>
    event Action<OHLCV>? OnKline;

    /// <summary>
    /// Событие: новая сделка (для построения OHLCV из тиков).
    /// </summary>
    event Action<string, decimal, decimal, DateTime>? OnTrade;

    /// <summary>
    /// Событие: обновленный стакан ордеров.
    /// </summary>
    event Action<OrderBook>? OnOrderBook;

    /// <summary>
    /// Событие: ошибка соединения.
    /// </summary>
    event Action<Exception>? OnError;

    /// <summary>
    /// Подключиться и подписаться на указанные пары.
    /// </summary>
    Task ConnectAsync(IEnumerable<string> symbols, string interval, CancellationToken ct = default);

    /// <summary>
    /// Отключиться.
    /// </summary>
    Task DisconnectAsync();

    /// <summary>
    /// Подключен ли клиент.
    /// </summary>
    bool IsConnected { get; }
    /// <summary>Последняя цена из уже полученного kline; без сетевого запроса.</summary>
    bool TryGetLastPrice(string symbol, out decimal price);
}
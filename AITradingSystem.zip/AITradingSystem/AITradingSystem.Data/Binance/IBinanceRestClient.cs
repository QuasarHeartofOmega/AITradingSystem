﻿using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Data.Binance;

/// <summary>
/// Интерфейс REST клиента Binance (FR-6).
/// </summary>
public interface IBinanceRestClient
{
    /// <summary>
    /// Получить список валидных торговых пар.
    /// </summary>
    Task<List<string>> GetValidSymbolsAsync(CancellationToken ct = default);

    /// <summary>
    /// Получить информацию о символе (фильтры).
    /// </summary>
    Task<BinanceSymbolInfo?> GetSymbolInfoAsync(string symbol, CancellationToken ct = default);

    /// <summary>
    /// Получить исторические свечи.
    /// </summary>
    Task<List<OHLCV>> GetKlinesAsync(string symbol, string interval, int limit, CancellationToken ct = default);

    /// <summary>
    /// Получить баланс аккаунта.
    /// </summary>
    Task<AccountBalance> GetAccountBalanceAsync(CancellationToken ct = default);

    /// <summary>
    /// Разместить ордер.
    /// </summary>
    Task<Order> PlaceOrderAsync(
        string symbol,
        OrderSide side,
        decimal quantity,
        decimal price,
        bool postOnly = true,
        CancellationToken ct = default);

    /// <summary>
    /// Отменить ордер.
    /// </summary>
    Task CancelOrderAsync(string symbol, long orderId, CancellationToken ct = default);

    /// <summary>
    /// Получить статус ордера.
    /// </summary>
    Task<Order> GetOrderAsync(string symbol, long orderId, CancellationToken ct = default);

    /// <summary>
    /// Получить открытые ордера.
    /// </summary>
    Task<List<Order>> GetOpenOrdersAsync(string? symbol = null, CancellationToken ct = default);
}
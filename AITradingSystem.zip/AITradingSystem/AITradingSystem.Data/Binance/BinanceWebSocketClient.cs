﻿using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Globalization;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Core.Models.MarketData;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Data.Binance;

/// <summary>
/// WebSocket клиент Binance с автопереподключением (NFR-2.1).
/// </summary>
public sealed class BinanceWebSocketClient : IBinanceWebSocketClient
{
    private readonly BinanceConfig _config;
    private readonly ILogger<BinanceWebSocketClient> _logger;
    private ClientWebSocket? _ws;
    private CancellationTokenSource? _cts;
    private Task? _receiveTask;
    private readonly Dictionary<string, OHLCV> _currentKlines = new();
    private readonly object _lock = new();

    public event Action<OHLCV>? OnKline;
    public event Action<string, decimal, decimal, DateTime>? OnTrade;
    public event Action<OrderBook>? OnOrderBook;
    public event Action<Exception>? OnError;

    public bool IsConnected => _ws?.State == WebSocketState.Open;

    public BinanceWebSocketClient(BinanceConfig config, ILogger<BinanceWebSocketClient> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task ConnectAsync(IEnumerable<string> symbols, string interval, CancellationToken ct = default)
    {
        var symbolList = symbols.ToList();
        if (symbolList.Count == 0)
            throw new ArgumentException("Symbols list cannot be empty", nameof(symbols));

        _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);

        // Формируем streams
        var streams = symbolList.SelectMany(s => new[]
        {
            $"{s.ToLower()}@kline_{interval}",
            $"{s.ToLower()}@depth@1000ms"
        });

        var combinedStream = string.Join("/", streams);

        // ИСПОЛЬЗУЕМ MAINNET ДЛЯ ПОЛУЧЕНИЯ ДАННЫХ (это публичные данные, ключи не нужны)
        // Это в 100 раз стабильнее, чем testnet.binance.vision
        var url = $"wss://stream.binance.com:9443/stream?streams={combinedStream}";

        _logger.LogInformation("Подключение к WebSocket (Mainnet Data). URL: {Url}", url);
        _logger.LogInformation("Количество стримов: {Count}", streams.Count());

        _ws = new ClientWebSocket();
        _ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(30);

        // Принудительно используем TLS 1.2/1.3 для совместимости
        _ws.Options.RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true;

        try
        {
            await _ws.ConnectAsync(new Uri(url), _cts.Token);
            _logger.LogInformation("✅ WebSocket подключен успешно!");
            _receiveTask = Task.Run(() => ReceiveLoopAsync(_cts.Token), _cts.Token);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Не удалось подключиться к WebSocket. URL: {Url}", url);
            throw;
        }
    }

    public async Task DisconnectAsync()
    {
        _logger.LogInformation("Отключение от WebSocket");

        _cts?.Cancel();

        if (_receiveTask != null)
        {
            try
            {
                await _receiveTask;
            }
            catch (OperationCanceledException)
            {
                // Ожидаемое поведение
            }
        }

        if (_ws?.State == WebSocketState.Open)
        {
            await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None);
        }

        _ws?.Dispose();
        _cts?.Dispose();

        _logger.LogInformation("WebSocket отключен");
    }

    private async Task ReceiveLoopAsync(CancellationToken ct)
    {
        var buffer = new byte[1024 * 64]; // 64 KB buffer

        while (!ct.IsCancellationRequested && _ws?.State == WebSocketState.Open)
        {
            try
            {
                var result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);

                if (result.MessageType == WebSocketMessageType.Close)
                {
                    _logger.LogWarning("WebSocket закрыт сервером");
                    break;
                }

                if (result.MessageType == WebSocketMessageType.Text)
                {
                    var message = Encoding.UTF8.GetString(buffer, 0, result.Count);
                    ProcessMessage(message);
                }
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка в WebSocket receive loop");
                OnError?.Invoke(ex);

                // Если произошла критическая ошибка, проверяем, не была ли запрошена отмена
                if (ct.IsCancellationRequested) break;

                // Небольшая задержка перед следующей итерацией, чтобы не нагружать CPU при ошибке
                await Task.Delay(1000, ct);
            }
        }
    }

    private void ProcessMessage(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (!root.TryGetProperty("stream", out var streamProp))
                return;

            var stream = streamProp.GetString();
            if (stream is null) return;

            if (!root.TryGetProperty("data", out var data))
                return;

            if (stream.Contains("@kline_"))
            {
                var kline = JsonSerializer.Deserialize<BinanceKlineStream>(data.GetRawText());
                if (kline != null)
                    ProcessKline(kline);
            }
            else if (stream.Contains("@depth"))
            {
                var depth = JsonSerializer.Deserialize<BinanceDepthStream>(data.GetRawText());
                if (depth != null)
                    ProcessDepth(depth);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка парсинга WebSocket сообщения");
        }
    }

    private void ProcessKline(BinanceKlineStream kline)
    {
        var ohlcv = new OHLCV
        {
            Symbol = kline.Kline.Symbol,
            OpenTime = DateTimeExtensions.FromUnixMilliseconds(kline.Kline.OpenTime),
            CloseTime = DateTimeExtensions.FromUnixMilliseconds(kline.Kline.CloseTime),
            Open = decimal.Parse(kline.Kline.Open, CultureInfo.InvariantCulture),
            High = decimal.Parse(kline.Kline.High, CultureInfo.InvariantCulture),
            Low = decimal.Parse(kline.Kline.Low, CultureInfo.InvariantCulture),
            Close = decimal.Parse(kline.Kline.Close, CultureInfo.InvariantCulture),
            Volume = decimal.Parse(kline.Kline.Volume, CultureInfo.InvariantCulture),
            QuoteVolume = decimal.Parse(kline.Kline.QuoteVolume, CultureInfo.InvariantCulture),
            TradesCount = kline.Kline.TradesCount
        };

        lock (_lock)
        {
            _currentKlines[ohlcv.Symbol] = ohlcv;
        }

        OnKline?.Invoke(ohlcv);

        // Также генерируем событие Trade для совместимости
        OnTrade?.Invoke(ohlcv.Symbol, ohlcv.Close, ohlcv.Volume, ohlcv.CloseTime);
    }

    private void ProcessDepth(BinanceDepthStream depth)
    {
        var orderBook = new OrderBook
        {
            Symbol = depth.Symbol,
            Timestamp = DateTime.UtcNow,
            LastUpdateId = depth.LastUpdateId,
            Bids = depth.Bids.Select(b => new OrderBookEntry
            {
                Price = decimal.Parse(b[0], CultureInfo.InvariantCulture),
                Quantity = decimal.Parse(b[1], CultureInfo.InvariantCulture)
            }).ToList(),
            Asks = depth.Asks.Select(a => new OrderBookEntry
            {
                Price = decimal.Parse(a[0], CultureInfo.InvariantCulture),
                Quantity = decimal.Parse(a[1], CultureInfo.InvariantCulture)
            }).ToList()
        };

        OnOrderBook?.Invoke(orderBook);
    }

    public async ValueTask DisposeAsync()
    {
        await DisconnectAsync();
    }
}
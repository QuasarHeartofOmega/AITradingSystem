using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Globalization;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Core.Models.MarketData;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Data.Binance;

/// <summary>
/// WebSocket клиент Binance с автопереподключением (NFR-2.1).
/// Стакан берется из partial-book stream (@depth20) — это готовый снимок топ-20 уровней,
/// в отличие от diff-stream (@depth), который содержит только изменения.
/// </summary>
public sealed class BinanceWebSocketClient : IBinanceWebSocketClient
{
    private readonly BinanceConfig _config;
    private readonly ILogger<BinanceWebSocketClient> _logger;
    private ClientWebSocket? _ws;
    private CancellationTokenSource? _cts;
    private Task? _receiveTask;
    private string? _streamUrl;

    public event Action<OHLCV>? OnKline;
    public event Action<string, decimal, decimal, DateTime>? OnTrade;
    public event Action<OrderBook>? OnOrderBook;
    public event Action<Exception>? OnError;

    public bool IsConnected => _ws?.State == WebSocketState.Open;

    public BinanceWebSocketClient(BinanceConfig config, ILogger<BinanceWebSocketClient> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task ConnectAsync(IEnumerable<string> symbols, string interval, CancellationToken ct = default)
    {
        var symbolList = symbols.ToList();
        if (symbolList.Count == 0)
            throw new ArgumentException("Symbols list cannot be empty", nameof(symbols));

        _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);

        var streams = symbolList.SelectMany(s => new[]
        {
            $"{s.ToLowerInvariant()}@kline_{interval}",
            $"{s.ToLowerInvariant()}@depth20@1000ms"
        });

        var combinedStream = string.Join("/", streams);

        // Публичные рыночные данные берем с mainnet — это стабильнее testnet и не требует ключей.
        _streamUrl = $"wss://stream.binance.com:9443/stream?streams={combinedStream}";

        _logger.LogInformation("Подключение к WebSocket. Стримов: {Count}", symbolList.Count * 2);

        await ConnectInternalAsync(_cts.Token);
        _receiveTask = Task.Run(() => ReceiveLoopAsync(_cts.Token), _cts.Token);
    }

    private async Task ConnectInternalAsync(CancellationToken ct)
    {
        _ws?.Dispose();
        _ws = new ClientWebSocket();
        _ws.Options.KeepAliveInterval = TimeSpan.FromSeconds(30);

        try
        {
            await _ws.ConnectAsync(new Uri(_streamUrl!), ct);
            _logger.LogInformation("WebSocket подключен");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Не удалось подключиться к WebSocket");
            throw;
        }
    }

    public async Task DisconnectAsync()
    {
        _logger.LogInformation("Отключение от WebSocket");

        _cts?.Cancel();

        if (_receiveTask != null)
        {
            try { await _receiveTask; }
            catch (OperationCanceledException) { /* ожидаемо */ }
            catch (Exception ex) { _logger.LogWarning(ex, "Ошибка завершения receive loop"); }
            _receiveTask = null;
        }

        if (_ws?.State == WebSocketState.Open)
        {
            try
            {
                await _ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", CancellationToken.None);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Ошибка корректного закрытия WebSocket");
            }
        }

        _ws?.Dispose();
        _ws = null;
        _cts?.Dispose();
        _cts = null;

        _logger.LogInformation("WebSocket отключен");
    }

    private async Task ReceiveLoopAsync(CancellationToken ct)
    {
        var buffer = new byte[1024 * 64];
        var reconnectDelayMs = 2000;

        while (!ct.IsCancellationRequested)
        {
            // === Цикл приема сообщений ===
            while (!ct.IsCancellationRequested && _ws?.State == WebSocketState.Open)
            {
                try
                {
                    var result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);

                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        _logger.LogWarning("WebSocket закрыт сервером");
                        break;
                    }

                    if (result.MessageType == WebSocketMessageType.Text)
                    {
                        // Сообщение может прийти частями — собираем до EndOfMessage
                        using var ms = new MemoryStream();
                        ms.Write(buffer, 0, result.Count);
                        while (!result.EndOfMessage)
                        {
                            result = await _ws.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                            ms.Write(buffer, 0, result.Count);
                        }

                        var message = Encoding.UTF8.GetString(ms.ToArray());
                        ProcessMessage(message);
                        reconnectDelayMs = 2000; // сброс backoff после успешного приема
                    }
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка в WebSocket receive loop");
                    OnError?.Invoke(ex);
                    break;
                }
            }

            if (ct.IsCancellationRequested)
                break;

            // === Автопереподключение (NFR-2.1) ===
            _logger.LogWarning("Переподключение через {Delay} мс...", reconnectDelayMs);
            try
            {
                await Task.Delay(reconnectDelayMs, ct);
                await ConnectInternalAsync(ct);
                reconnectDelayMs = 2000;
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка переподключения");
                OnError?.Invoke(ex);
                reconnectDelayMs = Math.Min(reconnectDelayMs * 2, 60_000);
            }
        }
    }

    private void ProcessMessage(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (!root.TryGetProperty("stream", out var streamProp))
                return;

            var stream = streamProp.GetString();
            if (stream is null) return;

            if (!root.TryGetProperty("data", out var data))
                return;

            if (stream.Contains("@kline_"))
            {
                var kline = JsonSerializer.Deserialize<BinanceKlineStream>(data.GetRawText());
                if (kline != null)
                    ProcessKline(kline);
            }
            else if (stream.Contains("@depth"))
            {
                // В partial-book stream нет поля "s" — символ берем из имени стрима
                var symbol = stream.Split('@')[0].ToUpperInvariant();
                var depth = JsonSerializer.Deserialize<BinancePartialDepthStream>(data.GetRawText());
                if (depth != null)
                    ProcessDepth(depth, symbol);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка парсинга WebSocket сообщения");
        }
    }

    private void ProcessKline(BinanceKlineStream kline)
    {
        var ohlcv = new OHLCV
        {
            Symbol = kline.Kline.Symbol,
            OpenTime = DateTimeExtensions.FromUnixMilliseconds(kline.Kline.OpenTime),
            CloseTime = DateTimeExtensions.FromUnixMilliseconds(kline.Kline.CloseTime),
            Open = decimal.Parse(kline.Kline.Open, CultureInfo.InvariantCulture),
            High = decimal.Parse(kline.Kline.High, CultureInfo.InvariantCulture),
            Low = decimal.Parse(kline.Kline.Low, CultureInfo.InvariantCulture),
            Close = decimal.Parse(kline.Kline.Close, CultureInfo.InvariantCulture),
            Volume = decimal.Parse(kline.Kline.Volume, CultureInfo.InvariantCulture),
            QuoteVolume = decimal.Parse(kline.Kline.QuoteVolume, CultureInfo.InvariantCulture),
            TradesCount = kline.Kline.TradesCount
        };

        OnKline?.Invoke(ohlcv);
        OnTrade?.Invoke(ohlcv.Symbol, ohlcv.Close, ohlcv.Volume, ohlcv.CloseTime);
    }

    private void ProcessDepth(BinancePartialDepthStream depth, string symbol)
    {
        var orderBook = new OrderBook
        {
            Symbol = symbol,
            Timestamp = DateTime.UtcNow,
            LastUpdateId = depth.LastUpdateId,
            Bids = depth.Bids.Select(b => new OrderBookEntry
            {
                Price = decimal.Parse(b[0], CultureInfo.InvariantCulture),
                Quantity = decimal.Parse(b[1], CultureInfo.InvariantCulture)
            }).ToList(),
            Asks = depth.Asks.Select(a => new OrderBookEntry
            {
                Price = decimal.Parse(a[0], CultureInfo.InvariantCulture),
                Quantity = decimal.Parse(a[1], CultureInfo.InvariantCulture)
            }).ToList()
        };

        OnOrderBook?.Invoke(orderBook);
    }

    public async ValueTask DisposeAsync()
    {
        await DisconnectAsync();
    }
}

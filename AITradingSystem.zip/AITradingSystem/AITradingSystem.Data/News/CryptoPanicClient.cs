﻿using System.Text.Json;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.News;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Data.News;

/// <summary>
/// Клиент CryptoPanic API (FR-2.1).
/// </summary>
public sealed class CryptoPanicClient : INewsProvider
{
    private readonly NewsConfig _config;
    private readonly HttpClient _httpClient;
    private readonly ILogger<CryptoPanicClient> _logger;

    public string Name => "CryptoPanic";
    public bool IsAvailable => !string.IsNullOrWhiteSpace(_config.CryptoPanicApiKey);

    public CryptoPanicClient(NewsConfig config, ILogger<CryptoPanicClient> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        _httpClient = new HttpClient
        {
            BaseAddress = new Uri("https://cryptopanic.com/api/v1/")
        };
    }

    public async Task<List<NewsItem>> GetLatestNewsAsync(CancellationToken ct = default)
    {
        if (!IsAvailable)
        {
            _logger.LogWarning("CryptoPanic API key не настроен");
            return new List<NewsItem>();
        }

        try
        {
            var url = $"posts/?auth_token={_config.CryptoPanicApiKey}&kind=news&public=true";
            var response = await _httpClient.GetStringAsync(url, ct);

            using var doc = JsonDocument.Parse(response);
            var results = doc.RootElement.GetProperty("results");

            var news = new List<NewsItem>();

            foreach (var item in results.EnumerateArray())
            {
                var newsItem = new NewsItem
                {
                    Id = item.GetProperty("id").ToString(),
                    Title = item.GetProperty("title").GetString() ?? string.Empty,
                    Source = item.TryGetProperty("source", out var src)
                        ? src.GetProperty("title").GetString() ?? "Unknown"
                        : "Unknown",
                    Url = item.GetProperty("url").GetString() ?? string.Empty,
                    Text = item.TryGetProperty("text", out var text)
                        ? text.GetString() ?? string.Empty
                        : string.Empty,
                    PublishedAt = item.TryGetProperty("published_at", out var pub)
                        ? DateTime.Parse(pub.GetString() ?? DateTime.UtcNow.ToString())
                        : DateTime.UtcNow,
                    Sentiment = MapSentiment(item),
                    SentimentScore = item.TryGetProperty("votes", out var votes)
                        ? CalculateSentimentScore(votes)
                        : 0
                };

                // Извлечение связанных криптовалют
                if (item.TryGetProperty("currencies", out var currencies))
                {
                    foreach (var curr in currencies.EnumerateArray())
                    {
                        if (curr.TryGetProperty("code", out var code))
                        {
                            newsItem.RelatedSymbols.Add(code.GetString() ?? string.Empty);
                        }
                    }
                }

                news.Add(newsItem);

                if (news.Count >= _config.MaxNewsPerSymbol * 7) // 7 пар
                    break;
            }

            _logger.LogInformation("Получено {Count} новостей из CryptoPanic", news.Count);
            return news;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка получения новостей из CryptoPanic");
            return new List<NewsItem>();
        }
    }

    private Sentiment MapSentiment(JsonElement item)
    {
        if (!item.TryGetProperty("votes", out var votes))
            return Sentiment.Neutral;

        var score = CalculateSentimentScore(votes);

        return score switch
        {
            > 0.2m => Sentiment.Bullish,
            < -0.2m => Sentiment.Bearish,
            _ => Sentiment.Neutral
        };
    }

    private decimal CalculateSentimentScore(JsonElement votes)
    {
        var positive = votes.TryGetProperty("positive", out var pos) ? pos.GetInt32() : 0;
        var negative = votes.TryGetProperty("negative", out var neg) ? neg.GetInt32() : 0;
        var total = positive + negative;

        return total > 0 ? (decimal)(positive - negative) / total : 0;
    }
}
﻿using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.News;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Data.News;

/// <summary>
/// Агрегатор новостей с фильтрацией по релевантности (FR-2.2, FR-2.3).
/// </summary>
public sealed class NewsAggregator
{
    private readonly NewsConfig _config;
    private readonly List<INewsProvider> _providers;
    private readonly ILogger<NewsAggregator> _logger;
    private readonly Dictionary<string, List<NewsItem>> _cachedNews = new();
    private DateTime _lastUpdate = DateTime.MinValue;
    private readonly object _lock = new();

    public NewsAggregator(
        NewsConfig config,
        IEnumerable<INewsProvider> providers,
        ILogger<NewsAggregator> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _providers = providers?.ToList() ?? throw new ArgumentNullException(nameof(providers));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить новости для конкретной торговой пары.
    /// </summary>
    public async Task<List<NewsItem>> GetNewsForSymbolAsync(string symbol, CancellationToken ct = default)
    {
        await UpdateNewsIfNeededAsync(ct);

        lock (_lock)
        {
            var result = new List<NewsItem>();

            // CryptoPanic тегирует новости базовыми активами (BTC, ETH),
            // а не торговыми парами (BTCUSDT) — пробуем оба варианта.
            if (_cachedNews.TryGetValue(symbol, out var byPair))
                result.AddRange(byPair);

            var baseAsset = ExtractBaseAsset(symbol);
            if (baseAsset.Length > 0 &&
                !baseAsset.Equals(symbol, StringComparison.OrdinalIgnoreCase) &&
                _cachedNews.TryGetValue(baseAsset, out var byAsset))
                result.AddRange(byAsset);

            // Если по активу новостей нет — берем общий фон
            if (result.Count == 0 && _cachedNews.TryGetValue("GENERAL", out var general))
                result.AddRange(general);

            return result
                .GroupBy(n => n.Id)
                .Select(g => g.First())
                .OrderByDescending(n => n.PublishedAt)
                .Take(_config.MaxNewsPerSymbol)
                .ToList();
        }
    }

    private static string ExtractBaseAsset(string symbol)
    {
        string[] quotes = { "USDT", "USDC", "BUSD", "FDUSD", "TUSD", "BTC", "ETH", "BNB", "USD" };
        foreach (var quote in quotes)
        {
            if (symbol.EndsWith(quote, StringComparison.OrdinalIgnoreCase) && symbol.Length > quote.Length)
                return symbol[..^quote.Length];
        }
        return symbol;
    }

    /// <summary>
    /// Обновить новости (с учетом интервала).
    /// </summary>
    public async Task UpdateNewsIfNeededAsync(CancellationToken ct = default)
    {
        if (!_config.Enabled)
            return;

        if (DateTime.UtcNow - _lastUpdate < TimeSpan.FromMinutes(_config.UpdateIntervalMinutes))
            return;

        var allNews = new List<NewsItem>();

        foreach (var provider in _providers.Where(p => p.IsAvailable))
        {
            try
            {
                var news = await provider.GetLatestNewsAsync(ct);
                allNews.AddRange(news);
                _logger.LogInformation("Получено {Count} новостей от {Provider}", news.Count, provider.Name);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка получения новостей от {Provider}", provider.Name);
            }
        }

        // Фильтрация и группировка по символам
        var grouped = FilterAndGroupBySymbol(allNews);

        lock (_lock)
        {
            _cachedNews.Clear();
            foreach (var kvp in grouped)
            {
                _cachedNews[kvp.Key] = kvp.Value;
            }
            _lastUpdate = DateTime.UtcNow;
        }

        _logger.LogInformation("Новости обновлены. Символов с новостями: {Count}", grouped.Count);
    }

    private Dictionary<string, List<NewsItem>> FilterAndGroupBySymbol(List<NewsItem> allNews)
    {
        var result = new Dictionary<string, List<NewsItem>>(StringComparer.OrdinalIgnoreCase);

        foreach (var news in allNews)
        {
            if (!news.IsRelevant)
                continue;

            // Группировка по связанным символам
            foreach (var symbol in news.RelatedSymbols)
            {
                if (!result.ContainsKey(symbol))
                {
                    result[symbol] = new List<NewsItem>();
                }
                result[symbol].Add(news);
            }

            // Также добавляем в общий список (без символа)
            if (!result.ContainsKey("GENERAL"))
            {
                result["GENERAL"] = new List<NewsItem>();
            }
            result["GENERAL"].Add(news);
        }

        // Сортировка по дате и sentiment score
        foreach (var kvp in result)
        {
            kvp.Value.Sort((a, b) =>
            {
                var dateCompare = b.PublishedAt.CompareTo(a.PublishedAt);
                if (dateCompare != 0) return dateCompare;
                return Math.Abs(b.SentimentScore).CompareTo(Math.Abs(a.SentimentScore));
            });
        }

        return result;
    }
}
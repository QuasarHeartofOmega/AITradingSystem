# AITradingSystem

WPF-приложение (.NET 8) для алгоритмической торговли криптовалютой на Binance:
рыночные данные по WebSocket, 12 технических индикаторов, торговые сигналы от локальной
LLM (Qwen через LLamaSharp), риск-менеджмент, paper-trading, Telegram-алерты.

## Структура

| Проект | Назначение |
|---|---|
| `AITradingSystem.Common` | Конфигурация, логирование (Serilog), шифрование ключей (DPAPI), retry |
| `AITradingSystem.Core` | Модели, индикаторы (EMA/RSI/MACD/ATR/ADX/Supertrend/BB/StochRSI/OBV/VWAP), риск-менеджмент |
| `AITradingSystem.Data` | Binance REST + WebSocket, новости CryptoPanic, JSON-хранилища |
| `AITradingSystem.Services` | TradingEngine, QwenModel (LLamaSharp), OrderExecutor, PositionManager, мониторинг |
| `AITradingSystem.UI` | WPF-интерфейс (MVVM, CommunityToolkit) |
| `AITradingSystem.Tests` | xUnit-тесты индикаторов и риск-менеджмента |

## Быстрый старт

1. **Требования:** Windows x64, [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0),
   Visual Studio 2022 (17.8+) или `dotnet build`.
2. **Скачайте GGUF-модель**, например
   [Qwen2.5-7B-Instruct Q4_K_M](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF)
   и положите её в папку `models/` рядом с exe (или укажите свой путь в `appsettings.json` → `AI:ModelPath`).
   Без модели приложение запустится, но кнопка «Старт» выдаст понятную ошибку.
3. **Настройте `AITradingSystem.UI/appsettings.json`:**
   - `Trading:PaperTradingMode: true` — тестовый режим без реальных ордеров (включен по умолчанию, баланс 10 000 USDT);
   - `AI:GpuLayers: 0` — CPU-бэкенд (`LLamaSharp.Backend.Cpu`). Для NVIDIA GPU замените пакет на
     `LLamaSharp.Backend.Cuda12` и поставьте `GpuLayers` ~35;
   - `AI:InferenceTimeoutMs` — таймаут генерации (30 c). На слабом CPU увеличьте;
   - `News:CryptoPanicApiKey` — опционально, для новостного контекста;
   - `Telegram` — опционально, алерты.
4. **Запуск:** откройте `AITradingSystem.sln`, стартовый проект — `AITradingSystem.UI`, F5.
   Или: `dotnet run --project AITradingSystem.UI`.
5. Нажмите **▶ Старт**. Индикаторы прогреваются историей свечей с REST автоматически.

> ⚠️ Live-режим (`PaperTradingMode: false`) требует API-ключей Binance, зашифрованных через
> `ApiKeyEncryptor.Encrypt` (DPAPI, привязка к пользователю Windows). Ключи в открытом виде
> в конфиг не вставляются. Торговля с реальными деньгами — на ваш риск.

## Тесты

```bash
dotnet test AITradingSystem.Tests
```

## Что было исправлено (ревизия кода)

- **Сборка:** пустой `DashboardView.xaml.cs` (+ его исключение из компиляции), несуществующая
  версия `Microsoft.Extensions.Logging.Abstractions 10.0.13`, отсутствующий `appsettings.json`.
- **AI:** `GenerateResponseAsync` перезагружал модель вместо генерации и возвращал пустую строку —
  теперь реальный потоковый инференс (`StatelessExecutor`) с таймаутом; промпт переведен в ChatML;
  JSON-ответ парсится с учетом snake_case (`entry_price` и т.д.).
- **Данные:** парсинг REST-свечей (`JsonElement` вместо `Convert`), инвариантная культура во всех
  `decimal.Parse`, стакан через `@depth20` (снимок) вместо diff-стрима, автопереподключение WS,
  убран обход проверки TLS-сертификатов.
- **Торговля:** прогрев индикаторов историей с REST при старте; Paper-режим исполняет ордера
  локально и обновляет виртуальный баланс; Post-Only через `LIMIT_MAKER`; закрытие market-ордером;
  округление до `stepSize`/`tickSize` и проверка `minNotional`; SL/TP от фактической цены входа;
  ручное закрытие из UI проходит через движок (история + баланс + события).
- **UI:** сохранение настроек в `appsettings.json`, живое обновление PnL (`INotifyPropertyChanged`),
  таймер обновления дашборда, загрузка истории сделок, читаемые тёмные вкладки/списки.
- **Прочее:** новости по базовому активу (BTC вместо BTCUSDT), корректные уровни Telegram-алертов,
  StochRSI %D, тренд OBV, потокобезопасный MarketAnalyzer, добавлены xUnit-тесты и `.gitignore`.

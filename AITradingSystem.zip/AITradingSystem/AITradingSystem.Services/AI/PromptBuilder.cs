using System.Globalization;
using System.Text;

namespace AITradingSystem.Services.AI;

/// <summary>
/// Формирование промптов для AI-модели в формате ChatML (FR-4.2).
/// Qwen-Instruct обучен на ChatML, поэтому используем именно его.
/// </summary>
public sealed class PromptBuilder
{
    public string BuildTradingPrompt(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        bool enableThinking = false)
    {
        var sb = new StringBuilder();

        sb.AppendLine("<|im_start|>system");
        sb.AppendLine("You are an expert cryptocurrency trading analyst. Analyze the provided market data and make a trading decision.");
        sb.AppendLine("All indicator values are normalized: trend/momentum values are in [-1, 1], volatility values in [0, 1].");
        sb.AppendLine("Respond ONLY with a valid JSON object, no markdown, no extra text:");
        sb.AppendLine("{");
        sb.AppendLine("  \"action\": \"BUY\" or \"SELL\" or \"HOLD\",");
        sb.AppendLine("  \"confidence\": 0.0 to 1.0,");
        sb.AppendLine("  \"entry_price\": number or null,");
        sb.AppendLine("  \"stop_loss\": number or null,");
        sb.AppendLine("  \"take_profit\": number or null,");
        sb.AppendLine("  \"reasoning\": \"brief explanation\"");
        sb.AppendLine("}");
        sb.AppendLine("For BUY: stop_loss < entry_price < take_profit. For SELL: take_profit < entry_price < stop_loss. For HOLD use null prices.");
        sb.AppendLine("<|im_end|>");

        sb.AppendLine("<|im_start|>user");
        sb.AppendLine($"Analyze {symbol} and provide a trading signal.");
        var priceText = indicators.TryGetValue("price", out var p)
            ? p.ToString("F2", CultureInfo.InvariantCulture)
            : "see indicators";
        sb.AppendLine($"Current price: {priceText}");
        sb.AppendLine();
        sb.AppendLine("Technical Indicators (normalized):");
        foreach (var kvp in indicators)
        {
            // Цена уже выведена выше отдельной строкой — не дублируем её в списке.
            if (string.Equals(kvp.Key, "price", StringComparison.OrdinalIgnoreCase))
                continue;

            sb.AppendLine($"- {kvp.Key}: {kvp.Value.ToString("F4", CultureInfo.InvariantCulture)}");
        }
        sb.AppendLine();

        if (!string.IsNullOrWhiteSpace(newsContext))
        {
            sb.AppendLine("Recent News:");
            sb.AppendLine(newsContext);
            sb.AppendLine();
        }

        sb.AppendLine("Provide your trading decision as the JSON object described above.");

        // Qwen3: мягкое отключение режима рассуждений. Иначе модель тратит лимит токенов
        // на <think>...</think> и до JSON дело не доходит (особенно на CPU).
        if (!enableThinking)
            sb.AppendLine("/no_think");
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>assistant");

        return sb.ToString();
    }
}

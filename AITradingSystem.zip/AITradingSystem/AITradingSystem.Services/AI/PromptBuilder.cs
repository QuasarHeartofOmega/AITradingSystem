﻿using System.Text;

namespace AITradingSystem.Services.AI;

/// <summary>
/// Формирование структурированных промптов для AI-модели (FR-4.2).
/// </summary>
public sealed class PromptBuilder
{
    /// <summary>
    /// Построить промпт для получения торгового сигнала.
    /// </summary>
    public string BuildTradingPrompt(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext)
    {
        var sb = new StringBuilder();

        sb.AppendLine("### System");
        sb.AppendLine("You are an expert cryptocurrency trading analyst. Analyze the provided market data and make a trading decision.");
        sb.AppendLine("Respond ONLY with a valid JSON object in the following format:");
        sb.AppendLine("{");
        sb.AppendLine("  \"action\": \"BUY\" | \"SELL\" | \"HOLD\",");
        sb.AppendLine("  \"confidence\": 0.0-1.0,");
        sb.AppendLine("  \"entry_price\": number | null,");
        sb.AppendLine("  \"stop_loss\": number | null,");
        sb.AppendLine("  \"take_profit\": number | null,");
        sb.AppendLine("  \"reasoning\": \"brief explanation\"");
        sb.AppendLine("}");
        sb.AppendLine();

        sb.AppendLine("### User");
        sb.AppendLine($"Analyze {symbol} and provide a trading signal.");
        sb.AppendLine();

        sb.AppendLine("**Technical Indicators:**");
        foreach (var kvp in indicators)
        {
            sb.AppendLine($"- {kvp.Key}: {kvp.Value:F4}");
        }
        sb.AppendLine();

        if (!string.IsNullOrWhiteSpace(newsContext))
        {
            sb.AppendLine("**Recent News:**");
            sb.AppendLine(newsContext);
            sb.AppendLine();
        }

        sb.AppendLine("Provide your analysis and trading decision in the specified JSON format.");
        sb.AppendLine();
        sb.AppendLine("### Assistant");

        return sb.ToString();
    }
}
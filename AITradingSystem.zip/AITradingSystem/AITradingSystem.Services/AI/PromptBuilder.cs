using System.Globalization;
using System.Text;

namespace AITradingSystem.Services.AI;

/// <summary>
/// Формирование промптов для AI-модели в формате ChatML (FR-4.2, B8).
///
/// Ключевое отличие от прежней версии: confidence НЕ якорится правилом «below 0.55».
/// Модель получает легенду индикаторов, детерминированный pre-score движка и рубрику,
/// по которой обязана вывести уверенность из фактов. Thinking остаётся включённым
/// (бюджет урезан), пустой think-блок в конце промпта НЕ префиллится (F3: давал 0 символов).
/// </summary>
public sealed class PromptBuilder
{
    private const string OpenThink = "<" + "think>";
    private const string CloseThink = "</" + "think>";

    /// <summary>Ключи индикаторов, которые являются ценой и форматируются по tick/decimals символа.</summary>
    private static readonly HashSet<string> PriceKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        "price", "atr_abs", "ema20", "ema50", "ema200", "bb_upper", "bb_lower", "vwap", "macd_hist_abs"
    };

    public string BuildTradingPrompt(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        bool enableThinking = false,
        AiRequestContext? context = null)
    {
        context ??= new AiRequestContext();
        var sb = new StringBuilder();

        sb.AppendLine("<|im_start|>system");
        sb.AppendLine("You are a disciplined cryptocurrency SPOT trading analyst. You manage a real account and must avoid invalid orders.");
        sb.AppendLine("The trading engine computes all arithmetic (position size, stops, R/R). Your job is the qualitative judgement of the setup.");
        sb.AppendLine();
        sb.AppendLine("Hard rules:");
        sb.AppendLine(context.AllowShort
            ? "1. BUY opens a long, SELL opens a short, CLOSE closes the open position, HOLD does nothing."
            : "1. This is a SPOT account: shorting is NOT possible. BUY opens a long. SELL or CLOSE closes an existing long. Without an open position SELL is ignored, so use HOLD instead.");
        sb.AppendLine("2. If a position is already open, choose only HOLD or CLOSE (never re-open the same symbol).");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"3. For a new entry: stop_loss and take_profit must give risk/reward >= {Num(context.MinRiskReward)}.");
        sb.AppendLine("4. For BUY: stop_loss < entry_price < take_profit. Prices must be realistic and close to the current price (within a few ATR).");
        sb.AppendLine("5. Never invent prices far from the market. entry_price should be within ~0.5% of the current price. Use the price precision shown in the context.");
        sb.AppendLine("6. confidence MUST be derived from the evidence rubric below and the engine pre-score. Do NOT default to any fixed number, and do not copy a threshold from these rules.");
        sb.AppendLine("7. News sentiment is a secondary factor; technical structure has priority. Ignore headlines that are not about this asset.");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"8. The engine re-calculates the actual stop at {Num(context.StopLossAtrMultiplier)} x ATR from the real fill price, so keep stop_loss near that distance instead of an arbitrary round number.");
        sb.AppendLine();

        // --- Легенда индикаторов (B8) ---
        sb.AppendLine("Indicator legend:");
        sb.AppendLine("- Normalized keys: trend/momentum in [-1, 1] (positive = bullish), volatility in [0, 1]. ema20_pos/ema50_pos/ema200_pos = price deviation from that EMA (x10, clipped); ema_align = 1 bullish stack / -1 bearish stack / 0 mixed; supertrend = 1 up / -1 down; adx = ADX/100; rsi = (RSI-50)/50; macd_hist = MACD histogram / (3*ATR); stoch_rsi_k/d in [0, 1]; atr_pct = ATR/price; bb_width = band width; bb_pos = position inside bands [-1, 1]; obv_trend = OBV slope; vwap_dev = deviation from VWAP.");
        sb.AppendLine("- Raw keys (use these for the rubric): rsi_raw and adx_raw in [0, 100]; stoch_k_raw/stoch_d_raw in [0, 100]; atr_abs, ema20, ema50, ema200, bb_upper, bb_lower, vwap, macd_hist_abs are absolute prices; volume_ratio = last candle volume / 20-period average volume (1.0 = average).");
        sb.AppendLine();

        // --- Рубрика уверенности (B8) ---
        sb.AppendLine("Confidence rubric (follow it literally):");
        sb.AppendLine("a) Start from engine_prior_confidence given in the context (deterministic pre-score of the same facts).");
        sb.AppendLine("b) Add +0.05 to +0.15 when trend, momentum and volume agree with your direction (EMA stack + Supertrend + MACD histogram + volume_ratio >= 1.2).");
        sb.AppendLine("c) Subtract 0.10 to 0.20 for conflicts (EMA vs Supertrend vs MACD disagree), adx_raw < 20, volume_ratio < 0.6, price pinned to a Bollinger band, or asset-specific negative news.");
        sb.AppendLine("d) Clamp the result to [0.10, 0.90]. Report that number as confidence — it must reflect the evidence, not a habit.");
        sb.AppendLine("e) Action follows the evidence: a coherent trend continuation with confidence >= the execution threshold is a BUY (or CLOSE when a position is open and the structure broke); a genuinely mixed setup is HOLD with a mid-range confidence.");
        sb.AppendLine("Examples: strong aligned setup (ema_align=1, supertrend=1, adx_raw=28, macd_hist>0, volume_ratio=1.6, engine_prior=0.62) -> BUY, confidence 0.72.");
        sb.AppendLine("Mixed setup (ema_align=0, supertrend=-1, adx_raw=15, volume_ratio=0.5, engine_prior=0.35) -> HOLD, confidence 0.30.");
        sb.AppendLine();

        sb.AppendLine("Answer format — ONE valid JSON object, no markdown, no comments, no extra text:");
        sb.AppendLine("{");
        sb.AppendLine("  \"action\": \"BUY\" | \"SELL\" | \"HOLD\" | \"CLOSE\",");
        sb.AppendLine("  \"confidence\": 0.0-1.0,");
        sb.AppendLine("  \"entry_price\": number or null,");
        sb.AppendLine("  \"stop_loss\": number or null,");
        sb.AppendLine("  \"take_profit\": number or null,");
        sb.AppendLine("  \"reasoning\": \"one or two sentences\"");
        sb.AppendLine("}");
        sb.AppendLine("For HOLD and CLOSE all price fields must be null.");

        if (enableThinking)
        {
            sb.AppendLine();
            sb.AppendLine("Before the JSON, reason briefly inside " + OpenThink + " ... " + CloseThink + " (max ~110 words, stay inside the thinking budget):");
            sb.AppendLine("trend/momentum agreement, ADX strength, volume confirmation, volatility, news risk, position state;");
            sb.AppendLine("then apply the confidence rubric and check the answer: action allowed, prices ordered, R/R sufficient.");
            sb.AppendLine("Open the think tag yourself, close it, then output ONLY the JSON object.");
        }

        sb.AppendLine("<|im_end|>");

        sb.AppendLine("<|im_start|>user");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Symbol: {symbol}");

        var priceText = indicators.TryGetValue("price", out var p) ? FmtPrice(p, context) : "unknown";
        sb.AppendLine(CultureInfo.InvariantCulture, $"Current price: {priceText}");
        // B8: у StringBuilder.AppendLine НЕТ перегрузки (IFormatProvider, string) — есть только
        // (IFormatProvider, ref AppendInterpolatedStringHandler). Конкатенация $"..." + (...)
        // даёт обычный string и не компилируется (CS1503). Форматируем строку целиком через
        // string.Create(IFormatProvider, ...), а в AppendLine отдаём готовый string.
        var tickText = context.TickSize.HasValue && context.TickSize.Value > 0
            ? string.Create(CultureInfo.InvariantCulture,
                $" (tick size {context.TickSize.Value:0.##########})")
            : string.Empty;
        sb.AppendLine(string.Create(CultureInfo.InvariantCulture,
            $"Price precision: {PriceDecimals(context)} decimals{tickText}"));

        if (indicators.TryGetValue("atr_pct", out var atrPct))
        {
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"ATR: {(atrPct * 100m).ToString("0.###", CultureInfo.InvariantCulture)}% of price (use it to scale stop distance)");
        }

        sb.AppendLine();
        sb.AppendLine("Technical indicators:");
        foreach (var kvp in indicators)
        {
            if (string.Equals(kvp.Key, "price", StringComparison.OrdinalIgnoreCase))
                continue;

            var valueText = PriceKeys.Contains(kvp.Key)
                ? FmtPrice(kvp.Value, context)
                : kvp.Value.ToString("0.####", CultureInfo.InvariantCulture);

            sb.AppendLine(CultureInfo.InvariantCulture, $"- {kvp.Key}: {valueText}");
        }
        sb.AppendLine();

        // --- Детерминированный pre-score движка (B9/B11) ---
        if (context.EngineScore.HasValue)
        {
            sb.AppendLine("Engine pre-score (deterministic, computed from the same indicators):");
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"- direction: {context.EngineDirection ?? "FLAT"}");
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"- score: {Num(context.EngineScore.Value)} (range -1..1)");
            if (context.EnginePriorConfidence.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture,
                    $"- engine_prior_confidence: {Num(context.EnginePriorConfidence.Value)}");
            if (context.EngineReasons is { Count: > 0 })
                sb.AppendLine("- reasons: " + string.Join("; ", context.EngineReasons));
            sb.AppendLine("Use this as the starting point of the rubric; deviate only with a stated reason.");
        }
        else
        {
            sb.AppendLine("Engine pre-score: not available — derive confidence from the rubric using the raw indicators.");
        }
        sb.AppendLine();

        if (context.HasPosition)
        {
            sb.AppendLine("Open position:");
            sb.AppendLine(CultureInfo.InvariantCulture, $"- side: {context.PositionSide ?? "LONG"}");
            if (context.Quantity.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- quantity: {FmtPrice(context.Quantity.Value, context)}");
            if (context.EntryPrice.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- entry_price: {FmtPrice(context.EntryPrice.Value, context)}");
            if (context.UnrealizedPnlPercent.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- unrealized_pnl_percent: {context.UnrealizedPnlPercent.Value.ToString("0.##", CultureInfo.InvariantCulture)}");
            if (context.StopLoss.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- stop_loss: {FmtPrice(context.StopLoss.Value, context)}");
            if (context.TakeProfit.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- take_profit: {FmtPrice(context.TakeProfit.Value, context)}");
            if (context.MinutesInPosition.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- minutes_open: {context.MinutesInPosition.Value.ToString("F0", CultureInfo.InvariantCulture)}");
            sb.AppendLine("Allowed actions now: HOLD (keep) or CLOSE (exit at market).");
        }
        else
        {
            sb.AppendLine(context.AllowShort
                ? "No open position. Allowed actions: BUY, SELL or HOLD."
                : "No open position. Allowed actions: BUY or HOLD (spot account, no shorting).");
        }
        sb.AppendLine();

        if (!string.IsNullOrWhiteSpace(newsContext))
        {
            sb.AppendLine("Recent news (secondary factor, may contain unrelated headlines):");
            sb.AppendLine(newsContext);
        }
        else
        {
            sb.AppendLine("Recent news: none available.");
        }
        sb.AppendLine();

        sb.AppendLine(CultureInfo.InvariantCulture,
            $"Execution threshold: signals with final confidence >= {Num(context.MinConfidence)} may be executed by the engine; the engine blends your confidence with its own pre-score, so an honest number matters more than a safe one.");
        sb.AppendLine("Provide the trading decision as the JSON object described above.");

        // Мягкие переключатели режима рассуждений Qwen3.
        sb.AppendLine(enableThinking ? "/think" : "/no_think");
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>assistant");

        // F3: пустой think-блок НЕ префиллим — модель открывает его сама.
        return sb.ToString();
    }

    /// <summary>
    /// Промпт «ремонта»: модель видит свой невалидный (или пустой) ответ и текст ошибки.
    /// Дешевле и надёжнее, чем повторять исходный промпт вслепую. Think не префиллится.
    /// </summary>
    public string BuildRepairPrompt(
        string originalPrompt,
        string invalidResponse,
        string error,
        bool enableThinking = true)
    {
        var sb = new StringBuilder();
        sb.Append(originalPrompt);
        sb.AppendLine(Trim(invalidResponse, 1500));
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>user");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"Your previous answer could not be parsed: {error}.");
        sb.AppendLine("Reply again with ONLY the JSON object (action, confidence, entry_price, stop_loss, take_profit, reasoning).");
        sb.AppendLine("No markdown, no code fences, no explanations outside JSON. Use null for prices on HOLD/CLOSE.");
        sb.AppendLine("Derive confidence from the rubric and the engine pre-score above; do not answer with an empty message.");
        if (enableThinking)
            sb.AppendLine("If you need to think, keep it under 40 words, then output the JSON.");
        sb.AppendLine(enableThinking ? "/think" : "/no_think");
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>assistant");
        return sb.ToString();
    }

    /// <summary>Точность цен: из tickSize, иначе из конфига символа (BTTC ≠ BTC).</summary>
    private static int PriceDecimals(AiRequestContext context)
    {
        if (context.TickSize.HasValue && context.TickSize.Value > 0m)
        {
            var tick = context.TickSize.Value;
            var decimals = 0;
            while (decimals < 18 && Math.Round(tick, decimals) != tick)
                decimals++;
            return decimals;
        }

        return Math.Clamp(context.PriceDecimals, 0, 18);
    }

    private static string FmtPrice(decimal value, AiRequestContext context) =>
        value.ToString("F" + PriceDecimals(context).ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture);

    private static string Num(decimal value) => value.ToString("0.##", CultureInfo.InvariantCulture);

    private static string Trim(string text, int max) =>
        string.IsNullOrEmpty(text) || text.Length <= max ? text : text[..max] + "…";
}
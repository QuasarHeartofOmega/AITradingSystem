using System.Globalization;
using System.Text;

namespace AITradingSystem.Services.AI;

/// <summary>
/// Формирование промптов для AI-модели в формате ChatML (FR-4.2).
/// Промпт учитывает: спот-ограничения (нет шорта), открытую позицию, минимальный R/R
/// и режим рассуждений (thinking) — модель сначала проверяет себя, потом выдаёт JSON.
/// </summary>
public sealed class PromptBuilder
{
    public string BuildTradingPrompt(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        bool enableThinking = false,
        AiRequestContext? context = null)
    {
        context ??= new AiRequestContext();
        var sb = new StringBuilder();

        sb.AppendLine("<|im_start|>system");
        sb.AppendLine("You are a disciplined cryptocurrency SPOT trading analyst. You manage a real account and must avoid invalid orders.");
        sb.AppendLine("Indicator values are normalized: trend/momentum in [-1, 1], volatility in [0, 1]. Positive = bullish, negative = bearish.");
        sb.AppendLine();
        sb.AppendLine("Hard rules:");
        sb.AppendLine(context.AllowShort
            ? "1. BUY opens a long, SELL opens a short, CLOSE closes the open position, HOLD does nothing."
            : "1. This is a SPOT account: shorting is NOT possible. BUY opens a long. SELL or CLOSE closes an existing long. Without an open position SELL is ignored, so use HOLD instead.");
        sb.AppendLine("2. If a position is already open, choose only HOLD or CLOSE (never re-open the same symbol).");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"3. For a new entry: stop_loss and take_profit must give risk/reward >= {context.MinRiskReward.ToString("0.##", CultureInfo.InvariantCulture)}.");
        sb.AppendLine("4. For BUY: stop_loss < entry_price < take_profit. Prices must be realistic and close to the current price (within a few ATR).");
        sb.AppendLine("5. Never invent prices far from the market. entry_price should be within ~0.5% of the current price.");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"6. Use confidence below {context.MinConfidence.ToString("0.##", CultureInfo.InvariantCulture)} when the setup is unclear — such signals are not executed.");
        sb.AppendLine("7. News sentiment is a secondary factor; technical structure has priority.");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"8. The engine re-calculates the actual stop at {context.StopLossAtrMultiplier.ToString("0.##", CultureInfo.InvariantCulture)} x ATR from the real fill price, so keep stop_loss near that distance instead of an arbitrary round number.");
        sb.AppendLine();
        sb.AppendLine("Answer format — ONE valid JSON object, no markdown, no comments, no extra text:");
        sb.AppendLine("{");
        sb.AppendLine("  \"action\": \"BUY\" | \"SELL\" | \"HOLD\" | \"CLOSE\",");
        sb.AppendLine("  \"confidence\": 0.0-1.0,");
        sb.AppendLine("  \"entry_price\": number or null,");
        sb.AppendLine("  \"stop_loss\": number or null,");
        sb.AppendLine("  \"take_profit\": number or null,");
        sb.AppendLine("  \"reasoning\": \"one or two sentences\"");
        sb.AppendLine("}");
        sb.AppendLine("For HOLD and CLOSE all price fields must be null.");

        if (enableThinking)
        {
            sb.AppendLine();
            sb.AppendLine("Before the JSON, think step by step inside <think> ... </think> (max ~150 words):");
            sb.AppendLine("trend and momentum agreement, volatility, volume confirmation, news risk, position state,");
            sb.AppendLine("then verify your own answer: action allowed, prices ordered correctly, R/R >= required minimum.");
            sb.AppendLine("After the closing think tag output ONLY the JSON object.");
        }

        sb.AppendLine("<|im_end|>");

        sb.AppendLine("<|im_start|>user");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Symbol: {symbol}");

        var priceText = indicators.TryGetValue("price", out var p)
            ? p.ToString("0.########", CultureInfo.InvariantCulture)
            : "unknown";
        sb.AppendLine(CultureInfo.InvariantCulture, $"Current price: {priceText}");

        if (indicators.TryGetValue("atr_pct", out var atrPct))
        {
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"ATR: {(atrPct * 100m).ToString("0.###", CultureInfo.InvariantCulture)}% of price (use it to scale stop distance)");
        }

        sb.AppendLine();
        sb.AppendLine("Technical indicators (normalized):");
        foreach (var kvp in indicators)
        {
            if (string.Equals(kvp.Key, "price", StringComparison.OrdinalIgnoreCase))
                continue;

            sb.AppendLine(CultureInfo.InvariantCulture,
                $"- {kvp.Key}: {kvp.Value.ToString("0.####", CultureInfo.InvariantCulture)}");
        }
        sb.AppendLine();

        if (context.HasPosition)
        {
            sb.AppendLine("Open position:");
            sb.AppendLine(CultureInfo.InvariantCulture, $"- side: {context.PositionSide ?? "LONG"}");
            if (context.Quantity.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- quantity: {Fmt(context.Quantity.Value)}");
            if (context.EntryPrice.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- entry_price: {Fmt(context.EntryPrice.Value)}");
            if (context.UnrealizedPnlPercent.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- unrealized_pnl_percent: {context.UnrealizedPnlPercent.Value.ToString("0.##", CultureInfo.InvariantCulture)}");
            if (context.StopLoss.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- stop_loss: {Fmt(context.StopLoss.Value)}");
            if (context.TakeProfit.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- take_profit: {Fmt(context.TakeProfit.Value)}");
            if (context.MinutesInPosition.HasValue)
                sb.AppendLine(CultureInfo.InvariantCulture, $"- minutes_open: {context.MinutesInPosition.Value.ToString("F0", CultureInfo.InvariantCulture)}");
            sb.AppendLine("Allowed actions now: HOLD (keep) or CLOSE (exit at market).");
        }
        else
        {
            sb.AppendLine(context.AllowShort
                ? "No open position. Allowed actions: BUY, SELL or HOLD."
                : "No open position. Allowed actions: BUY or HOLD (spot account, no shorting).");
        }
        sb.AppendLine();

        if (!string.IsNullOrWhiteSpace(newsContext))
        {
            sb.AppendLine("Recent news:");
            sb.AppendLine(newsContext);
        }
        else
        {
            sb.AppendLine("Recent news: none available.");
        }
        sb.AppendLine();

        sb.AppendLine("Self-check before answering: is the action allowed, are prices ordered correctly, is R/R sufficient, is confidence honest?");
        sb.AppendLine("Provide the trading decision as the JSON object described above.");

        // Мягкие переключатели режима рассуждений Qwen3.
        sb.AppendLine(enableThinking ? "/think" : "/no_think");
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>assistant");

        if (enableThinking)
            sb.AppendLine("<think>");

        return sb.ToString();
    }

    /// <summary>
    /// Промпт «ремонта»: модель видит свой невалидный ответ и текст ошибки.
    /// Дешевле и надёжнее, чем повторять исходный промпт вслепую.
    /// </summary>
    public string BuildRepairPrompt(string originalPrompt, string invalidResponse, string error)
    {
        var sb = new StringBuilder();
        sb.Append(originalPrompt);
        sb.AppendLine(CultureInfo.InvariantCulture, Trim(invalidResponse, 1500));
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>user");
        sb.AppendLine(CultureInfo.InvariantCulture,
            $"Your previous answer could not be parsed: {error}.");
        sb.AppendLine("Reply again with ONLY the JSON object (action, confidence, entry_price, stop_loss, take_profit, reasoning).");
        sb.AppendLine("No markdown, no code fences, no explanations outside JSON. Use null for prices on HOLD/CLOSE.");
        sb.AppendLine("/no_think");
        sb.AppendLine("<|im_end|>");
        sb.AppendLine("<|im_start|>assistant");
        return sb.ToString();
    }

    private static string Fmt(decimal value) => value.ToString("0.########", CultureInfo.InvariantCulture);

    private static string Trim(string text, int max) =>
        string.IsNullOrEmpty(text) || text.Length <= max ? text : text[..max] + "…";
}

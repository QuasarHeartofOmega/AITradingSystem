namespace AITradingSystem.Services.AI;

/// <summary>
/// Контекст запроса к модели: что уже открыто по символу и какие ограничения действуют.
/// Без этого модель предлагала SELL по споту (шорт невозможен) и не могла закрыть позицию.
/// </summary>
public sealed class AiRequestContext
{
    /// <summary>Есть открытая позиция по символу.</summary>
    public bool HasPosition { get; init; }

    /// <summary>Сторона открытой позиции ("LONG"/"SHORT").</summary>
    public string? PositionSide { get; init; }

    /// <summary>Цена входа открытой позиции.</summary>
    public decimal? EntryPrice { get; init; }

    /// <summary>Объём открытой позиции.</summary>
    public decimal? Quantity { get; init; }

    /// <summary>Текущий нереализованный PnL, %.</summary>
    public decimal? UnrealizedPnlPercent { get; init; }

    /// <summary>Текущий Stop-Loss.</summary>
    public decimal? StopLoss { get; init; }

    /// <summary>Текущий Take-Profit.</summary>
    public decimal? TakeProfit { get; init; }

    /// <summary>Сколько минут позиция открыта.</summary>
    public double? MinutesInPosition { get; init; }

    /// <summary>Разрешён ли шорт (на споте Binance — нет).</summary>
    public bool AllowShort { get; init; }

    /// <summary>Минимальное соотношение риск/прибыль.</summary>
    public decimal MinRiskReward { get; init; } = 2m;

    /// <summary>Минимальная уверенность для исполнения сигнала.</summary>
    public decimal MinConfidence { get; init; } = 0.55m;

    /// <summary>Множитель ATR для Stop-Loss (для подсказки модели).</summary>
    public decimal StopLossAtrMultiplier { get; init; } = 2m;
}

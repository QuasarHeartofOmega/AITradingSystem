using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics.X86;
using System.Text;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>
/// Загрузчик нативных библиотек llama.cpp для LLamaSharp.
///
/// Зачем это нужно (корень ошибки "The type initializer for 'LLama.Native.NativeApi' threw an exception"):
/// 1) Пакет LLamaSharp.Backend.Cpu кладёт нативные DLL через MSBuild .props (Content-элементы).
///    Content НЕ передаётся транзитивно: библиотеки копились в bin проекта Services,
///    но НЕ попадали в bin запускаемого проекта UI.
/// 2) Для net8.0 NuGet выбирает сборку LLamaSharp из lib/netstandard2.0, а в ней нет
///    логики поиска по папкам runtimes/&lt;rid&gt;/native/avx*. Загрузка идёт обычным
///    DllImport("llama"), т.е. DLL должна лежать рядом с exe (или быть найдена загрузчиком).
///
/// Здесь мы регистрируем DllImportResolver для сборки LLamaSharp, который сам ищет
/// llama.dll / ggml*.dll рядом с exe, в runtimes/&lt;rid&gt;/native/&lt;avx&gt; и по пути
/// из конфигурации AI:NativeLibraryPath, предварительно подгружая зависимости ggml.
/// </summary>
public static class LlamaNativeLoader
{
    private static readonly object Sync = new();
    private static readonly Dictionary<string, IntPtr> LoadedHandles = new(StringComparer.OrdinalIgnoreCase);
    private static bool _resolverRegistered;
    private static string? _explicitPath;
    private static ILogger? _logger;

    /// <summary>
    /// Явный уровень набора инструкций ("avx2", "avx512", "avx", "noavx").
    /// Если null — определяется автоматически по возможностям CPU.
    /// </summary>
    public static string? PreferredAvxLevel { get; set; }

    /// <summary>
    /// Регистрирует резолвер нативных библиотек. Идемпотентно и потокобезопасно.
    /// Должен вызываться ДО первого обращения к любому API LLamaSharp
    /// (в т.ч. до new ModelParams(...), который триггерит NativeApi..cctor).
    /// </summary>
    public static void Initialize(string? explicitNativePath = null, ILogger? logger = null)
    {
        lock (Sync)
        {
            if (!string.IsNullOrWhiteSpace(explicitNativePath))
                _explicitPath = explicitNativePath.Trim();

            if (logger != null)
                _logger = logger;

            if (_resolverRegistered)
                return;

            try
            {
                var assembly = FindLlamaSharpAssembly();
                NativeLibrary.SetDllImportResolver(assembly, ImportResolver);
                _resolverRegistered = true;
                _logger?.LogDebug("DllImportResolver для LLamaSharp зарегистрирован");
            }
            catch (InvalidOperationException ex)
            {
                // Резолвер для этой сборки уже кем-то зарегистрирован — не падаем.
                _resolverRegistered = true;
                _logger?.LogDebug(ex, "DllImportResolver для LLamaSharp уже зарегистрирован");
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Не удалось зарегистрировать DllImportResolver для LLamaSharp");
            }
        }
    }

    /// <summary>
    /// Проверяет, что llama доступна, и возвращает путь к найденной библиотеке.
    /// Бросает FileNotFoundException с понятной инструкцией, если ничего не найдено.
    /// </summary>
    public static string EnsureAvailable(string? explicitNativePath = null, ILogger? logger = null)
    {
        Initialize(explicitNativePath, logger);

        if (TryFindLibraryFile("llama", out var path))
        {
            _logger?.LogInformation("Нативная библиотека llama найдена: {Path}", path);
            return path;
        }

        throw new FileNotFoundException(BuildNotFoundMessage());
    }

    /// <summary>
    /// Диагностическая строка: где искали и что нашли.
    /// </summary>
    public static string GetDiagnostics()
    {
        var sb = new StringBuilder();
        sb.Append("RID: ").Append(GetRuntimeIdentifier())
          .Append(", OS: ").Append(RuntimeInformation.OSDescription)
          .Append(", Arch: ").Append(RuntimeInformation.OSArchitecture)
          .Append(", AVX2: ").Append(Avx2.IsSupported)
          .Append(", AVX512F: ").Append(Avx512F.IsSupported);

        foreach (var dir in GetCandidateDirectories())
        {
            sb.AppendLine();
            sb.Append("  ").Append(dir).Append(" -> ")
              .Append(Directory.Exists(dir) ? "есть каталог" : "нет каталога");

            if (Directory.Exists(dir))
            {
                var llama = Path.Combine(dir, GetFileName("llama"));
                sb.Append(", llama: ").Append(File.Exists(llama) ? "найден" : "НЕТ");
            }
        }

        return sb.ToString();
    }

    private static Assembly FindLlamaSharpAssembly()
    {
        foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
        {
            if (string.Equals(asm.GetName().Name, "LLamaSharp", StringComparison.OrdinalIgnoreCase))
                return asm;
        }

        // Загрузка сборки НЕ запускает статические конструкторы её типов,
        // поэтому это безопасно делать до регистрации резолвера.
        return Assembly.Load(new AssemblyName("LLamaSharp"));
    }

    private static IntPtr ImportResolver(string libraryName, Assembly assembly, DllImportSearchPath? searchPath)
    {
        var baseName = NormalizeLibraryName(libraryName);
        if (baseName == null)
            return IntPtr.Zero; // не наша библиотека — пусть CLR ищет сама

        lock (Sync)
        {
            if (LoadedHandles.TryGetValue(baseName, out var cached) && cached != IntPtr.Zero)
                return cached;

            var fileName = GetFileName(baseName);

            foreach (var dir in GetCandidateDirectories())
            {
                var fullPath = Path.Combine(dir, fileName);
                if (!File.Exists(fullPath))
                    continue;

                // llama.dll линкуется с ggml*.dll — подгружаем их из того же каталога заранее,
                // иначе загрузчик Windows ищет зависимости рядом с exe и не находит.
                if (baseName is "llama" or "mtmd")
                    PreloadDependencies(dir);

                if (NativeLibrary.TryLoad(fullPath, out var handle) && handle != IntPtr.Zero)
                {
                    LoadedHandles[baseName] = handle;
                    _logger?.LogInformation("Нативная библиотека {Name} загружена из {Path}", baseName, fullPath);
                    return handle;
                }

                _logger?.LogWarning(
                    "Не удалось загрузить {Path}. Обычно причина — отсутствующий Microsoft Visual C++ Redistributable x64.",
                    fullPath);
            }
        }

        return IntPtr.Zero;
    }

    private static void PreloadDependencies(string directory)
    {
        // Порядок важен: ggml-base <- ggml <- ggml-cpu <- llama
        string[] deps = { "ggml-base", "ggml", "ggml-cpu" };

        foreach (var dep in deps)
        {
            if (LoadedHandles.ContainsKey(dep))
                continue;

            var path = Path.Combine(directory, GetFileName(dep));
            if (!File.Exists(path))
                continue;

            if (NativeLibrary.TryLoad(path, out var handle) && handle != IntPtr.Zero)
                LoadedHandles[dep] = handle;
        }
    }

    private static bool TryFindLibraryFile(string baseName, out string path)
    {
        var fileName = GetFileName(baseName);

        foreach (var dir in GetCandidateDirectories())
        {
            var candidate = Path.Combine(dir, fileName);
            if (File.Exists(candidate))
            {
                path = candidate;
                return true;
            }
        }

        path = string.Empty;
        return false;
    }

    private static IEnumerable<string> GetCandidateDirectories()
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var dir in EnumerateCandidateDirectories())
        {
            if (string.IsNullOrWhiteSpace(dir))
                continue;

            string full;
            try
            {
                full = Path.GetFullPath(dir);
            }
            catch (Exception)
            {
                continue;
            }

            if (seen.Add(full))
                yield return full;
        }
    }

    private static IEnumerable<string> EnumerateCandidateDirectories()
    {
        // 1. Явный путь из конфигурации (файл или каталог).
        if (!string.IsNullOrWhiteSpace(_explicitPath))
        {
            var explicitPath = _explicitPath!;

            if (File.Exists(explicitPath))
            {
                var dir = Path.GetDirectoryName(Path.GetFullPath(explicitPath));
                if (!string.IsNullOrEmpty(dir))
                    yield return dir;
            }
            else
            {
                yield return explicitPath;

                if (!Path.IsPathRooted(explicitPath))
                    yield return Path.Combine(AppContext.BaseDirectory, explicitPath);
            }
        }

        var baseDir = AppContext.BaseDirectory;
        var rid = GetRuntimeIdentifier();

        // 2. Рядом с exe (основной вариант — сюда их кладёт сборка проекта UI).
        yield return baseDir;

        // 3. Стандартная раскладка NuGet-пакета LLamaSharp.Backend.*.
        foreach (var level in GetAvxLevels())
            yield return Path.Combine(baseDir, "runtimes", rid, "native", level);

        yield return Path.Combine(baseDir, "runtimes", rid, "native");

        foreach (var level in GetAvxLevels())
            yield return Path.Combine(baseDir, level);

        // 4. Текущий рабочий каталог (запуск из другой папки).
        var cwd = Directory.GetCurrentDirectory();
        yield return cwd;

        foreach (var level in GetAvxLevels())
            yield return Path.Combine(cwd, "runtimes", rid, "native", level);
    }

    private static IEnumerable<string> GetAvxLevels()
    {
        if (!string.IsNullOrWhiteSpace(PreferredAvxLevel))
        {
            yield return PreferredAvxLevel!.Trim();
            yield break;
        }

        // avx2 первым: он есть у любого CPU с 2013 года и заведомо совместим.
        if (Avx2.IsSupported)
            yield return "avx2";

        if (Avx512F.IsSupported)
            yield return "avx512";

        if (Avx.IsSupported)
            yield return "avx";

        yield return "noavx";
    }

    private static string GetRuntimeIdentifier()
    {
        var arch = RuntimeInformation.OSArchitecture switch
        {
            Architecture.X64 => "x64",
            Architecture.X86 => "x86",
            Architecture.Arm64 => "arm64",
            Architecture.Arm => "arm",
            _ => RuntimeInformation.OSArchitecture.ToString().ToLowerInvariant()
        };

        if (OperatingSystem.IsWindows()) return $"win-{arch}";
        if (OperatingSystem.IsLinux()) return $"linux-{arch}";
        if (OperatingSystem.IsMacOS()) return $"osx-{arch}";
        return $"unknown-{arch}";
    }

    private static string GetFileName(string baseName)
    {
        if (OperatingSystem.IsWindows()) return baseName + ".dll";
        if (OperatingSystem.IsMacOS()) return "lib" + baseName + ".dylib";
        return "lib" + baseName + ".so";
    }

    private static string? NormalizeLibraryName(string libraryName)
    {
        var name = libraryName.Trim().ToLowerInvariant();

        if (name.EndsWith(".dll", StringComparison.Ordinal) ||
            name.EndsWith(".so", StringComparison.Ordinal) ||
            name.EndsWith(".dylib", StringComparison.Ordinal))
        {
            name = Path.GetFileNameWithoutExtension(name);
        }

        if (name.StartsWith("lib", StringComparison.Ordinal))
            name = name[3..];

        return name switch
        {
            "llama" or "ggml" or "ggml-base" or "ggml-cpu" or "ggml-cuda" or
            "ggml-metal" or "ggml-blas" or "ggml-rpc" or "ggml-vulkan" or
            "mtmd" or "llava" => name,
            _ => null
        };
    }

    private static string BuildNotFoundMessage()
    {
        var sb = new StringBuilder();
        sb.AppendLine("Нативная библиотека llama.cpp не найдена (LLamaSharp.Backend.Cpu).");
        sb.AppendLine("Что сделать:");
        sb.AppendLine("  1) Пересобрать проект AITradingSystem.UI (не только Services) — нативные DLL копируются в каталог exe целевой сборкой UI.");
        sb.AppendLine("  2) Убедиться, что рядом с AITradingSystem.UI.exe лежат llama.dll, ggml.dll, ggml-base.dll, ggml-cpu.dll.");
        sb.AppendLine("  3) Если сборка идёт на машину без NuGet-кэша — скопировать эти DLL вручную из пакета LLamaSharp.Backend.Cpu");
        sb.AppendLine("     (%USERPROFILE%\\.nuget\\packages\\llamasharp.backend.cpu\\0.30.0\\LLamaSharpRuntimes\\win-x64\\native\\avx2).");
        sb.AppendLine("  4) Либо указать путь к ним в appsettings.json: AI:NativeLibraryPath (каталог или полный путь к llama.dll).");
        sb.AppendLine("  5) Установить Microsoft Visual C++ Redistributable 2015-2022 x64 — без него DLL не грузится.");
        sb.AppendLine("Диагностика поиска:");
        sb.AppendLine(GetDiagnostics());
        return sb.ToString();
    }
}

using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics.X86;
using System.Text;
using AITradingSystem.Common.Configuration;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>
/// Загрузчик нативных библиотек llama.cpp для LLamaSharp с выбором бэкенда.
///
/// Поддерживаются наборы: CPU (avx/avx2/avx512/noavx), CUDA 11/12 (NVIDIA), Vulkan (AMD/Intel/NVIDIA).
/// Библиотеки ищутся рядом с exe, в runtimes/&lt;rid&gt;/native/&lt;backend&gt; и по пути AI:NativeLibraryPath.
/// Резолвер регистрируется ДО первого вызова API LLamaSharp (иначе NativeApi..cctor падает).
/// </summary>
public static class LlamaNativeLoader
{
    private static readonly object Sync = new();
    private static readonly Dictionary<string, IntPtr> LoadedHandles = new(StringComparer.OrdinalIgnoreCase);
    private static bool _resolverRegistered;
    private static string? _explicitPath;
    private static ILogger? _logger;

    /// <summary>Активный бэкенд (влияет на порядок поиска каталогов и предзагрузку зависимостей).</summary>
    public static AiBackend ActiveBackend { get; private set; } = AiBackend.Cpu;

    /// <summary>Каталог, из которого реально загружена llama (для диагностики).</summary>
    public static string? LoadedFromDirectory { get; private set; }

    /// <summary>Явный уровень набора инструкций CPU ("avx2", "avx512", "avx", "noavx").</summary>
    public static string? PreferredAvxLevel { get; set; }

    /// <summary>
    /// Выбирает бэкенд до регистрации резолвера. Можно вызывать повторно до загрузки модели.
    /// </summary>
    public static void UseBackend(AiBackend backend, ILogger? logger = null)
    {
        lock (Sync)
        {
            if (logger != null) _logger = logger;

            if (LoadedHandles.ContainsKey("llama") && ActiveBackend != backend)
            {
                _logger?.LogWarning(
                    "Бэкенд уже загружен ({Active}); переключение на {Requested} потребует перезапуска приложения",
                    ActiveBackend, backend);
                return;
            }

            ActiveBackend = backend;
            _logger?.LogInformation("Нативный бэкенд llama.cpp: {Backend}", backend);
        }
    }

    /// <summary>
    /// Есть ли на диске нативные файлы выбранного бэкенда
    /// (llama + ggml-cuda для CUDA, llama + ggml-vulkan для Vulkan).
    /// </summary>
    public static bool HasBackendFiles(AiBackend backend)
    {
        var marker = backend switch
        {
            AiBackend.Cuda11 or AiBackend.Cuda12 => "ggml-cuda",
            AiBackend.Vulkan => "ggml-vulkan",
            _ => "ggml-cpu"
        };

        foreach (var dir in GetCandidateDirectories(backend))
        {
            if (File.Exists(Path.Combine(dir, GetFileName("llama"))) &&
                File.Exists(Path.Combine(dir, GetFileName(marker))))
                return true;
        }

        // CUDA/Vulkan-сборки иногда кладут backend-DLL отдельно от llama.dll —
        // тогда считаем бэкенд доступным, если есть сама backend-библиотека.
        if (backend != AiBackend.Cpu)
        {
            foreach (var dir in GetCandidateDirectories(backend))
            {
                if (File.Exists(Path.Combine(dir, GetFileName(marker))))
                    return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Регистрирует DllImportResolver для сборки LLamaSharp. Идемпотентно и потокобезопасно.
    /// </summary>
    public static void Initialize(string? explicitNativePath = null, ILogger? logger = null)
    {
        lock (Sync)
        {
            if (!string.IsNullOrWhiteSpace(explicitNativePath))
                _explicitPath = explicitNativePath.Trim();

            if (logger != null)
                _logger = logger;

            if (_resolverRegistered)
                return;

            try
            {
                var assembly = FindLlamaSharpAssembly();
                NativeLibrary.SetDllImportResolver(assembly, ImportResolver);
                _resolverRegistered = true;
                _logger?.LogDebug("DllImportResolver для LLamaSharp зарегистрирован");
            }
            catch (InvalidOperationException ex)
            {
                _resolverRegistered = true;
                _logger?.LogDebug(ex, "DllImportResolver для LLamaSharp уже зарегистрирован");
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Не удалось зарегистрировать DllImportResolver для LLamaSharp");
            }
        }
    }

    /// <summary>
    /// Проверяет, что llama доступна, и возвращает путь к найденной библиотеке.
    /// </summary>
    public static string EnsureAvailable(string? explicitNativePath = null, ILogger? logger = null)
    {
        Initialize(explicitNativePath, logger);

        if (TryFindLibraryFile("llama", out var path))
        {
            _logger?.LogInformation("Нативная библиотека llama найдена: {Path} (бэкенд {Backend})", path, ActiveBackend);
            return path;
        }

        throw new FileNotFoundException(BuildNotFoundMessage());
    }

    /// <summary>Диагностика: где искали и что нашли.</summary>
    public static string GetDiagnostics()
    {
        var sb = new StringBuilder();
        sb.Append("Backend: ").Append(ActiveBackend)
          .Append(", RID: ").Append(GetRuntimeIdentifier())
          .Append(", OS: ").Append(RuntimeInformation.OSDescription)
          .Append(", Arch: ").Append(RuntimeInformation.OSArchitecture)
          .Append(", AVX2: ").Append(Avx2.IsSupported)
          .Append(", AVX512F: ").Append(Avx512F.IsSupported);

        foreach (var dir in GetCandidateDirectories(ActiveBackend))
        {
            sb.AppendLine();
            sb.Append("  ").Append(dir).Append(" -> ")
              .Append(Directory.Exists(dir) ? "есть каталог" : "нет каталога");

            if (!Directory.Exists(dir)) continue;

            sb.Append(", llama: ").Append(File.Exists(Path.Combine(dir, GetFileName("llama"))) ? "найден" : "НЕТ");

            foreach (var marker in new[] { "ggml-cpu", "ggml-cuda", "ggml-vulkan" })
            {
                if (File.Exists(Path.Combine(dir, GetFileName(marker))))
                    sb.Append(", ").Append(marker).Append(": есть");
            }
        }

        return sb.ToString();
    }

    private static Assembly FindLlamaSharpAssembly()
    {
        foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
        {
            if (string.Equals(asm.GetName().Name, "LLamaSharp", StringComparison.OrdinalIgnoreCase))
                return asm;
        }

        return Assembly.Load(new AssemblyName("LLamaSharp"));
    }

    private static IntPtr ImportResolver(string libraryName, Assembly assembly, DllImportSearchPath? searchPath)
    {
        var baseName = NormalizeLibraryName(libraryName);
        if (baseName == null)
            return IntPtr.Zero;

        lock (Sync)
        {
            if (LoadedHandles.TryGetValue(baseName, out var cached) && cached != IntPtr.Zero)
                return cached;

            var fileName = GetFileName(baseName);

            foreach (var dir in GetCandidateDirectories(ActiveBackend))
            {
                var fullPath = Path.Combine(dir, fileName);
                if (!File.Exists(fullPath))
                    continue;

                if (baseName is "llama" or "mtmd")
                    PreloadDependencies(dir);

                if (NativeLibrary.TryLoad(fullPath, out var handle) && handle != IntPtr.Zero)
                {
                    LoadedHandles[baseName] = handle;
                    LoadedFromDirectory = dir;
                    _logger?.LogInformation("Нативная библиотека {Name} загружена из {Path}", baseName, fullPath);
                    return handle;
                }

                _logger?.LogWarning(
                    "Не удалось загрузить {Path}. Частые причины: нет Microsoft Visual C++ Redistributable x64, " +
                    "нет драйвера GPU/CUDA-рантайма, либо сборка не под этот CPU.", fullPath);
            }

            return IntPtr.Zero;
        }
    }

    private static void PreloadDependencies(string directory)
    {
        // Порядок важен: ggml-base <- ggml <- ggml-cpu <- backend <- llama.
        var deps = new List<string> { "ggml-base", "ggml", "ggml-cpu" };

        switch (ActiveBackend)
        {
            case AiBackend.Cuda12:
                deps.AddRange(new[] { "cudart64_12", "cublasLt64_12", "cublas64_12", "ggml-cuda" });
                break;
            case AiBackend.Cuda11:
                deps.AddRange(new[] { "cudart64_110", "cublasLt64_11", "cublas64_11", "ggml-cuda" });
                break;
            case AiBackend.Vulkan:
                deps.Add("ggml-vulkan");
                break;
        }

        foreach (var dep in deps)
        {
            if (LoadedHandles.ContainsKey(dep))
                continue;

            var path = Path.Combine(directory, GetFileName(dep));
            if (!File.Exists(path))
                continue;

            if (NativeLibrary.TryLoad(path, out var handle) && handle != IntPtr.Zero)
            {
                LoadedHandles[dep] = handle;
                _logger?.LogDebug("Предзагружена зависимость {Dep} из {Path}", dep, path);
            }
            else
            {
                _logger?.LogDebug("Не удалось предзагрузить {Path}", path);
            }
        }
    }

    private static bool TryFindLibraryFile(string baseName, out string path)
    {
        var fileName = GetFileName(baseName);

        foreach (var dir in GetCandidateDirectories(ActiveBackend))
        {
            var candidate = Path.Combine(dir, fileName);
            if (File.Exists(candidate))
            {
                path = candidate;
                return true;
            }
        }

        path = string.Empty;
        return false;
    }

    private static IEnumerable<string> GetCandidateDirectories(AiBackend backend)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var dir in EnumerateCandidateDirectories(backend))
        {
            if (string.IsNullOrWhiteSpace(dir))
                continue;

            string full;
            try
            {
                full = Path.GetFullPath(dir);
            }
            catch (Exception)
            {
                continue;
            }

            if (seen.Add(full))
                yield return full;
        }
    }

    private static IEnumerable<string> EnumerateCandidateDirectories(AiBackend backend)
    {
        // 1. Явный путь из конфигурации (файл или каталог).
        if (!string.IsNullOrWhiteSpace(_explicitPath))
        {
            var explicitPath = _explicitPath!;

            if (File.Exists(explicitPath))
            {
                var dir = Path.GetDirectoryName(Path.GetFullPath(explicitPath));
                if (!string.IsNullOrEmpty(dir))
                    yield return dir;
            }
            else
            {
                yield return explicitPath;

                if (!Path.IsPathRooted(explicitPath))
                    yield return Path.Combine(AppContext.BaseDirectory, explicitPath);
            }
        }

        var baseDir = AppContext.BaseDirectory;
        var cwd = Directory.GetCurrentDirectory();
        var rid = GetRuntimeIdentifier();
        var backendDirs = BackendSubdirs(backend);

        foreach (var root in new[] { baseDir, cwd })
        {
            // 2. Подкаталоги бэкенда рядом с exe (сюда их кладёт сборка проекта UI).
            foreach (var sub in backendDirs)
            {
                yield return Path.Combine(root, sub);
                yield return Path.Combine(root, "runtimes", rid, "native", sub);
            }

            // 3. Стандартная раскладка NuGet-пакета LLamaSharp.Backend.*.
            yield return Path.Combine(root, "runtimes", rid, "native");

            foreach (var level in GetAvxLevels())
                yield return Path.Combine(root, "runtimes", rid, "native", level);

            // 4. Плоская раскладка (DLL прямо рядом с exe).
            yield return root;

            foreach (var level in GetAvxLevels())
                yield return Path.Combine(root, level);
        }
    }

    private static IEnumerable<string> BackendSubdirs(AiBackend backend) => backend switch
    {
        AiBackend.Cuda12 => new[] { "cuda12", "cuda", "gpu" },
        AiBackend.Cuda11 => new[] { "cuda11", "cuda", "gpu" },
        AiBackend.Vulkan => new[] { "vulkan", "gpu" },
        _ => new[] { "cpu" }
    };

    private static IEnumerable<string> GetAvxLevels()
    {
        if (!string.IsNullOrWhiteSpace(PreferredAvxLevel))
        {
            yield return PreferredAvxLevel!.Trim();
            yield break;
        }

        if (Avx2.IsSupported)
            yield return "avx2";

        if (Avx512F.IsSupported)
            yield return "avx512";

        if (Avx.IsSupported)
            yield return "avx";

        yield return "noavx";
    }

    private static string GetRuntimeIdentifier()
    {
        var arch = RuntimeInformation.OSArchitecture switch
        {
            Architecture.X64 => "x64",
            Architecture.X86 => "x86",
            Architecture.Arm64 => "arm64",
            Architecture.Arm => "arm",
            _ => RuntimeInformation.OSArchitecture.ToString().ToLowerInvariant()
        };

        if (OperatingSystem.IsWindows()) return $"win-{arch}";
        if (OperatingSystem.IsLinux()) return $"linux-{arch}";
        if (OperatingSystem.IsMacOS()) return $"osx-{arch}";
        return $"unknown-{arch}";
    }

    private static string GetFileName(string baseName)
    {
        if (OperatingSystem.IsWindows()) return baseName + ".dll";
        if (OperatingSystem.IsMacOS()) return "lib" + baseName + ".dylib";
        return "lib" + baseName + ".so";
    }

    private static string? NormalizeLibraryName(string libraryName)
    {
        var name = libraryName.Trim().ToLowerInvariant();

        if (name.EndsWith(".dll", StringComparison.Ordinal) ||
            name.EndsWith(".so", StringComparison.Ordinal) ||
            name.EndsWith(".dylib", StringComparison.Ordinal))
        {
            name = Path.GetFileNameWithoutExtension(name);
        }

        if (name.StartsWith("lib", StringComparison.Ordinal))
            name = name[3..];

        return name switch
        {
            "llama" or "ggml" or "ggml-base" or "ggml-cpu" or "ggml-cuda" or
            "ggml-metal" or "ggml-blas" or "ggml-rpc" or "ggml-vulkan" or
            "mtmd" or "llava" => name,
            _ => null
        };
    }

    private static string BuildNotFoundMessage()
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Нативная библиотека llama.cpp не найдена (бэкенд {ActiveBackend}).");
        sb.AppendLine("Что сделать:");
        sb.AppendLine("  1) Пересобрать проект AITradingSystem.UI — нативные DLL копируются в каталог exe целевой сборкой UI.");
        sb.AppendLine("  2) Убедиться, что рядом с AITradingSystem.UI.exe есть llama.dll, ggml.dll, ggml-base.dll, ggml-cpu.dll");
        sb.AppendLine("     (для GPU дополнительно ggml-cuda.dll + cudart/cublas или ggml-vulkan.dll).");
        sb.AppendLine("  3) Для NVIDIA: пакет LLamaSharp.Backend.Cuda12 и свежий драйвер NVIDIA (CUDA 12 runtime идёт в пакете).");
        sb.AppendLine("  4) Для AMD/Intel: пакет LLamaSharp.Backend.Vulkan и драйвер с поддержкой Vulkan 1.2+.");
        sb.AppendLine("  5) Либо указать путь к DLL в appsettings.json: AI:NativeLibraryPath.");
        sb.AppendLine("  6) Установить Microsoft Visual C++ Redistributable 2015-2022 x64.");
        sb.AppendLine("Диагностика поиска:");
        sb.AppendLine(GetDiagnostics());
        return sb.ToString();
    }
}

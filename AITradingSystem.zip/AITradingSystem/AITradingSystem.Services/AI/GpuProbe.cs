using System.Diagnostics;
using System.Runtime.InteropServices;
using AITradingSystem.Common.Configuration;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>Результат разведки GPU: какие ускорители и рантаймы найдены в системе.</summary>
public sealed class GpuDetectionResult
{
    public List<string> NvidiaGpus { get; } = new();
    public List<string> AmdGpus { get; } = new();
    public List<string> IntelGpus { get; } = new();
    public bool HasCudaRuntime { get; set; }
    public bool HasVulkanRuntime { get; set; }
    public bool HasRocm { get; set; }
    public string Summary { get; set; } = string.Empty;

    public bool HasNvidia => NvidiaGpus.Count > 0 || HasCudaRuntime;
    public bool HasAmd => AmdGpus.Count > 0 || HasRocm;
    public bool HasAnyGpu => HasNvidia || HasAmd || IntelGpus.Count > 0;
}

/// <summary>
/// Определение железа без внешних зависимостей: nvidia-smi / rocminfo / lspci,
/// наличие рантайм-библиотек (nvcuda, amdhip64, vulkan-1) и переменных окружения.
/// Используется для выбора бэкенда llama.cpp: CUDA (NVIDIA) → Vulkan (AMD/Intel) → CPU.
/// </summary>
public static class GpuProbe
{
    private static GpuDetectionResult? _cached;
    private static readonly object Sync = new();

    /// <summary>Определить GPU (результат кэшируется).</summary>
    public static GpuDetectionResult Detect(ILogger? logger = null, bool refresh = false)
    {
        lock (Sync)
        {
            if (_cached != null && !refresh)
                return _cached;

            var result = new GpuDetectionResult();

            try
            {
                ProbeNvidia(result);
                ProbeAmd(result);
                ProbeVulkan(result);
                ProbeLinuxPci(result);
            }
            catch (Exception ex)
            {
                logger?.LogDebug(ex, "Ошибка определения GPU — считаем, что доступен только CPU");
            }

            result.Summary = BuildSummary(result);
            _cached = result;

            logger?.LogInformation("GPU: {Summary}", result.Summary);
            return result;
        }
    }

    /// <summary>
    /// Выбирает бэкенд под железо. requested=Auto → автовыбор, иначе уважаем явный выбор,
    /// но откатываемся на CPU, если нужных нативных библиотек нет.
    /// </summary>
    public static AiBackend SelectBackend(
        AiBackend requested,
        GpuDetectionResult gpu,
        Func<AiBackend, bool> backendFilesAvailable,
        ILogger? logger = null)
    {
        var order = requested switch
        {
            AiBackend.Cpu => new[] { AiBackend.Cpu },
            AiBackend.Cuda12 => new[] { AiBackend.Cuda12, AiBackend.Vulkan, AiBackend.Cpu },
            AiBackend.Cuda11 => new[] { AiBackend.Cuda11, AiBackend.Vulkan, AiBackend.Cpu },
            AiBackend.Vulkan => new[] { AiBackend.Vulkan, AiBackend.Cpu },
            _ => AutoOrder(gpu)
        };

        foreach (var candidate in order)
        {
            if (candidate != AiBackend.Cpu && !backendFilesAvailable(candidate))
            {
                logger?.LogWarning("Бэкенд {Backend} пропущен: нативные библиотеки не найдены", candidate);
                continue;
            }

            if (candidate is AiBackend.Cuda12 or AiBackend.Cuda11 &&
                !gpu.HasNvidia)
            {
                logger?.LogWarning("Бэкенд {Backend} пропущен: NVIDIA GPU не обнаружен", candidate);
                continue;
            }

            if (candidate == AiBackend.Vulkan && !gpu.HasVulkanRuntime && !gpu.HasAnyGpu)
            {
                logger?.LogWarning("Vulkan пропущен: рантайм Vulkan не найден");
                continue;
            }

            if (requested == AiBackend.Auto && candidate != AiBackend.Cpu)
                logger?.LogInformation("Автовыбор бэкенда: {Backend} ({Summary})", candidate, gpu.Summary);

            return candidate;
        }

        return AiBackend.Cpu;
    }

    private static AiBackend[] AutoOrder(GpuDetectionResult gpu)
    {
        // NVIDIA → CUDA 12 (самый быстрый путь), затем Vulkan.
        if (gpu.HasNvidia)
            return new[]
            {
                AiBackend.Cuda12,
                AiBackend.Vulkan,
                AiBackend.Cpu
            };

        // AMD/Intel → Vulkan (ROCm на Windows у llama.cpp поддерживается хуже и требует HIP SDK).
        if (gpu.HasAnyGpu)
            return new[]
            {
                AiBackend.Vulkan,
                AiBackend.Cpu
            };

        return new[] { AiBackend.Cpu };
    }

    private static void ProbeNvidia(GpuDetectionResult result)
    {
        var smi = RunTool("nvidia-smi", "--list-gpus", 4000);
        if (smi != null)
        {
            foreach (var line in smi.Split('\n', StringSplitOptions.RemoveEmptyEntries))
            {
                var trimmed = line.Trim();
                if (trimmed.Length > 0 && trimmed.Contains("GPU", StringComparison.OrdinalIgnoreCase))
                    result.NvidiaGpus.Add(trimmed);
            }
        }

        if (FileExistsInSystem("nvcuda.dll") ||
            FileExistsInSystem("libcuda.so.1") ||
            !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("CUDA_PATH")) ||
            File.Exists("/proc/driver/nvidia/version"))
            result.HasCudaRuntime = true;

        if (result.NvidiaGpus.Count > 0)
            result.HasCudaRuntime = true;
    }

    private static void ProbeAmd(GpuDetectionResult result)
    {
        if (FileExistsInSystem("amdhip64.dll") ||
            FileExistsInSystem("amdhip64_6.dll") ||
            File.Exists("/dev/kfd") ||
            Directory.Exists("/opt/rocm") ||
            !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("ROCM_PATH")) ||
            !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("HIP_PATH")))
            result.HasRocm = true;

        // Драйвер AMD Radeon (Windows): наличие user-mode драйверных DLL.
        if (FileExistsInSystem("atidxx64.dll") || FileExistsInSystem("amdxc64.dll"))
            result.AmdGpus.Add("AMD Radeon (драйвер обнаружен)");

        var rocm = RunTool("rocminfo", string.Empty, 4000);
        if (rocm != null)
        {
            result.HasRocm = true;
            foreach (var line in rocm.Split('\n'))
            {
                if (line.Contains("Marketing Name", StringComparison.OrdinalIgnoreCase) &&
                    !line.Contains("CPU", StringComparison.OrdinalIgnoreCase))
                    result.AmdGpus.Add(line.Trim());
            }
        }
    }

    private static void ProbeVulkan(GpuDetectionResult result)
    {
        if (FileExistsInSystem("vulkan-1.dll") ||
            FileExistsInSystem("libvulkan.so.1") ||
            File.Exists("/usr/lib/x86_64-linux-gnu/libvulkan.so.1") ||
            File.Exists("/usr/lib64/libvulkan.so.1"))
            result.HasVulkanRuntime = true;

        var info = RunTool("vulkaninfo", "--summary", 4000);
        if (info != null)
        {
            result.HasVulkanRuntime = true;
            foreach (var line in info.Split('\n'))
            {
                if (!line.Contains("deviceName", StringComparison.OrdinalIgnoreCase)) continue;
                var name = line.Split('=').Last().Trim();
                if (name.Contains("NVIDIA", StringComparison.OrdinalIgnoreCase)) result.NvidiaGpus.Add(name);
                else if (name.Contains("AMD", StringComparison.OrdinalIgnoreCase) ||
                         name.Contains("Radeon", StringComparison.OrdinalIgnoreCase)) result.AmdGpus.Add(name);
                else if (name.Contains("Intel", StringComparison.OrdinalIgnoreCase)) result.IntelGpus.Add(name);
            }
        }
    }

    private static void ProbeLinuxPci(GpuDetectionResult result)
    {
        if (!OperatingSystem.IsLinux()) return;

        var lspci = RunTool("lspci", string.Empty, 4000);
        if (lspci == null) return;

        foreach (var line in lspci.Split('\n'))
        {
            if (!line.Contains("VGA", StringComparison.OrdinalIgnoreCase) &&
                !line.Contains("3D controller", StringComparison.OrdinalIgnoreCase))
                continue;

            if (line.Contains("NVIDIA", StringComparison.OrdinalIgnoreCase)) result.NvidiaGpus.Add(line.Trim());
            else if (line.Contains("AMD", StringComparison.OrdinalIgnoreCase) ||
                     line.Contains("ATI", StringComparison.OrdinalIgnoreCase)) result.AmdGpus.Add(line.Trim());
            else if (line.Contains("Intel", StringComparison.OrdinalIgnoreCase)) result.IntelGpus.Add(line.Trim());
        }
    }

    private static bool FileExistsInSystem(string fileName)
    {
        try
        {
            if (OperatingSystem.IsWindows())
            {
                var system = Environment.GetFolderPath(Environment.SpecialFolder.System);
                return File.Exists(Path.Combine(system, fileName));
            }

            string[] dirs = { "/usr/lib/x86_64-linux-gnu", "/usr/lib64", "/usr/lib", "/lib/x86_64-linux-gnu" };
            return dirs.Any(d => File.Exists(Path.Combine(d, fileName)));
        }
        catch (Exception)
        {
            return false;
        }
    }

    private static string? RunTool(string fileName, string arguments, int timeoutMs)
    {
        try
        {
            using var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = fileName,
                    Arguments = arguments,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            if (!process.Start())
                return null;

            // Читаем с таймаутом: зависшая утилита не должна блокировать запуск бота.
            var readTask = process.StandardOutput.ReadToEndAsync();
            if (!readTask.Wait(timeoutMs))
            {
                try { process.Kill(true); } catch (Exception) { /* игнорируем */ }
                return null;
            }

            if (!process.WaitForExit(500))
            {
                try { process.Kill(true); } catch (Exception) { /* игнорируем */ }
                return null;
            }

            var output = readTask.Result;
            return process.ExitCode == 0 && !string.IsNullOrWhiteSpace(output) ? output : null;
        }
        catch (Exception)
        {
            // Утилиты нет в PATH — это нормально, пробуем другие признаки.
            return null;
        }
    }

    private static string BuildSummary(GpuDetectionResult g)
    {
        var parts = new List<string>
        {
            $"OS={RuntimeInformation.OSDescription}",
            $"arch={RuntimeInformation.OSArchitecture}"
        };

        if (g.NvidiaGpus.Count > 0) parts.Add("NVIDIA: " + string.Join("; ", g.NvidiaGpus.Distinct().Take(3)));
        if (g.AmdGpus.Count > 0) parts.Add("AMD: " + string.Join("; ", g.AmdGpus.Distinct().Take(3)));
        if (g.IntelGpus.Count > 0) parts.Add("Intel: " + string.Join("; ", g.IntelGpus.Distinct().Take(2)));
        if (!g.HasAnyGpu) parts.Add("GPU не обнаружен");

        parts.Add($"CUDA={(g.HasCudaRuntime ? "yes" : "no")}");
        parts.Add($"Vulkan={(g.HasVulkanRuntime ? "yes" : "no")}");
        parts.Add($"ROCm={(g.HasRocm ? "yes" : "no")}");

        return string.Join(", ", parts);
    }
}

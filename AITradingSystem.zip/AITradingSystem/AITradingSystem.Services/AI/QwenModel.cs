using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using LLama;
using LLama.Common;
using LLama.Sampling;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>
/// AI-модель Qwen через LLamaSharp (FR-4.1).
/// Использует StatelessExecutor: каждый запрос независим, KV-кэш не накапливается
/// (executor сам создаёт и освобождает контекст на каждый вызов InferAsync).
/// </summary>
public sealed class QwenModel : IAIModel
{
    private readonly AIConfig _config;
    private readonly ILogger<QwenModel> _logger;
    private readonly PromptBuilder _promptBuilder;
    private readonly SemaphoreSlim _inferenceLock = new(1, 1);
    private LLamaWeights? _weights;
    private ModelParams? _params;
    private StatelessExecutor? _executor;
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public bool IsLoaded => _weights != null && _executor != null;
    public double LastInferenceTimeMs { get; private set; }

    public QwenModel(
        AIConfig config,
        ILogger<QwenModel> logger,
        PromptBuilder promptBuilder)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _promptBuilder = promptBuilder ?? throw new ArgumentNullException(nameof(promptBuilder));
    }

    public async Task LoadAsync(CancellationToken ct = default)
    {
        if (IsLoaded)
        {
            _logger.LogWarning("Модель уже загружена");
            return;
        }

        // Относительный путь считаем от каталога exe, а не от текущего рабочего каталога:
        // иначе запуск ярлыком/из другой папки ломает поиск модели.
        var modelPath = ResolveModelPath(_config.ModelPath);

        _logger.LogInformation("Загрузка модели из {Path}", modelPath);

        if (!File.Exists(modelPath))
        {
            throw new FileNotFoundException(
                $"GGUF-модель не найдена: {modelPath}. " +
                "Скачайте модель (например Qwen3-14B Q4_K_M) и укажите путь в appsettings.json (секция AI:ModelPath). " +
                "Относительный путь отсчитывается от каталога с AITradingSystem.UI.exe.");
        }

        // Нативные библиотеки llama.cpp должны быть найдены ДО первого вызова API LLamaSharp:
        // конструктор ModelParams уже триггерит статический конструктор NativeApi.
        LlamaNativeLoader.EnsureAvailable(_config.NativeLibraryPath, _logger);

        if (_config.GpuLayers > 0)
        {
            _logger.LogWarning(
                "AI:GpuLayers = {Layers}, но установлен CPU-бэкенд (LLamaSharp.Backend.Cpu). " +
                "Слои останутся на CPU. Для GPU нужен пакет LLamaSharp.Backend.Cuda12 и NVIDIA GPU.",
                _config.GpuLayers);
        }

        await Task.Run(() =>
        {
            ModelParams modelParams;
            LLamaWeights weights;

            try
            {
                modelParams = new ModelParams(modelPath)
                {
                    ContextSize = (uint)_config.ContextSize,
                    GpuLayerCount = _config.GpuLayers
                };

                weights = LLamaWeights.LoadFromFile(modelParams);
            }
            catch (Exception ex) when (ex is TypeInitializationException or DllNotFoundException or BadImageFormatException)
            {
                _logger.LogError(ex, "Не удалось загрузить нативную библиотеку llama.cpp");
                throw new InvalidOperationException(
                    "Нативная библиотека llama.cpp не загрузилась. Проверьте, что рядом с exe есть " +
                    "llama.dll, ggml.dll, ggml-base.dll, ggml-cpu.dll (проект UI копирует их при сборке), " +
                    "и установлен Microsoft Visual C++ Redistributable x64. Подробности: " + ex.Message, ex);
            }

            _params = modelParams;
            _weights = weights;

            // Новый API (LLamaSharp 0.20+): executor принимает веса и параметры
            // и управляет контекстом самостоятельно.
            // ApplyTemplate = false (по умолчанию): PromptBuilder уже строит ChatML-промпт.
            _executor = new StatelessExecutor(weights, modelParams);

            _logger.LogInformation(
                "Модель загружена. Context: {Context}, GPU Layers: {Layers}",
                _config.ContextSize, _config.GpuLayers);
        }, ct);
    }

    /// <summary>
    /// Абсолютный путь к модели: сначала от каталога exe, затем от рабочего каталога.
    /// </summary>
    private static string ResolveModelPath(string configuredPath)
    {
        if (string.IsNullOrWhiteSpace(configuredPath))
            return configuredPath;

        var path = configuredPath.Trim().Replace('/', Path.DirectorySeparatorChar);

        if (Path.IsPathRooted(path))
            return Path.GetFullPath(path);

        var fromBase = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, path));
        if (File.Exists(fromBase))
            return fromBase;

        var fromCwd = Path.GetFullPath(path);
        return File.Exists(fromCwd) ? fromCwd : fromBase;
    }

    public async Task UnloadAsync()
    {
        if (!IsLoaded)
            return;

        _logger.LogInformation("Выгрузка модели");

        await Task.Run(() =>
        {
            // Контекстом владеет executor и освобождает его после каждого запроса,
            // поэтому достаточно освободить веса.
            _executor = null;
            _weights?.Dispose();
            _weights = null;
        });

        _logger.LogInformation("Модель выгружена");
    }

    public async Task<TradingSignal> GetTradingSignalAsync(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        CancellationToken ct = default)
    {
        if (!IsLoaded)
            throw new InvalidOperationException("Модель не загружена. Вызовите LoadAsync.");

        var prompt = _promptBuilder.BuildTradingPrompt(symbol, indicators, newsContext, _config.EnableThinking);

        _logger.LogDebug("Отправка промпта для {Symbol}. Длина: {Length}", symbol, prompt.Length);

        TradingSignal? signal = null;
        Exception? lastException = null;

        for (int attempt = 1; attempt <= _config.MaxRetriesOnInvalidJson; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            var sw = Stopwatch.StartNew();
            try
            {
                var response = await GenerateResponseAsync(prompt, ct);
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;

                _logger.LogDebug(
                    "Получен ответ от модели для {Symbol}. Время: {Time:F0} мс. Попытка: {Attempt}",
                    symbol, LastInferenceTimeMs, attempt);

                signal = ParseSignalFromResponse(symbol, response);

                if (signal != null)
                {
                    _logger.LogInformation(
                        "Сигнал для {Symbol}: {Action} (Confidence: {Confidence:P0})",
                        symbol, signal.Action, signal.Confidence);
                    return signal;
                }

                _logger.LogWarning(
                    "Не удалось распарсить JSON из ответа модели. Попытка {Attempt}/{Max}",
                    attempt, _config.MaxRetriesOnInvalidJson);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;
                lastException = ex;
                _logger.LogError(ex, "Ошибка инференса для {Symbol}. Попытка {Attempt}", symbol, attempt);
            }
        }

        _logger.LogError(
            "Все попытки получить валидный сигнал для {Symbol} провалились. Возвращаю Hold.",
            symbol);

        return new TradingSignal
        {
            Symbol = symbol,
            Action = SignalAction.Hold,
            Confidence = 0,
            Reasoning = $"Ошибка инференса: {lastException?.Message ?? "невалидный JSON в ответе модели"}",
            Timestamp = DateTime.UtcNow,
            ModelVersion = "Qwen-GGUF"
        };
    }

    /// <summary>
    /// Реальный инференс: потоковая генерация токенов с таймаутом (NFR-1.1).
    /// </summary>
    private async Task<string> GenerateResponseAsync(string prompt, CancellationToken ct)
    {
        var executor = _executor ?? throw new InvalidOperationException("Executor не инициализирован");

        var inferenceParams = new InferenceParams
        {
            MaxTokens = _config.MaxTokens,
            AntiPrompts = new List<string> { "<|im_end|>", "<|im_start|>", "<|endoftext|>" },
            // Новый API: параметры сэмплирования задаются через SamplingPipeline
            SamplingPipeline = new DefaultSamplingPipeline
            {
                Temperature = _config.Temperature,
                TopP = _config.TopP
            }
        };

        await _inferenceLock.WaitAsync(ct);
        try
        {
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeoutCts.CancelAfter(_config.InferenceTimeoutMs);

            var sb = new StringBuilder();
            try
            {
                await foreach (var token in executor
                    .InferAsync(prompt, inferenceParams, timeoutCts.Token)
                    .WithCancellation(timeoutCts.Token))
                {
                    sb.Append(token);
                }
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                _logger.LogWarning(
                    "Инференс превысил таймаут {Timeout} мс. Использую частичный ответ ({Length} символов).",
                    _config.InferenceTimeoutMs, sb.Length);

                if (sb.Length == 0)
                    throw new TimeoutException(
                        $"Инференс не успел сгенерировать ни одного токена за {_config.InferenceTimeoutMs} мс. " +
                        "Увеличьте AI:InferenceTimeoutMs в appsettings.json. " +
                        "На CPU модель 14B генерирует примерно 2-6 токенов/с, поэтому 500 токенов могут занять несколько минут.");
            }

            return sb.ToString();
        }
        finally
        {
            _inferenceLock.Release();
        }
    }

    private TradingSignal? ParseSignalFromResponse(string symbol, string response)
    {
        try
        {
            // Qwen3 может выдавать блок рассуждений <think>...</think> — он ломает
            // наивный поиск "первая { — последняя }", поэтому вырезаем его.
            var cleaned = StripThinking(response);
            var json = ExtractJsonObject(cleaned);

            if (json == null)
            {
                _logger.LogWarning("JSON не найден в ответе модели");
                return null;
            }

            var signalDto = JsonSerializer.Deserialize<TradingSignalDto>(json, _jsonOptions);
            if (signalDto == null || string.IsNullOrWhiteSpace(signalDto.Action))
                return null;

            if (!Enum.TryParse<SignalAction>(signalDto.Action.Trim(), true, out var action))
            {
                _logger.LogWarning("Неизвестное действие в ответе модели: {Action}", signalDto.Action);
                return null;
            }

            return new TradingSignal
            {
                Symbol = symbol,
                Action = action,
                Confidence = Math.Clamp(signalDto.Confidence, 0m, 1m),
                EntryPrice = signalDto.EntryPrice,
                StopLoss = signalDto.StopLoss,
                TakeProfit = signalDto.TakeProfit,
                Reasoning = signalDto.Reasoning ?? string.Empty,
                Timestamp = DateTime.UtcNow,
                ModelVersion = "Qwen-GGUF"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка парсинга JSON из ответа модели");
            return null;
        }
    }

    /// <summary>
    /// Убирает блоки рассуждений Qwen3 (<think>…</think>) и markdown-ограждения.
    /// </summary>
    private static string StripThinking(string response)
    {
        if (string.IsNullOrEmpty(response))
            return string.Empty;

        var text = Regex.Replace(response, "<think>.*?</think>", string.Empty,
            RegexOptions.Singleline | RegexOptions.IgnoreCase);

        // Незакрытый блок рассуждений (обрыв по таймауту) — отбрасываем его целиком.
        var open = text.IndexOf("<think>", StringComparison.OrdinalIgnoreCase);
        if (open >= 0)
            text = text[..open];

        return text.Replace("```json", string.Empty, StringComparison.OrdinalIgnoreCase)
                   .Replace("```", string.Empty, StringComparison.Ordinal);
    }

    /// <summary>
    /// Достаёт первый сбалансированный JSON-объект (с учётом строк и экранирования).
    /// Предпочитает объект, содержащий поле "action".
    /// </summary>
    private static string? ExtractJsonObject(string text)
    {
        string? fallback = null;
        var index = 0;

        while (index < text.Length)
        {
            var start = text.IndexOf('{', index);
            if (start < 0)
                break;

            if (TryReadBalancedObject(text, start, out var end))
            {
                var candidate = text.Substring(start, end - start + 1);
                if (candidate.Contains("\"action\"", StringComparison.OrdinalIgnoreCase))
                    return candidate;

                fallback ??= candidate;
                index = end + 1;
            }
            else
            {
                index = start + 1;
            }
        }

        return fallback;
    }

    /// <summary>
    /// Ищет закрывающую скобку для открывающей в позиции start, игнорируя скобки внутри строк.
    /// </summary>
    private static bool TryReadBalancedObject(string text, int start, out int end)
    {
        var depth = 0;
        var inString = false;
        var escaped = false;

        for (var i = start; i < text.Length; i++)
        {
            var c = text[i];

            if (inString)
            {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') inString = false;
                continue;
            }

            if (c == '"')
            {
                inString = true;
            }
            else if (c == '{')
            {
                depth++;
            }
            else if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    end = i;
                    return true;
                }
            }
        }

        end = -1;
        return false;
    }

    public async ValueTask DisposeAsync()
    {
        await UnloadAsync();
        _inferenceLock.Dispose();
    }
}

/// <summary>
/// DTO для парсинга JSON-ответа модели (snake_case, как в промпте).
/// </summary>
internal sealed class TradingSignalDto
{
    [JsonPropertyName("action")]
    public string Action { get; set; } = string.Empty;

    [JsonPropertyName("confidence")]
    public decimal Confidence { get; set; }

    [JsonPropertyName("entry_price")]
    public decimal? EntryPrice { get; set; }

    [JsonPropertyName("stop_loss")]
    public decimal? StopLoss { get; set; }

    [JsonPropertyName("take_profit")]
    public decimal? TakeProfit { get; set; }

    [JsonPropertyName("reasoning")]
    public string? Reasoning { get; set; }
}
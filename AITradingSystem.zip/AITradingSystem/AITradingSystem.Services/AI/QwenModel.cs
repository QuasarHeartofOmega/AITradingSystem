using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using LLama;
using LLama.Common;
using LLama.Sampling;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>
/// AI-модель Qwen через LLamaSharp (FR-4.1).
/// Использует StatelessExecutor: каждый запрос независим, KV-кэш не накапливается
/// (executor сам создаёт и освобождает контекст на каждый вызов InferAsync).
/// </summary>
public sealed class QwenModel : IAIModel
{
    private readonly AIConfig _config;
    private readonly ILogger<QwenModel> _logger;
    private readonly PromptBuilder _promptBuilder;
    private readonly SemaphoreSlim _inferenceLock = new(1, 1);
    private LLamaWeights? _weights;
    private ModelParams? _params;
    private StatelessExecutor? _executor;
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public bool IsLoaded => _weights != null && _executor != null;
    public double LastInferenceTimeMs { get; private set; }

    public QwenModel(
        AIConfig config,
        ILogger<QwenModel> logger,
        PromptBuilder promptBuilder)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _promptBuilder = promptBuilder ?? throw new ArgumentNullException(nameof(promptBuilder));
    }

    public async Task LoadAsync(CancellationToken ct = default)
    {
        if (IsLoaded)
        {
            _logger.LogWarning("Модель уже загружена");
            return;
        }

        _logger.LogInformation("Загрузка модели из {Path}", _config.ModelPath);

        if (!File.Exists(_config.ModelPath))
        {
            throw new FileNotFoundException(
                $"GGUF-модель не найдена: {_config.ModelPath}. " +
                "Скачайте модель (например Qwen2.5-7B-Instruct Q4_K_M) и укажите путь в appsettings.json (секция AI:ModelPath).");
        }

        await Task.Run(() =>
        {
            _params = new ModelParams(_config.ModelPath)
            {
                ContextSize = (uint)_config.ContextSize,
                GpuLayerCount = _config.GpuLayers
            };

            _weights = LLamaWeights.LoadFromFile(_params);

            // Новый API (LLamaSharp 0.20+): executor принимает веса и параметры
            // и управляет контекстом самостоятельно.
            // ApplyTemplate = false (по умолчанию): PromptBuilder уже строит ChatML-промпт.
            _executor = new StatelessExecutor(_weights, _params);

            _logger.LogInformation(
                "Модель загружена. Context: {Context}, GPU Layers: {Layers}",
                _config.ContextSize, _config.GpuLayers);
        }, ct);
    }

    public async Task UnloadAsync()
    {
        if (!IsLoaded)
            return;

        _logger.LogInformation("Выгрузка модели");

        await Task.Run(() =>
        {
            // Контекстом владеет executor и освобождает его после каждого запроса,
            // поэтому достаточно освободить веса.
            _executor = null;
            _weights?.Dispose();
            _weights = null;
        });

        _logger.LogInformation("Модель выгружена");
    }

    public async Task<TradingSignal> GetTradingSignalAsync(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        CancellationToken ct = default)
    {
        if (!IsLoaded)
            throw new InvalidOperationException("Модель не загружена. Вызовите LoadAsync.");

        var prompt = _promptBuilder.BuildTradingPrompt(symbol, indicators, newsContext);

        _logger.LogDebug("Отправка промпта для {Symbol}. Длина: {Length}", symbol, prompt.Length);

        TradingSignal? signal = null;
        Exception? lastException = null;

        for (int attempt = 1; attempt <= _config.MaxRetriesOnInvalidJson; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            var sw = Stopwatch.StartNew();
            try
            {
                var response = await GenerateResponseAsync(prompt, ct);
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;

                _logger.LogDebug(
                    "Получен ответ от модели для {Symbol}. Время: {Time:F0} мс. Попытка: {Attempt}",
                    symbol, LastInferenceTimeMs, attempt);

                signal = ParseSignalFromResponse(symbol, response);

                if (signal != null)
                {
                    _logger.LogInformation(
                        "Сигнал для {Symbol}: {Action} (Confidence: {Confidence:P0})",
                        symbol, signal.Action, signal.Confidence);
                    return signal;
                }

                _logger.LogWarning(
                    "Не удалось распарсить JSON из ответа модели. Попытка {Attempt}/{Max}",
                    attempt, _config.MaxRetriesOnInvalidJson);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;
                lastException = ex;
                _logger.LogError(ex, "Ошибка инференса для {Symbol}. Попытка {Attempt}", symbol, attempt);
            }
        }

        _logger.LogError(
            "Все попытки получить валидный сигнал для {Symbol} провалились. Возвращаю Hold.",
            symbol);

        return new TradingSignal
        {
            Symbol = symbol,
            Action = SignalAction.Hold,
            Confidence = 0,
            Reasoning = $"Ошибка инференса: {lastException?.Message ?? "невалидный JSON в ответе модели"}",
            Timestamp = DateTime.UtcNow,
            ModelVersion = "Qwen-GGUF"
        };
    }

    /// <summary>
    /// Реальный инференс: потоковая генерация токенов с таймаутом (NFR-1.1).
    /// </summary>
    private async Task<string> GenerateResponseAsync(string prompt, CancellationToken ct)
    {
        var executor = _executor ?? throw new InvalidOperationException("Executor не инициализирован");

        var inferenceParams = new InferenceParams
        {
            MaxTokens = _config.MaxTokens,
            AntiPrompts = new List<string> { "<|im_end|>", "<|im_start|>" },
            // Новый API: параметры сэмплирования задаются через SamplingPipeline
            SamplingPipeline = new DefaultSamplingPipeline
            {
                Temperature = _config.Temperature,
                TopP = _config.TopP
            }
        };

        await _inferenceLock.WaitAsync(ct);
        try
        {
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeoutCts.CancelAfter(_config.InferenceTimeoutMs);

            var sb = new StringBuilder();
            try
            {
                await foreach (var token in executor
                    .InferAsync(prompt, inferenceParams, timeoutCts.Token)
                    .WithCancellation(timeoutCts.Token))
                {
                    sb.Append(token);
                }
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                _logger.LogWarning(
                    "Инференс превысил таймаут {Timeout} мс. Использую частичный ответ ({Length} символов).",
                    _config.InferenceTimeoutMs, sb.Length);

                if (sb.Length == 0)
                    throw new TimeoutException($"Инференс не успел сгенерировать ни одного токена за {_config.InferenceTimeoutMs} мс. Увеличьте AI:InferenceTimeoutMs в appsettings.json.");
            }

            return sb.ToString();
        }
        finally
        {
            _inferenceLock.Release();
        }
    }

    private TradingSignal? ParseSignalFromResponse(string symbol, string response)
    {
        try
        {
            // Ищем JSON в ответе (может быть обернут в markdown или текст)
            var jsonStart = response.IndexOf('{');
            var jsonEnd = response.LastIndexOf('}');

            if (jsonStart < 0 || jsonEnd <= jsonStart)
            {
                _logger.LogWarning("JSON не найден в ответе модели");
                return null;
            }

            var json = response.Substring(jsonStart, jsonEnd - jsonStart + 1);

            var signalDto = JsonSerializer.Deserialize<TradingSignalDto>(json, _jsonOptions);
            if (signalDto == null || string.IsNullOrWhiteSpace(signalDto.Action))
                return null;

            if (!Enum.TryParse<SignalAction>(signalDto.Action.Trim(), true, out var action))
            {
                _logger.LogWarning("Неизвестное действие в ответе модели: {Action}", signalDto.Action);
                return null;
            }

            return new TradingSignal
            {
                Symbol = symbol,
                Action = action,
                Confidence = Math.Clamp(signalDto.Confidence, 0m, 1m),
                EntryPrice = signalDto.EntryPrice,
                StopLoss = signalDto.StopLoss,
                TakeProfit = signalDto.TakeProfit,
                Reasoning = signalDto.Reasoning ?? string.Empty,
                Timestamp = DateTime.UtcNow,
                ModelVersion = "Qwen-GGUF"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка парсинга JSON из ответа модели");
            return null;
        }
    }

    public async ValueTask DisposeAsync()
    {
        await UnloadAsync();
        _inferenceLock.Dispose();
    }
}

/// <summary>
/// DTO для парсинга JSON-ответа модели (snake_case, как в промпте).
/// </summary>
internal sealed class TradingSignalDto
{
    [JsonPropertyName("action")]
    public string Action { get; set; } = string.Empty;

    [JsonPropertyName("confidence")]
    public decimal Confidence { get; set; }

    [JsonPropertyName("entry_price")]
    public decimal? EntryPrice { get; set; }

    [JsonPropertyName("stop_loss")]
    public decimal? StopLoss { get; set; }

    [JsonPropertyName("take_profit")]
    public decimal? TakeProfit { get; set; }

    [JsonPropertyName("reasoning")]
    public string? Reasoning { get; set; }
}
﻿using System.Diagnostics;
using System.Text.Json;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using LLama;
using LLama.Common;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>
/// AI-модель Qwen 14B через LLamaSharp с CUDA (FR-4.1).
/// </summary>
public sealed class QwenModel : IAIModel
{
    private readonly AIConfig _config;
    private readonly ILogger<QwenModel> _logger;
    private readonly PromptBuilder _promptBuilder;
    private LLamaWeights? _weights;
    private ModelParams? _params;
    private LLamaContext? _context;
    private InteractiveExecutor? _executor;
    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public bool IsLoaded => _weights != null && _context != null;
    public double LastInferenceTimeMs { get; private set; }

    public QwenModel(
        AIConfig config,
        ILogger<QwenModel> logger,
        PromptBuilder promptBuilder)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _promptBuilder = promptBuilder ?? throw new ArgumentNullException(nameof(promptBuilder));
    }

    public async Task LoadAsync(CancellationToken ct = default)
    {
        if (IsLoaded)
        {
            _logger.LogWarning("Модель уже загружена");
            return;
        }

        _logger.LogInformation("Загрузка модели Qwen 14B из {Path}", _config.ModelPath);

        if (!File.Exists(_config.ModelPath))
        {
            throw new FileNotFoundException($"Модель не найдена: {_config.ModelPath}");
        }

        await Task.Run(() =>
        {
            _params = new ModelParams(_config.ModelPath)
            {
                ContextSize = (uint)_config.ContextSize,
                GpuLayerCount = _config.GpuLayers
                // Seed и UseMemorymap удалены, так как они отсутствуют в ModelParams версии 0.30.0
            };

            _weights = LLamaWeights.LoadFromFile(_params);
            _context = _weights.CreateContext(_params);
            _executor = new InteractiveExecutor(_context);

            _logger.LogInformation(
                "Модель загружена. Context: {Context}, GPU Layers: {Layers}",
                _config.ContextSize, _config.GpuLayers);
        }, ct);
    }

    public async Task UnloadAsync()
    {
        if (!IsLoaded)
            return;

        _logger.LogInformation("Выгрузка модели");

        await Task.Run(() =>
        {
            _context?.Dispose();
            _weights?.Dispose();
            _context = null;
            _weights = null;
            _executor = null;
        });

        _logger.LogInformation("Модель выгружена");
    }

    public async Task<TradingSignal> GetTradingSignalAsync(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        CancellationToken ct = default)
    {
        if (!IsLoaded)
            throw new InvalidOperationException("Модель не загружена. Вызовите LoadAsync.");

        var prompt = _promptBuilder.BuildTradingPrompt(symbol, indicators, newsContext);

        _logger.LogDebug("Отправка промпта для {Symbol}. Длина: {Length}", symbol, prompt.Length);

        var sw = Stopwatch.StartNew();
        TradingSignal? signal = null;
        Exception? lastException = null;

        for (int attempt = 1; attempt <= _config.MaxRetriesOnInvalidJson; attempt++)
        {
            try
            {
                var response = await GenerateResponseAsync(prompt, ct);
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;

                _logger.LogDebug(
                    "Получен ответ от модели для {Symbol}. Время: {Time:F0} мс. Попытка: {Attempt}",
                    symbol, LastInferenceTimeMs, attempt);

                signal = ParseSignalFromResponse(symbol, response);

                if (signal != null)
                {
                    _logger.LogInformation(
                        "Сигнал для {Symbol}: {Action} (Confidence: {Confidence:P0})",
                        symbol, signal.Action, signal.Confidence);
                    return signal;
                }

                _logger.LogWarning(
                    "Не удалось распарсить JSON из ответа модели. Попытка {Attempt}/{Max}",
                    attempt, _config.MaxRetriesOnInvalidJson);
            }
            catch (Exception ex)
            {
                lastException = ex;
                _logger.LogError(ex, "Ошибка инференса для {Symbol}. Попытка {Attempt}", symbol, attempt);
            }
        }

        // Если все попытки провалились, возвращаем Hold
        _logger.LogError(
            "Все попытки получить валидный сигнал для {Symbol} провалились. Возвращаю Hold.",
            symbol);

        return new TradingSignal
        {
            Symbol = symbol,
            Action = SignalAction.Hold,
            Confidence = 0,
            Reasoning = $"Ошибка инференса: {lastException?.Message ?? "Неизвестная ошибка"}",
            Timestamp = DateTime.UtcNow,
            ModelVersion = "Qwen-14B-Q4_K_M"
        };
    }

    private async Task<string> GenerateResponseAsync(string prompt, CancellationToken ct)
    {
        if (_executor is null)
            throw new InvalidOperationException("Executor не инициализирован");

        var response = string.Empty;

        await Task.Run(() =>
        {
            _params = new ModelParams(_config.ModelPath)
            {
                ContextSize = (uint)_config.ContextSize,
                GpuLayerCount = _config.GpuLayers,
                // Seed и UseMemorymap удалены, так как они отсутствуют в ModelParams версии 0.30.0

            };

            _weights = LLamaWeights.LoadFromFile(_params);
            _context = _weights.CreateContext(_params);
            _executor = new InteractiveExecutor(_context);

            _logger.LogInformation(
                "Модель загружена. Context: {Context}, GPU Layers: {Layers}",
                _config.ContextSize, _config.GpuLayers);
        }, ct);

        return response;
    }

    private TradingSignal? ParseSignalFromResponse(string symbol, string response)
    {
        try
        {
            // Ищем JSON в ответе (может быть обернут в markdown или текст)
            var jsonStart = response.IndexOf('{');
            var jsonEnd = response.LastIndexOf('}');

            if (jsonStart < 0 || jsonEnd < 0 || jsonEnd <= jsonStart)
            {
                _logger.LogWarning("JSON не найден в ответе модели");
                return null;
            }

            var json = response.Substring(jsonStart, jsonEnd - jsonStart + 1);

            var signalDto = JsonSerializer.Deserialize<TradingSignalDto>(json, _jsonOptions);
            if (signalDto == null)
                return null;

            return new TradingSignal
            {
                Symbol = symbol,
                Action = Enum.Parse<SignalAction>(signalDto.Action, true),
                Confidence = signalDto.Confidence,
                EntryPrice = signalDto.EntryPrice,
                StopLoss = signalDto.StopLoss,
                TakeProfit = signalDto.TakeProfit,
                Reasoning = signalDto.Reasoning,
                Timestamp = DateTime.UtcNow,
                ModelVersion = "Qwen-14B-Q4_K_M"
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка парсинга JSON из ответа модели");
            return null;
        }
    }

    public async ValueTask DisposeAsync()
    {
        await UnloadAsync();
    }
}

/// <summary>
/// DTO для парсинга JSON-ответа модели.
/// </summary>
internal sealed class TradingSignalDto
{
    public string Action { get; set; } = string.Empty;
    public decimal Confidence { get; set; }
    public decimal? EntryPrice { get; set; }
    public decimal? StopLoss { get; set; }
    public decimal? TakeProfit { get; set; }
    public string Reasoning { get; set; } = string.Empty;
}
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;
using LLama;
using LLama.Common;
using LLama.Sampling;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.AI;

/// <summary>
/// AI-модель Qwen через LLamaSharp (FR-4.1).
///
/// Возможности:
///  - автовыбор бэкенда под железо: CUDA (NVIDIA) → Vulkan (AMD/Intel) → CPU;
///  - режим рассуждений (thinking) с отдельным бюджетом токенов и самопроверкой;
///  - полное логирование: промпт → сырой ответ → рассуждения → распарсенный сигнал (logs/ai-*.log);
///  - «ремонт» невалидного JSON вместо слепого повтора;
///  - учёт открытой позиции и спот-ограничений (сигнал CLOSE, запрет шорта).
/// StatelessExecutor: каждый запрос независим, KV-кэш не накапливается.
/// </summary>
public sealed class QwenModel : IAIModel
{
    private readonly AIConfig _config;
    private readonly ILogger<QwenModel> _logger;
    private readonly PromptBuilder _promptBuilder;
    private readonly SemaphoreSlim _inferenceLock = new(1, 1);
    private LLamaWeights? _weights;
    private ModelParams? _params;
    private StatelessExecutor? _executor;

    private readonly JsonSerializerOptions _jsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        NumberHandling = JsonNumberHandling.AllowReadingFromString
    };

    public bool IsLoaded => _weights != null && _executor != null;
    public double LastInferenceTimeMs { get; private set; }

    /// <summary>Фактически выбранный бэкенд инференса.</summary>
    public AiBackend ActiveBackend { get; private set; } = AiBackend.Cpu;

    /// <summary>Последний блок рассуждений модели (для UI/диагностики).</summary>
    public string LastThinking { get; private set; } = string.Empty;

    public QwenModel(
        AIConfig config,
        ILogger<QwenModel> logger,
        PromptBuilder promptBuilder)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        _promptBuilder = promptBuilder ?? throw new ArgumentNullException(nameof(promptBuilder));
    }

    public async Task LoadAsync(CancellationToken ct = default)
    {
        if (IsLoaded)
        {
            _logger.LogWarning("Модель уже загружена");
            return;
        }

        var modelPath = ResolveModelPath(_config.ModelPath);
        _logger.LogInformation("Загрузка модели из {Path}", modelPath);

        if (!File.Exists(modelPath))
        {
            throw new FileNotFoundException(
                $"GGUF-модель не найдена: {modelPath}. " +
                "Скачайте модель (например Qwen3-8B/14B Q4_K_M) и укажите путь в appsettings.json (AI:ModelPath). " +
                "Относительный путь отсчитывается от каталога с AITradingSystem.UI.exe.");
        }

        // === Выбор вычислительного бэкенда под железо ===
        var gpu = GpuProbe.Detect(_logger);
        ActiveBackend = GpuProbe.SelectBackend(_config.ResolvedBackend, gpu, LlamaNativeLoader.HasBackendFiles, _logger);
        LlamaNativeLoader.UseBackend(ActiveBackend, _logger);
        LlamaNativeLoader.EnsureAvailable(_config.NativeLibraryPath, _logger);

        AiLog.Backend($"{ActiveBackend}; {gpu.Summary}; {LlamaNativeLoader.GetDiagnostics()}");

        var gpuLayers = ResolveGpuLayers();
        var threads = _config.Threads > 0 ? _config.Threads : Math.Max(1, Environment.ProcessorCount / 2);

        await Task.Run(() =>
        {
            ModelParams modelParams;
            LLamaWeights weights;

            try
            {
                modelParams = new ModelParams(modelPath)
                {
                    ContextSize = (uint)_config.ContextSize,
                    GpuLayerCount = gpuLayers,
                    Threads = threads,
                    BatchSize = (uint)_config.BatchSize,
                    UseMemorymap = _config.UseMemorymap
                };

                weights = LLamaWeights.LoadFromFile(modelParams);
            }
            catch (Exception ex) when (ex is TypeInitializationException or DllNotFoundException or BadImageFormatException)
            {
                _logger.LogError(ex, "Не удалось загрузить нативную библиотеку llama.cpp ({Backend})", ActiveBackend);

                // Автоматический откат на CPU: GPU-сборка могла не подгрузиться из-за драйвера.
                if (ActiveBackend != AiBackend.Cpu && LlamaNativeLoader.HasBackendFiles(AiBackend.Cpu))
                {
                    AiLog.Backend($"GPU-бэкенд {ActiveBackend} не загрузился, откат на CPU: {ex.Message}");
                    throw new InvalidOperationException(
                        $"GPU-бэкенд {ActiveBackend} не загрузился ({ex.Message}). " +
                        "Установите AI:Backend = \"Cpu\" в appsettings.json или обновите драйвер GPU. " +
                        "Диагностика: " + LlamaNativeLoader.GetDiagnostics(), ex);
                }

                throw new InvalidOperationException(
                    "Нативная библиотека llama.cpp не загрузилась. Проверьте наличие llama.dll, ggml*.dll рядом с exe " +
                    "и Microsoft Visual C++ Redistributable x64. Подробности: " + ex.Message, ex);
            }

            _params = modelParams;
            _weights = weights;
            _executor = new StatelessExecutor(weights, modelParams);

            _logger.LogInformation(
                "Модель загружена. Backend={Backend}, Context={Context}, GpuLayers={Layers}, Threads={Threads}, Thinking={Thinking}",
                ActiveBackend, _config.ContextSize, gpuLayers, threads, _config.EnableThinking);

            AiLog.Backend($"модель загружена: backend={ActiveBackend}, ctx={_config.ContextSize}, " +
                          $"gpuLayers={gpuLayers}, threads={threads}, maxTokens={_config.EffectiveMaxTokens}, " +
                          $"thinking={_config.EnableThinking}");
        }, ct);
    }

    /// <summary>-1 = все слои на GPU; для CPU всегда 0.</summary>
    private int ResolveGpuLayers()
    {
        if (ActiveBackend == AiBackend.Cpu)
            return 0;

        // 999 гарантированно больше числа слоёв любой текущей модели = «все слои на GPU».
        return _config.GpuLayers < 0 ? 999 : _config.GpuLayers;
    }

    private static string ResolveModelPath(string configuredPath)
    {
        if (string.IsNullOrWhiteSpace(configuredPath))
            return configuredPath;

        var path = configuredPath.Trim().Replace('/', Path.DirectorySeparatorChar);

        if (Path.IsPathRooted(path))
            return Path.GetFullPath(path);

        var fromBase = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, path));
        if (File.Exists(fromBase))
            return fromBase;

        var fromCwd = Path.GetFullPath(path);
        return File.Exists(fromCwd) ? fromCwd : fromBase;
    }

    public async Task UnloadAsync()
    {
        if (!IsLoaded)
            return;

        _logger.LogInformation("Выгрузка модели");

        await Task.Run(() =>
        {
            _executor = null;
            _params = null;
            _weights?.Dispose();
            _weights = null;
        });

        _logger.LogInformation("Модель выгружена");
    }

    public async Task<TradingSignal> GetTradingSignalAsync(
        string symbol,
        Dictionary<string, decimal> indicators,
        string? newsContext,
        AiRequestContext? context = null,
        CancellationToken ct = default)
    {
        if (!IsLoaded)
            throw new InvalidOperationException("Модель не загружена. Вызовите LoadAsync.");

        context ??= new AiRequestContext
        {
            AllowShort = false,
            MinConfidence = _config.MinConfidence
        };

        var prompt = _promptBuilder.BuildTradingPrompt(
            symbol, indicators, newsContext, _config.EnableThinking, context);

        TradingSignal? signal = null;
        Exception? lastException = null;
        string? lastRawResponse = null;
        string? lastParseError = null;
        var currentPrompt = prompt;

        for (var attempt = 1; attempt <= _config.MaxRetriesOnInvalidJson; attempt++)
        {
            ct.ThrowIfCancellationRequested();

            // «Ремонт»: со второй попытки показываем модели её невалидный ответ и ошибку.
            if (attempt > 1 && _config.RepairInvalidJson && lastRawResponse != null)
            {
                currentPrompt = _promptBuilder.BuildRepairPrompt(
                    prompt, lastRawResponse, lastParseError ?? "invalid JSON");
                AiLog.Retry(symbol, attempt, lastParseError ?? "invalid JSON");
            }

            var meta = $"backend={ActiveBackend}, thinking={_config.EnableThinking}, " +
                       $"position={(context.HasPosition ? context.PositionSide ?? "LONG" : "none")}";
            AiLog.Prompt(symbol, attempt, _config.MaxRetriesOnInvalidJson, currentPrompt, meta);

            var sw = Stopwatch.StartNew();
            try
            {
                var response = await GenerateResponseAsync(currentPrompt, ct);
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;
                lastRawResponse = response;

                AiLog.Response(symbol, attempt, response, LastInferenceTimeMs);

                var thinking = ExtractThinking(response);
                if (!string.IsNullOrWhiteSpace(thinking))
                {
                    LastThinking = thinking;
                    AiLog.Thinking(symbol, thinking, LastInferenceTimeMs);
                }

                signal = ParseSignalFromResponse(symbol, response, out var parseError);
                lastParseError = parseError;

                if (signal != null)
                {
                    // Слишком низкая уверенность → не торгуем.
                    if (signal.Action is SignalAction.Buy or SignalAction.Sell &&
                        signal.Confidence < _config.MinConfidence)
                    {
                        AiLog.Parsed(symbol, signal.Action.ToString(), signal.Confidence,
                            JsonSerializer.Serialize(new { downgraded = "HOLD", reason = "confidence < MinConfidence" }),
                            LastInferenceTimeMs);

                        signal.Action = SignalAction.Hold;
                        signal.Reasoning = $"Низкая уверенность ({signal.Confidence:P0} < {_config.MinConfidence:P0}): {signal.Reasoning}";
                    }
                    else
                    {
                        AiLog.Parsed(symbol, signal.Action.ToString(), signal.Confidence,
                            $"entry={signal.EntryPrice}, sl={signal.StopLoss}, tp={signal.TakeProfit}, reason={signal.Reasoning}",
                            LastInferenceTimeMs);
                    }

                    _logger.LogInformation(
                        "Сигнал для {Symbol}: {Action} (Confidence: {Confidence:P0}, {Time:F0} мс, backend {Backend})",
                        symbol, signal.Action, signal.Confidence, LastInferenceTimeMs, ActiveBackend);

                    return signal;
                }

                AiLog.ParseFailed(symbol, attempt, parseError ?? "unknown", response);
                _logger.LogWarning("Не удалось распарсить JSON ответа модели. Попытка {Attempt}/{Max}: {Error}",
                    attempt, _config.MaxRetriesOnInvalidJson, parseError);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception ex)
            {
                sw.Stop();
                LastInferenceTimeMs = sw.Elapsed.TotalMilliseconds;
                lastException = ex;
                lastParseError = ex.Message;
                AiLog.Failure(symbol, ex, $"инференс, попытка {attempt}");
                _logger.LogError(ex, "Ошибка инференса для {Symbol}. Попытка {Attempt}", symbol, attempt);
            }
        }

        _logger.LogError("Все попытки получить валидный сигнал для {Symbol} провалились. Возвращаю Hold.", symbol);

        return new TradingSignal
        {
            Symbol = symbol,
            Action = SignalAction.Hold,
            Confidence = 0,
            Reasoning = $"Ошибка инференса: {lastException?.Message ?? lastParseError ?? "невалидный JSON в ответе модели"}",
            Timestamp = DateTime.UtcNow,
            ModelVersion = $"Qwen-GGUF/{ActiveBackend}"
        };
    }

    /// <summary>Потоковая генерация с таймаутом и бюджетом на рассуждения.</summary>
    private async Task<string> GenerateResponseAsync(string prompt, CancellationToken ct)
    {
        var executor = _executor ?? throw new InvalidOperationException("Executor не инициализирован");

        var inferenceParams = new InferenceParams
        {
            MaxTokens = _config.EffectiveMaxTokens,
            AntiPrompts = new List<string> { "<|im_end|>", "<|im_start|>", "<|endoftext|>" },
            SamplingPipeline = new DefaultSamplingPipeline
            {
                Temperature = _config.Temperature,
                TopP = _config.TopP
            }
        };

        await _inferenceLock.WaitAsync(ct);
        try
        {
            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeoutCts.CancelAfter(_config.InferenceTimeoutMs);

            var sb = new StringBuilder();
            try
            {
                await foreach (var token in executor
                    .InferAsync(prompt, inferenceParams, timeoutCts.Token)
                    .WithCancellation(timeoutCts.Token))
                {
                    sb.Append(token);
                }
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                _logger.LogWarning(
                    "Инференс превысил таймаут {Timeout} мс. Использую частичный ответ ({Length} символов).",
                    _config.InferenceTimeoutMs, sb.Length);

                if (sb.Length == 0)
                    throw new TimeoutException(
                        $"Инференс не успел сгенерировать ни одного токена за {_config.InferenceTimeoutMs} мс. " +
                        "Увеличьте AI:InferenceTimeoutMs, уменьшите AI:MaxTokens/ThinkingBudgetTokens " +
                        "или включите GPU-бэкенд (AI:Backend = Auto/Cuda12/Vulkan).");
            }

            return sb.ToString();
        }
        finally
        {
            _inferenceLock.Release();
        }
    }

    private TradingSignal? ParseSignalFromResponse(string symbol, string response, out string? error)
    {
        error = null;

        try
        {
            var cleaned = StripThinking(response);
            var json = ExtractJsonObject(cleaned);

            if (json == null)
            {
                error = "в ответе нет JSON-объекта";
                return null;
            }

            var signalDto = JsonSerializer.Deserialize<TradingSignalDto>(json, _jsonOptions);
            if (signalDto == null || string.IsNullOrWhiteSpace(signalDto.Action))
            {
                error = "в JSON отсутствует поле action";
                return null;
            }

            if (!Enum.TryParse<SignalAction>(signalDto.Action.Trim(), true, out var action))
            {
                error = $"неизвестное действие '{signalDto.Action}'";
                return null;
            }

            return new TradingSignal
            {
                Symbol = symbol,
                Action = action,
                Confidence = Math.Clamp(signalDto.Confidence, 0m, 1m),
                EntryPrice = NormalizePrice(signalDto.EntryPrice),
                StopLoss = NormalizePrice(signalDto.StopLoss),
                TakeProfit = NormalizePrice(signalDto.TakeProfit),
                Reasoning = signalDto.Reasoning ?? string.Empty,
                Timestamp = DateTime.UtcNow,
                ModelVersion = $"Qwen-GGUF/{ActiveBackend}"
            };
        }
        catch (JsonException ex)
        {
            error = $"ошибка JSON: {ex.Message}";
            _logger.LogError(ex, "Ошибка парсинга JSON из ответа модели");
            return null;
        }
        catch (Exception ex)
        {
            error = $"ошибка разбора: {ex.Message}";
            _logger.LogError(ex, "Ошибка парсинга ответа модели");
            return null;
        }
    }

    /// <summary>Модель иногда присылает 0 или отрицательные цены вместо null.</summary>
    private static decimal? NormalizePrice(decimal? price) =>
        price.HasValue && price.Value > 0 ? price : null;

    /// <summary>Достаёт содержимое блока рассуждений (для лога).</summary>
    private static string ExtractThinking(string response)
    {
        if (string.IsNullOrEmpty(response)) return string.Empty;

        var match = Regex.Match(response, @"<think>(.*?)</think>",
            RegexOptions.Singleline | RegexOptions.IgnoreCase);

        if (match.Success)
            return match.Groups[1].Value.Trim();

        var open = response.IndexOf("<think>", StringComparison.OrdinalIgnoreCase);
        return open >= 0 ? response[(open + 7)..].Trim() : string.Empty;
    }

    /// <summary>Убирает блоки рассуждений и markdown-ограждения.</summary>
    private static string StripThinking(string response)
    {
        if (string.IsNullOrEmpty(response))
            return string.Empty;

        var text = Regex.Replace(response, "<think>.*?</think>", string.Empty,
            RegexOptions.Singleline | RegexOptions.IgnoreCase);

        // Незакрытый блок рассуждений (обрыв по таймауту/лимиту токенов) — отбрасываем.
        var open = text.IndexOf("<think>", StringComparison.OrdinalIgnoreCase);
        if (open >= 0)
            text = text[..open];

        return text.Replace("```json", string.Empty, StringComparison.OrdinalIgnoreCase)
                   .Replace("```", string.Empty, StringComparison.Ordinal);
    }

    /// <summary>
    /// Достаёт первый сбалансированный JSON-объект (с учётом строк и экранирования).
    /// Предпочитает объект с полем "action".
    /// </summary>
    private static string? ExtractJsonObject(string text)
    {
        string? fallback = null;
        var index = 0;

        while (index < text.Length)
        {
            var start = text.IndexOf('{', index);
            if (start < 0)
                break;

            if (TryReadBalancedObject(text, start, out var end))
            {
                var candidate = text.Substring(start, end - start + 1);
                if (candidate.Contains("\"action\"", StringComparison.OrdinalIgnoreCase))
                    return candidate;

                fallback ??= candidate;
                index = end + 1;
            }
            else
            {
                index = start + 1;
            }
        }

        return fallback;
    }

    private static bool TryReadBalancedObject(string text, int start, out int end)
    {
        var depth = 0;
        var inString = false;
        var escaped = false;

        for (var i = start; i < text.Length; i++)
        {
            var c = text[i];

            if (inString)
            {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') inString = false;
                continue;
            }

            if (c == '"')
            {
                inString = true;
            }
            else if (c == '{')
            {
                depth++;
            }
            else if (c == '}')
            {
                depth--;
                if (depth == 0)
                {
                    end = i;
                    return true;
                }
            }
        }

        end = -1;
        return false;
    }

    public async ValueTask DisposeAsync()
    {
        await UnloadAsync();
        _inferenceLock.Dispose();
    }
}

/// <summary>DTO для парсинга JSON-ответа модели (snake_case, как в промпте).</summary>
internal sealed class TradingSignalDto
{
    [JsonPropertyName("action")]
    public string Action { get; set; } = string.Empty;

    [JsonPropertyName("confidence")]
    public decimal Confidence { get; set; }

    [JsonPropertyName("entry_price")]
    public decimal? EntryPrice { get; set; }

    [JsonPropertyName("stop_loss")]
    public decimal? StopLoss { get; set; }

    [JsonPropertyName("take_profit")]
    public decimal? TakeProfit { get; set; }

    [JsonPropertyName("reasoning")]
    public string? Reasoning { get; set; }
}

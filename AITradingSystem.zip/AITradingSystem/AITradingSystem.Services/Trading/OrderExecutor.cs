﻿using AITradingSystem.Common.Extensions;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Data.Binance;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Исполнитель ордеров через Binance API (FR-6).
/// </summary>
public sealed class OrderExecutor : IOrderExecutor
{
    private readonly IBinanceRestClient _binanceClient;
    private readonly ILogger<OrderExecutor> _logger;

    public OrderExecutor(
        IBinanceRestClient binanceClient,
        ILogger<OrderExecutor> logger)
    {
        _binanceClient = binanceClient ?? throw new ArgumentNullException(nameof(binanceClient));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<Order?> ExecuteSignalAsync(
        TradingSignal signal,
        decimal quantity,
        OrderBook? currentOrderBook,
        CancellationToken ct = default)
    {
        if (signal.Action == SignalAction.Hold)
        {
            _logger.LogDebug("Сигнал Hold для {Symbol}, пропускаю", signal.Symbol);
            return null;
        }

        if (!signal.EntryPrice.HasValue || quantity <= 0)
        {
            _logger.LogWarning("Невалидный сигнал для {Symbol}: EntryPrice или quantity не указаны", signal.Symbol);
            return null;
        }

        var side = signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell;
        decimal executionPrice = signal.EntryPrice.Value;

        // FR-6.2: Валидация и корректировка цены для гарантированного Post-Only (Maker)
        // Если мы покупаем, наша лимитная цена должна быть <= Best Bid, чтобы не стать Taker.
        // Если мы продаем, наша лимитная цена должна быть >= Best Ask.
        if (currentOrderBook != null)
        {
            if (side == OrderSide.Buy && currentOrderBook.BestBid.HasValue)
            {
                executionPrice = Math.Min(executionPrice, currentOrderBook.BestBid.Value);
            }
            else if (side == OrderSide.Sell && currentOrderBook.BestAsk.HasValue)
            {
                executionPrice = Math.Max(executionPrice, currentOrderBook.BestAsk.Value);
            }
        }

        _logger.LogInformation(
            "Исполнение сигнала для {Symbol}: {Side} {Quantity} @ {Price} (Post-Only)",
            signal.Symbol, side, quantity, executionPrice);

        try
        {
            var order = await _binanceClient.PlaceOrderAsync(
                signal.Symbol,
                side,
                quantity,
                executionPrice,
                postOnly: true, // FR-6.2: Строго Post-Only
                ct);

            _logger.LogInformation(
                "Ордер размещен: {OrderId}, Status: {Status}, Price: {Price}",
                order.Id, order.Status, order.Price);

            if (order.Status == OrderStatus.Rejected)
            {
                _logger.LogError("Ордер отклонен биржей (возможно, нарушение Post-Only): {OrderId}", order.Id);
                return null;
            }

            return order;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка размещения ордера для {Symbol}", signal.Symbol);
            return null;
        }
    }

    public async Task<Order?> ClosePositionAsync(Position position, CancellationToken ct = default)
    {
        var side = position.Side == OrderSide.Buy ? OrderSide.Sell : OrderSide.Buy;

        _logger.LogInformation(
            "Закрытие позиции {Symbol}: {Side} {Quantity}",
            position.Symbol, side, position.Quantity);

        try
        {
            var order = await _binanceClient.PlaceOrderAsync(
                position.Symbol,
                side,
                position.Quantity,
                position.CurrentPrice,
                postOnly: false, // Для экстренного закрытия post-only не используется
                ct);

            _logger.LogInformation("Ордер на закрытие размещен: {OrderId}", order.Id);
            return order;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка закрытия позиции {Symbol}", position.Symbol);
            return null;
        }
    }

    public async Task<Order?> UpdateStopLossAsync(
        Position position,
        decimal newStopLoss,
        CancellationToken ct = default)
    {
        _logger.LogInformation(
            "Обновление Stop-Loss для {Symbol}: {OldSL} → {NewSL}",
            position.Symbol, position.StopLoss, newStopLoss);

        // Для спотовой торговли SL реализуется через мониторинг цены и manual close (Market order)
        // В фьючерсах здесь размещался бы stop-market ордер
        position.StopLoss = newStopLoss;

        return null;
    }
}
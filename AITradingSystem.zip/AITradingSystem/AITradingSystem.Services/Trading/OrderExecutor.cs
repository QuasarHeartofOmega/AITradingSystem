using System.Diagnostics;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Data.Binance;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Исполнитель ордеров (FR-6).
///
/// Ключевые исправления:
///  - ордер на вход считается исполненным ТОЛЬКО после подтверждения биржей
///    (опрос статуса с таймаутом, отмена неисполненного остатка) — иначе позиция
///    создавалась по неисполненному лимитному ордеру и «висела» в воздухе;
///  - частичное исполнение: позиция открывается на фактически исполненный объём;
///  - округление до stepSize/tickSize и проверка minQty/minNotional (фильтры Binance
///    приходят строками — парсер исправлен в BinanceModels);
///  - спот: SELL без открытой позиции не открывает шорт;
///  - paper-режим учитывает комиссию.
/// </summary>
public sealed class OrderExecutor : IOrderExecutor
{
    private readonly IBinanceRestClient _binanceClient;
    private readonly TradingConfig _tradingConfig;
    private readonly ILogger<OrderExecutor> _logger;
    private readonly Dictionary<string, (BinanceSymbolInfo Info, DateTime CachedAt)> _symbolInfoCache =
        new(StringComparer.OrdinalIgnoreCase);

    private static readonly TimeSpan SymbolInfoTtl = TimeSpan.FromHours(1);

    public OrderExecutor(
        IBinanceRestClient binanceClient,
        TradingConfig tradingConfig,
        ILogger<OrderExecutor> logger)
    {
        _binanceClient = binanceClient ?? throw new ArgumentNullException(nameof(binanceClient));
        _tradingConfig = tradingConfig ?? throw new ArgumentNullException(nameof(tradingConfig));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<Order?> ExecuteSignalAsync(
        TradingSignal signal,
        decimal quantity,
        OrderBook? currentOrderBook,
        CancellationToken ct = default)
    {
        if (signal.Action is SignalAction.Hold or SignalAction.Close)
        {
            _logger.LogDebug("Сигнал {Action} для {Symbol} не требует ордера на вход", signal.Action, signal.Symbol);
            return null;
        }

        if (!signal.EntryPrice.HasValue || quantity <= 0)
        {
            TradeLog.Rejected(signal.Symbol, "entry", "нет EntryPrice или quantity <= 0");
            return null;
        }

        var side = signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell;

        if (side == OrderSide.Sell && !_tradingConfig.AllowShort)
        {
            TradeLog.Rejected(signal.Symbol, "entry",
                "SELL на споте без открытой позиции — шорт невозможен (Trading:AllowShort=false)");
            return null;
        }

        var executionPrice = signal.EntryPrice.Value;

        // FR-6.2: Post-Only (Maker). Buy: цена <= Best Bid; Sell: цена >= Best Ask.
        if (currentOrderBook != null && !_tradingConfig.UseMarketEntry)
        {
            if (side == OrderSide.Buy && currentOrderBook.BestBid.HasValue)
                executionPrice = Math.Min(executionPrice, currentOrderBook.BestBid.Value);
            else if (side == OrderSide.Sell && currentOrderBook.BestAsk.HasValue)
                executionPrice = Math.Max(executionPrice, currentOrderBook.BestAsk.Value);
        }

        // === Фильтры символа: округление до stepSize/tickSize, minQty/minNotional ===
        // Применяем и в paper-режиме (best effort): иначе «бумажные» сделки проходят там,
        // где реальная биржа ордер отклонит, и статистика paper-режима врёт.
        var info = await GetSymbolInfoCachedAsync(signal.Symbol, ct);
        if (info != null)
        {
            if (info.StepSize > 0)
                quantity = Math.Floor(quantity / info.StepSize) * info.StepSize;

            if (!_tradingConfig.UseMarketEntry && info.TickSize > 0)
                executionPrice = RoundPriceToTick(executionPrice, info.TickSize, side);

            if (quantity <= 0 || (info.MinQty > 0 && quantity < info.MinQty))
            {
                TradeLog.Rejected(signal.Symbol, "filters", $"quantity {quantity} < minQty {info.MinQty}");
                return null;
            }

            var notionalPrice = _tradingConfig.UseMarketEntry
                ? currentOrderBook?.MidPrice ?? executionPrice
                : executionPrice;

            if (info.MinNotional > 0 && quantity * notionalPrice < info.MinNotional)
            {
                TradeLog.Rejected(signal.Symbol, "filters",
                    $"notional {quantity * notionalPrice:F2} < minNotional {info.MinNotional}");
                return null;
            }
        }
        else if (!_tradingConfig.PaperTradingMode)
        {
            _logger.LogWarning("Фильтры символа {Symbol} недоступны — ордер отправляется без округления", signal.Symbol);
        }

        // === Paper Trading: симулируем исполнение по указанной цене + комиссия ===
        if (_tradingConfig.PaperTradingMode)
        {
            var paperOrder = CreatePaperOrder(signal.Symbol, side, quantity, executionPrice,
                postOnly: !_tradingConfig.UseMarketEntry, _tradingConfig.PaperCommissionRate);

            TradeLog.Opened(signal.Symbol, side.ToString(), quantity, executionPrice,
                signal.StopLoss ?? 0m, signal.TakeProfit ?? 0m, "PAPER", paperOrder.Id);
            return paperOrder;
        }

        try
        {
            if (_tradingConfig.UseMarketEntry)
            {
                var marketOrder = await _binanceClient.PlaceMarketOrderAsync(signal.Symbol, side, quantity, ct);
                return ValidateFilled(marketOrder, signal.Symbol, "market-entry");
            }

            var order = await _binanceClient.PlaceOrderAsync(
                signal.Symbol, side, quantity, executionPrice, postOnly: true, ct);

            if (order.Status is OrderStatus.Rejected or OrderStatus.Expired or OrderStatus.Canceled)
            {
                TradeLog.Rejected(signal.Symbol, "exchange", $"ордер отклонён биржей: {order.Status}");
                return null;
            }

            // Ждём реального исполнения: лимитный Post-Only ордер может простоять в стакане долго.
            var filled = await WaitForFillAsync(order, ct);
            return ValidateFilled(filled, signal.Symbol, "limit-entry");
        }
        catch (BinanceApiException ex) when (ex.IsPostOnlyRejection)
        {
            TradeLog.Rejected(signal.Symbol, "post-only",
                "цена пересекла спред (ордер был бы taker). Сигнал пропущен, ждём следующий цикл.");
            return null;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка размещения ордера для {Symbol}", signal.Symbol);
            TradeLog.Rejected(signal.Symbol, "exception", ex.Message);
            return null;
        }
    }

    public async Task<Order?> ClosePositionAsync(Position position, CancellationToken ct = default)
    {
        var side = position.Side == OrderSide.Buy ? OrderSide.Sell : OrderSide.Buy;

        _logger.LogInformation("Закрытие позиции {Symbol}: {Side} {Quantity}",
            position.Symbol, side, position.Quantity);

        if (_tradingConfig.PaperTradingMode)
        {
            var price = position.CurrentPrice > 0 ? position.CurrentPrice : position.EntryPrice;
            var paperOrder = CreatePaperOrder(position.Symbol, side, position.Quantity, price,
                postOnly: false, _tradingConfig.PaperCommissionRate);

            ExchangeLog.Order("PAPER-CLOSE", position.Symbol, side.ToString(), position.Quantity, price,
                $"fee={paperOrder.Commission:F4}");
            return paperOrder;
        }

        try
        {
            var quantity = position.Quantity;
            var info = await GetSymbolInfoCachedAsync(position.Symbol, ct);
            if (info != null && info.StepSize > 0)
                quantity = Math.Floor(quantity / info.StepSize) * info.StepSize;

            if (quantity <= 0)
            {
                _logger.LogError("Quantity после округления <= 0 для {Symbol}", position.Symbol);
                TradeLog.Rejected(position.Symbol, "close", "quantity после округления <= 0");
                return null;
            }

            var order = await _binanceClient.PlaceMarketOrderAsync(position.Symbol, side, quantity, ct);

            if (order.ExecutedQuantity <= 0)
            {
                // MARKET может не исполниться сразу в тонком стакане — проверяем статус один раз.
                order = await WaitForFillAsync(order, ct);
            }

            return ValidateFilled(order, position.Symbol, "close");
        }
        catch (BinanceApiException ex) when (ex.IsInsufficientBalance)
        {
            // Частая причина на споте: часть базового актива ушла на комиссию (BNB/актив),
            // либо позиция в учёте больше, чем реальный free-баланс монеты.
            TradeLog.Rejected(position.Symbol, "close",
                $"биржа отклонила закрытие: недостаточно средств ({ex.ApiMessage}). " +
                "Проверьте free-баланс базового актива на счёте — позиция останется открытой и будет пересчитана.");
            _logger.LogError(ex, "Недостаточно средств для закрытия {Symbol}", position.Symbol);
            return null;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка закрытия позиции {Symbol}", position.Symbol);
            TradeLog.Rejected(position.Symbol, "close", ex.Message);
            return null;
        }
    }

    public Task<Order?> UpdateStopLossAsync(Position position, decimal newStopLoss, CancellationToken ct = default)
    {
        // На споте SL реализуется мониторингом цены и market-close (см. TradingEngine).
        position.StopLoss = newStopLoss;
        return Task.FromResult<Order?>(null);
    }

    /// <summary>
    /// Опрос статуса ордера до полного исполнения или таймаута.
    /// По таймауту неисполненный остаток отменяется, исполненная часть возвращается.
    /// </summary>
    private async Task<Order> WaitForFillAsync(Order order, CancellationToken ct)
    {
        if (order.Status == OrderStatus.Filled || order.BinanceOrderId <= 0)
            return order;

        var sw = Stopwatch.StartNew();
        var timeout = TimeSpan.FromSeconds(_tradingConfig.OrderFillTimeoutSeconds);
        var current = order;

        while (sw.Elapsed < timeout && !ct.IsCancellationRequested)
        {
            await Task.Delay(_tradingConfig.OrderFillPollIntervalMs, ct);

            try
            {
                current = await _binanceClient.GetOrderAsync(order.Symbol, order.BinanceOrderId, ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось получить статус ордера {OrderId}", order.BinanceOrderId);
                continue;
            }

            if (current.Status is OrderStatus.Filled or OrderStatus.Canceled
                or OrderStatus.Rejected or OrderStatus.Expired)
                break;
        }

        if (current.Status is OrderStatus.New or OrderStatus.PartiallyFilled)
        {
            try
            {
                await _binanceClient.CancelOrderAsync(current.Symbol, current.BinanceOrderId, ct);
                // После отмены забираем финальное состояние (могли исполнить в момент отмены).
                current = await _binanceClient.GetOrderAsync(current.Symbol, current.BinanceOrderId, ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Не удалось отменить неисполненный ордер {OrderId}", current.BinanceOrderId);
            }

            _logger.LogWarning(
                "Ордер {OrderId} не исполнен полностью за {Timeout} с: {Executed}/{Original}. Остаток отменён.",
                current.BinanceOrderId, _tradingConfig.OrderFillTimeoutSeconds,
                current.ExecutedQuantity, current.OriginalQuantity);
        }

        return current;
    }

    private Order? ValidateFilled(Order order, string symbol, string stage)
    {
        if (order.ExecutedQuantity <= 0)
        {
            TradeLog.Rejected(symbol, stage,
                $"ордер не исполнен (status={order.Status}, executed={order.ExecutedQuantity})");
            return null;
        }

        if (order.ExecutedQuantity < order.OriginalQuantity)
        {
            _logger.LogWarning(
                "Частичное исполнение {Symbol}: {Executed}/{Original} — позиция открывается на исполненный объём",
                symbol, order.ExecutedQuantity, order.OriginalQuantity);
        }

        ExchangeLog.Order("FILLED", symbol, order.Side.ToString(), order.ExecutedQuantity,
            order.AverageFillPrice ?? order.Price,
            $"id={order.Id} status={order.Status} fee={order.Commission}");

        return order;
    }

    /// <summary>Округление цены к tickSize в «безопасную» для maker сторону.</summary>
    private static decimal RoundPriceToTick(decimal price, decimal tickSize, OrderSide side)
    {
        if (tickSize <= 0) return price;

        var steps = price / tickSize;
        return side == OrderSide.Buy
            ? Math.Floor(steps) * tickSize
            : Math.Ceiling(steps) * tickSize;
    }

    private async Task<BinanceSymbolInfo?> GetSymbolInfoCachedAsync(string symbol, CancellationToken ct)
    {
        if (_symbolInfoCache.TryGetValue(symbol, out var cached) &&
            DateTime.UtcNow - cached.CachedAt < SymbolInfoTtl)
            return cached.Info;

        try
        {
            var info = await _binanceClient.GetSymbolInfoAsync(symbol, ct);
            if (info != null)
                _symbolInfoCache[symbol] = (info, DateTime.UtcNow);
            return info;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось получить фильтры символа {Symbol}", symbol);
            return null;
        }
    }

    private static Order CreatePaperOrder(
        string symbol, OrderSide side, decimal quantity, decimal price, bool postOnly, decimal commissionRate)
    {
        var id = $"paper-{Guid.NewGuid():N}";
        var notional = quantity * price;

        return new Order
        {
            Id = id,
            ClientOrderId = id,
            Symbol = symbol,
            Side = side,
            Type = postOnly ? OrderType.Limit : OrderType.Market,
            Status = OrderStatus.Filled,
            Price = price,
            OriginalQuantity = quantity,
            ExecutedQuantity = quantity,
            FilledQuoteQuantity = notional,
            Commission = Math.Round(notional * commissionRate, 8),
            CommissionAsset = "USDT",
            CreatedAt = DateTime.UtcNow,
            IsPostOnly = postOnly
        };
    }
}

using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Extensions;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Data.Binance;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Исполнитель ордеров (FR-6).
/// В Paper Trading режиме симулирует исполнение локально, без обращения к бирже.
/// В Live режиме округляет цену/объем до фильтров символа (tickSize/stepSize).
/// </summary>
public sealed class OrderExecutor : IOrderExecutor
{
    private readonly IBinanceRestClient _binanceClient;
    private readonly TradingConfig _tradingConfig;
    private readonly ILogger<OrderExecutor> _logger;
    private readonly Dictionary<string, BinanceSymbolInfo> _symbolInfoCache = new(StringComparer.OrdinalIgnoreCase);

    public OrderExecutor(
        IBinanceRestClient binanceClient,
        TradingConfig tradingConfig,
        ILogger<OrderExecutor> logger)
    {
        _binanceClient = binanceClient ?? throw new ArgumentNullException(nameof(binanceClient));
        _tradingConfig = tradingConfig ?? throw new ArgumentNullException(nameof(tradingConfig));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public async Task<Order?> ExecuteSignalAsync(
        TradingSignal signal,
        decimal quantity,
        OrderBook? currentOrderBook,
        CancellationToken ct = default)
    {
        if (signal.Action == SignalAction.Hold)
        {
            _logger.LogDebug("Сигнал Hold для {Symbol}, пропускаю", signal.Symbol);
            return null;
        }

        if (!signal.EntryPrice.HasValue || quantity <= 0)
        {
            _logger.LogWarning("Невалидный сигнал для {Symbol}: EntryPrice или quantity не указаны", signal.Symbol);
            return null;
        }

        var side = signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell;
        decimal executionPrice = signal.EntryPrice.Value;

        // FR-6.2: Post-Only (Maker). Buy: цена <= Best Bid; Sell: цена >= Best Ask.
        if (currentOrderBook != null)
        {
            if (side == OrderSide.Buy && currentOrderBook.BestBid.HasValue)
                executionPrice = Math.Min(executionPrice, currentOrderBook.BestBid.Value);
            else if (side == OrderSide.Sell && currentOrderBook.BestAsk.HasValue)
                executionPrice = Math.Max(executionPrice, currentOrderBook.BestAsk.Value);
        }

        // === Paper Trading: симулируем мгновенное исполнение ===
        if (_tradingConfig.PaperTradingMode)
        {
            var paperOrder = CreatePaperOrder(signal.Symbol, side, quantity, executionPrice, postOnly: true);
            _logger.LogInformation(
                "[PAPER] Симулировано открытие: {Symbol} {Side} {Quantity} @ {Price}",
                signal.Symbol, side, quantity, executionPrice);
            return paperOrder;
        }

        // === Live: округление до фильтров символа ===
        var info = await GetSymbolInfoCachedAsync(signal.Symbol, ct);
        if (info != null)
        {
            if (info.StepSize > 0)
                quantity = Math.Floor(quantity / info.StepSize) * info.StepSize;
            if (info.TickSize > 0)
                executionPrice = Math.Floor(executionPrice / info.TickSize) * info.TickSize;

            if (quantity <= 0 || (info.MinQty > 0 && quantity < info.MinQty))
            {
                _logger.LogWarning("Quantity {Qty} меньше minQty {Min} для {Symbol}", quantity, info.MinQty, signal.Symbol);
                return null;
            }

            if (info.MinNotional > 0 && quantity * executionPrice < info.MinNotional)
            {
                _logger.LogWarning("Notional {Notional} меньше minNotional {Min} для {Symbol}",
                    quantity * executionPrice, info.MinNotional, signal.Symbol);
                return null;
            }
        }

        _logger.LogInformation(
            "Исполнение сигнала для {Symbol}: {Side} {Quantity} @ {Price} (Post-Only)",
            signal.Symbol, side, quantity, executionPrice);

        try
        {
            var order = await _binanceClient.PlaceOrderAsync(
                signal.Symbol, side, quantity, executionPrice, postOnly: true, ct);

            _logger.LogInformation("Ордер размещен: {OrderId}, Status: {Status}, Price: {Price}",
                order.Id, order.Status, order.Price);

            if (order.Status == OrderStatus.Rejected || order.Status == OrderStatus.Expired)
            {
                _logger.LogError("Ордер отклонен биржей (возможно, нарушение Post-Only): {OrderId}", order.Id);
                return null;
            }

            return order;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка размещения ордера для {Symbol}", signal.Symbol);
            return null;
        }
    }

    public async Task<Order?> ClosePositionAsync(Position position, CancellationToken ct = default)
    {
        var side = position.Side == OrderSide.Buy ? OrderSide.Sell : OrderSide.Buy;

        _logger.LogInformation("Закрытие позиции {Symbol}: {Side} {Quantity}",
            position.Symbol, side, position.Quantity);

        // === Paper Trading ===
        if (_tradingConfig.PaperTradingMode)
        {
            var paperOrder = CreatePaperOrder(position.Symbol, side, position.Quantity, position.CurrentPrice, postOnly: false);
            _logger.LogInformation("[PAPER] Симулировано закрытие: {Symbol} @ {Price}", position.Symbol, position.CurrentPrice);
            return paperOrder;
        }

        // === Live: MARKET-ордер для гарантированного исполнения ===
        try
        {
            var quantity = position.Quantity;
            var info = await GetSymbolInfoCachedAsync(position.Symbol, ct);
            if (info != null && info.StepSize > 0)
                quantity = Math.Floor(quantity / info.StepSize) * info.StepSize;

            if (quantity <= 0)
            {
                _logger.LogError("Quantity после округления <= 0 для {Symbol}", position.Symbol);
                return null;
            }

            var order = await _binanceClient.PlaceMarketOrderAsync(position.Symbol, side, quantity, ct);
            _logger.LogInformation("Market-ордер на закрытие размещен: {OrderId}, Status: {Status}", order.Id, order.Status);
            return order;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка закрытия позиции {Symbol}", position.Symbol);
            return null;
        }
    }

    public Task<Order?> UpdateStopLossAsync(Position position, decimal newStopLoss, CancellationToken ct = default)
    {
        // Для спота SL реализуется через мониторинг цены и market-close (см. TradingEngine).
        position.StopLoss = newStopLoss;
        return Task.FromResult<Order?>(null);
    }

    private async Task<BinanceSymbolInfo?> GetSymbolInfoCachedAsync(string symbol, CancellationToken ct)
    {
        if (_symbolInfoCache.TryGetValue(symbol, out var cached))
            return cached;

        try
        {
            var info = await _binanceClient.GetSymbolInfoAsync(symbol, ct);
            if (info != null)
                _symbolInfoCache[symbol] = info;
            return info;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось получить фильтры символа {Symbol}", symbol);
            return null;
        }
    }

    private static Order CreatePaperOrder(string symbol, OrderSide side, decimal quantity, decimal price, bool postOnly)
    {
        var id = $"paper-{Guid.NewGuid():N}";
        return new Order
        {
            Id = id,
            ClientOrderId = id,
            Symbol = symbol,
            Side = side,
            Type = OrderType.Limit,
            Status = OrderStatus.Filled,
            Price = price,
            OriginalQuantity = quantity,
            ExecutedQuantity = quantity,
            FilledQuoteQuantity = quantity * price,
            CreatedAt = DateTime.UtcNow,
            IsPostOnly = postOnly
        };
    }
}

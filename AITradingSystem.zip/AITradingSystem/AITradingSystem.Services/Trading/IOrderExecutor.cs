﻿using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Интерфейс исполнителя ордеров (FR-6).
/// </summary>
public interface IOrderExecutor
{
    /// <summary>
    /// Исполнить торговый сигнал (открыть позицию) с учетом текущего стакана для Post-Only.
    /// </summary>
    Task<Order?> ExecuteSignalAsync(
        TradingSignal signal,
        decimal quantity,
        OrderBook? currentOrderBook,
        CancellationToken ct = default);

    /// <summary>
    /// Закрыть позицию.
    /// </summary>
    Task<Order?> ClosePositionAsync(Position position, CancellationToken ct = default);

    /// <summary>
    /// Обновить Stop-Loss позиции.
    /// </summary>
    Task<Order?> UpdateStopLossAsync(Position position, decimal newStopLoss, CancellationToken ct = default);
}
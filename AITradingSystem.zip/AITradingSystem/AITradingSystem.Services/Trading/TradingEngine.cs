using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Data.Binance;
using AITradingSystem.Data.Storage;
using AITradingSystem.Services.AI;
using AITradingSystem.Services.Analysis;
using AITradingSystem.Services.Monitoring;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Globalization;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Центральный движок торговли — координирует все компоненты (FR-1 — FR-8).
/// </summary>
public sealed class TradingEngine : IAsyncDisposable
{
    private readonly AppConfig _config;
    private readonly IBinanceWebSocketClient _wsClient;
    private readonly IBinanceRestClient _restClient;
    private readonly IAIModel _aiModel;
    private readonly MarketAnalyzer _marketAnalyzer;
    private readonly SentimentAnalyzer _sentimentAnalyzer;
    private readonly SignalCalibrator _calibrator;
    private readonly RiskManager _riskManager;
    private readonly PositionManager _positionManager;
    private readonly PositionMonitor _positionMonitor;
    private readonly ExecutionQueue _executionQueue;
    private readonly ReconciliationService _reconciliation;
    private readonly ClockDriftMonitor _clockDriftMonitor;
    private readonly IOrderExecutor _orderExecutor;
    private readonly ITradeHistoryRepository _tradeHistory;
    private readonly IStateRepository _stateRepository;
    private readonly MetricsCollector _metrics;
    private readonly ILogger<TradingEngine> _logger;

    private CancellationTokenSource? _cts;
    private Task? _mainLoop;
    private BotStatus _status = BotStatus.Stopped;

    private readonly Dictionary<string, OHLCV> _currentCandles = new();
    private readonly object _candleLock = new();

    private readonly Dictionary<string, OrderBook> _currentOrderBooks = new();
    private readonly object _orderBookLock = new();

    /// <summary>
    /// P0.2: абсолютный ATR по символу для трейлинга в тик-контуре.
    /// Обновляется на закрытых свечах — считать индикаторы на каждом тике незачем.
    /// </summary>
    private readonly ConcurrentDictionary<string, decimal> _atrAbsolute = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Когда последний раз спрашивали ИИ об уже открытой позиции (закрыть/держать).</summary>
    private readonly Dictionary<string, DateTime> _lastPositionReview = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _reviewLock = new();

    /// <summary>Cooldown анализа символа (B11): последний запрос к ИИ на вход.</summary>
    private readonly Dictionary<string, DateTime> _lastSymbolAnalysis = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Троттлинг WAITING-сообщений (не чаще раза в минуту на символ).</summary>
    private readonly Dictionary<string, DateTime> _lastWaitingLog = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _throttleLock = new();

    private sealed record SymbolPrecision(int PriceDecimals, decimal? TickSize, decimal? StepSize);
    private readonly ConcurrentDictionary<string, SymbolPrecision> _symbolPrecision = new(StringComparer.OrdinalIgnoreCase);
    public IReadOnlyList<string> UnavailableSymbols { get; private set; } = Array.Empty<string>();
    private List<string> _activeSymbols = new();
    public BotStatus Status => _status;
    public event Action<BotStatus>? OnStatusChanged;
    public event Action<TradingSignal>? OnSignalGenerated;
    public event Action<Position>? OnPositionOpened;
    public event Action<TradeRecord>? OnPositionClosed;

    /// <summary>P0.6: kill-switch взведён — новые входы заблокированы до явного сброса.</summary>
    private int _killSwitchEngaged;
    public bool IsKillSwitchEngaged => Volatile.Read(ref _killSwitchEngaged) == 1;
    public event Action<string>? OnKillSwitchEngaged;

    public TradingEngine(
        AppConfig config,
        IBinanceWebSocketClient wsClient,
        IBinanceRestClient restClient,
        IAIModel aiModel,
        MarketAnalyzer marketAnalyzer,
        SentimentAnalyzer sentimentAnalyzer,
        SignalCalibrator calibrator,
        RiskManager riskManager,
        PositionManager positionManager,
        PositionMonitor positionMonitor,
        ExecutionQueue executionQueue,
        ReconciliationService reconciliation,
        ClockDriftMonitor clockDriftMonitor,
        IOrderExecutor orderExecutor,
        ITradeHistoryRepository tradeHistory,
        IStateRepository stateRepository,
        MetricsCollector metrics,
        ILogger<TradingEngine> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _wsClient = wsClient ?? throw new ArgumentNullException(nameof(wsClient));
        _restClient = restClient ?? throw new ArgumentNullException(nameof(restClient));
        _aiModel = aiModel ?? throw new ArgumentNullException(nameof(aiModel));
        _marketAnalyzer = marketAnalyzer ?? throw new ArgumentNullException(nameof(marketAnalyzer));
        _sentimentAnalyzer = sentimentAnalyzer ?? throw new ArgumentNullException(nameof(sentimentAnalyzer));
        _calibrator = calibrator ?? throw new ArgumentNullException(nameof(calibrator));
        _riskManager = riskManager ?? throw new ArgumentNullException(nameof(riskManager));
        _positionManager = positionManager ?? throw new ArgumentNullException(nameof(positionManager));
        _positionMonitor = positionMonitor ?? throw new ArgumentNullException(nameof(positionMonitor));
        _executionQueue = executionQueue ?? throw new ArgumentNullException(nameof(executionQueue));
        _reconciliation = reconciliation ?? throw new ArgumentNullException(nameof(reconciliation));
        _clockDriftMonitor = clockDriftMonitor ?? throw new ArgumentNullException(nameof(clockDriftMonitor));
        _orderExecutor = orderExecutor ?? throw new ArgumentNullException(nameof(orderExecutor));
        _tradeHistory = tradeHistory ?? throw new ArgumentNullException(nameof(tradeHistory));
        _stateRepository = stateRepository ?? throw new ArgumentNullException(nameof(stateRepository));
        _metrics = metrics ?? throw new ArgumentNullException(nameof(metrics));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Запустить торговый движок.
    /// </summary>
    public async Task StartAsync(CancellationToken ct = default)
    {
        if (_status is BotStatus.Running or BotStatus.Starting or BotStatus.Stopping or BotStatus.Paused)
        {
            _logger.LogWarning("Движок уже запущен или в переходном состоянии: {Status}", _status);
            return;
        }

        SetStatus(BotStatus.Starting);
        _logger.LogInformation("Запуск торгового движка");

        try
        {
            // Проверка доступностиDemo/выбранной биржи до дорогой загрузки модели.
            await ValidateSymbolsAsync(ct);

            // Загрузка модели
            await _aiModel.LoadAsync(ct);

            // P0.3: ключи идемпотентности из журнала намерений — ДО первой торговой операции.
            // Иначе после рестарта повторное закрытие/защита ушли бы вторым ордером.
            var restoredIntents = await _executionQueue.RestoreAsync(ct);
            var unresolved = _executionQueue.UnresolvedIntents;
            if (unresolved.Count > 0)
            {
                _logger.LogWarning(
                    "Незавершённых намерений исполнения: {Count} ({Keys}) — судьба ордеров сверяется с биржей при повторе; полная реконсиляция — P0.5",
                    unresolved.Count, string.Join(", ", unresolved.Select(i => i.ClientOrderId)));
            }
            else if (restoredIntents > 0)
            {
                _logger.LogInformation("Восстановлено ключей идемпотентности: {Count}", restoredIntents);
            }

            // Восстановление позиций
            await _positionManager.LoadPositionsAsync(ct);
            foreach (var restored in _positionManager.GetOpenPositions())
            {
                OnPositionOpened?.Invoke(restored); // показываем восстановленные позиции в UI
            }

            // P0.5: реконсиляция с биржей + user-data stream (в paper/без ключей — тихий пропуск).
            // Колбэки применения филлов/подхвата сирот регистрируются до старта контура.
            _reconciliation.Configure(ApplyExchangeFillAsync, AdoptOrphanPositionAsync);
            await _reconciliation.StartAsync(ct);

            // P0.4: граница торгового дня — по часам биржи, а не локального процесса.
            await ConfigureExchangeClockAsync(ct);

            // P0.4: восстанавливаем пик/дневной старт/макс. просадку ДО первого UpdateBalance —
            // иначе рестарт «прощает» дневной убыток и обнуляет пик.
            var riskState = await _stateRepository.LoadRiskStateAsync(ct);
            if (riskState != null)
            {
                _riskManager.DrawdownTracker.RestoreState(riskState);
                _logger.LogInformation(
                    "RISK-STATE-RESTORED: пик {Peak:F2}, старт дня {DayStart:F2} ({Day:yyyy-MM-dd}), макс. просадка {MaxDd:P2}",
                    riskState.PeakBalance, riskState.DayStartBalance, riskState.DayStartUtc, riskState.MaxDrawdownPercent);
            }

            // Получение начального баланса
            if (_config.Trading.PaperTradingMode)
            {
                // P0.4: виртуальный баланс переживает рестарт — иначе дневной PnL считался бы с нуля.
                var paperBalance = riskState?.CurrentBalance > 0
                    ? riskState.CurrentBalance
                    : _config.Trading.PaperTradingInitialBalance;
                _logger.LogInformation("Режим Paper Trading: виртуальный баланс {Balance} USDT ({Source})",
                    paperBalance,
                    riskState?.CurrentBalance > 0 ? "восстановлен из risk_state.json" : "начальный из конфига");
                await UpdateRiskBalanceAsync(paperBalance, ct);
            }
            else
            {
                // В реальном режиме запрашиваем баланс с биржи
                _logger.LogInformation("Режим Live: запрос баланса с Binance...");
                var balance = await _restClient.GetAccountBalanceAsync(ct);
                await UpdateRiskBalanceAsync(balance.AvailableUSDT, ct);
            }

            // Прогрев индикаторов историческими свечами с REST.
            // Без этого боту потребовались бы сутки+ ожидания закрытых свечей с WebSocket.
            foreach (var symbol in _activeSymbols)
            {
                try
                {
                    var history = await _restClient.GetKlinesAsync(
                        symbol, _config.Trading.CandleInterval, _config.Trading.HistoryCandlesCount, ct);

                    var calc = _marketAnalyzer.GetOrCreateCalculator(symbol);
                    var closed = history.Where(k => k.IsClosed).ToList();
                    foreach (var candle in closed)
                    {
                        calc.Update(candle);
                    }

                    if (history.Count > 0)
                    {
                        lock (_candleLock)
                        {
                            _currentCandles[symbol] = history[^1];
                        }
                    }

                    if (calc.AllReady && history.Count > 0)
                        RefreshAtrCache(symbol, history[^1]);

                    _logger.LogInformation("История для {Symbol}: {Count} закрытых свечей, индикаторы прогреты: {Ready}",
                        symbol, closed.Count, calc.AllReady);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось загрузить историю для {Symbol} — индикаторы будут прогреваться через WebSocket", symbol);
                }
            }

            // Подписка на события ДО подключения, чтобы не потерять первые сообщения
            _wsClient.OnKline += OnKlineReceived;
            _wsClient.OnOrderBook += OnOrderBookReceived;
            _wsClient.OnError += OnWebSocketError;

            // Подключение к WebSocket
            await _wsClient.ConnectAsync(
                _activeSymbols,
                _config.Trading.CandleInterval,
                ct);

            _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);

            // P1.8: мониторинг дрейфа часов живёт отдельно от анализа и подписанных запросов.
            _clockDriftMonitor.Start(_cts.Token);

            // P0.2: независимый контур сопровождения позиций стартует ДО цикла анализа
            // и работает даже когда анализ занят инференсом или стоит на Pause.
            _positionMonitor.Configure(
                (position, reason, exitPrice, token) => ClosePositionAsync(position, reason, token, exitPrice),
                GetCurrentCandle,
                GetAtrAbsolute);
            _positionMonitor.Start(_cts.Token);

            // Запуск основного цикла (только входы и пересмотр позиции моделью)
            _mainLoop = Task.Run(() => MainLoopAsync(_cts.Token), _cts.Token);

            SetStatus(BotStatus.Running);
            _logger.LogInformation("Торговый движок запущен");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка запуска движка");

            // Откатываем частично выполненный запуск: иначе остаются подписки на WS,
            // живой receive-loop и загруженная модель, а повторный "Старт" плодит дубли.
            await CleanupAfterFailedStartAsync();

            SetStatus(BotStatus.Error);
            throw;
        }
    }

    private async Task CleanupAfterFailedStartAsync()
    {
        _wsClient.OnKline -= OnKlineReceived;
        _wsClient.OnOrderBook -= OnOrderBookReceived;
        _wsClient.OnError -= OnWebSocketError;

        // P0.5: если реконсиляция успела стартовать до падения запуска — гасим и её.
        try
        {
            await _reconciliation.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Не удалось остановить контур реконсиляции при откате запуска");
        }

        try
        {
            await _clockDriftMonitor.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Не удалось остановить мониторинг дрейфа часов при откате запуска");
        }

        try
        {
            _cts?.Cancel();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Не удалось отменить токен основного цикла");
        }

        if (_mainLoop != null)
        {
            try
            {
                await _mainLoop;
            }
            catch (OperationCanceledException)
            {
                // Ожидаемо
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Основной цикл завершился с ошибкой при откате запуска");
            }
        }

        try
        {
            await _positionMonitor.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Контур сопровождения завершился с ошибкой при откате запуска");
        }

        try
        {
            await _wsClient.DisconnectAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось отключить WebSocket при откате запуска");
        }

        try
        {
            await _aiModel.UnloadAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось выгрузить модель при откате запуска");
        }

        _cts?.Dispose();
        _cts = null;
        _mainLoop = null;
    }

    /// <summary>
    /// Остановить торговый движок.
    /// </summary>
    public async Task StopAsync()
    {
        if (_status == BotStatus.Stopped)
            return;

        SetStatus(BotStatus.Stopping);
        _logger.LogInformation("Остановка торгового движка");

        try
        {
            _cts?.Cancel();
        }
        catch (ObjectDisposedException)
        {
            // Токен уже освобождён предыдущей остановкой
        }

        if (_mainLoop != null)
        {
            try
            {
                await _mainLoop;
            }
            catch (OperationCanceledException)
            {
                // Ожидаемое поведение
            }
        }

        // P0.2: гасим тик-контур раньше отключения WS — иначе он продолжит закрывать позиции.
        try
        {
            await _positionMonitor.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка остановки контура сопровождения позиций");
        }

        // P0.5: user-data stream и keepalive гасятся до отключения рыночного WS.
        try
        {
            await _reconciliation.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка остановки контура реконсиляции");
        }

        // P1.8: гасим периодическую проверку часов вместе с остальными фоновыми контурами.
        try
        {
            await _clockDriftMonitor.StopAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка остановки мониторинга дрейфа часов");
        }

        _wsClient.OnKline -= OnKlineReceived;
        _wsClient.OnOrderBook -= OnOrderBookReceived;
        _wsClient.OnError -= OnWebSocketError;

        try
        {
            await _wsClient.DisconnectAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка отключения WebSocket при остановке");
        }

        try
        {
            await _aiModel.UnloadAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка выгрузки модели при остановке");
        }

        try
        {
            await _positionManager.SavePositionsAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось сохранить позиции при остановке");
        }

        _cts?.Dispose();
        _cts = null;
        _mainLoop = null;

        SetStatus(BotStatus.Stopped);
        _logger.LogInformation("Торговый движок остановлен");
    }

    /// <summary>
    /// Приостановить торговлю.
    /// </summary>
    public void Pause()
    {
        if (_status != BotStatus.Running)
            return;

        SetStatus(BotStatus.Paused);
        _logger.LogInformation("Торговля приостановлена");
    }

    /// <summary>
    /// Возобновить торговлю.
    /// </summary>
    public void Resume()
    {
        if (_status != BotStatus.Paused)
            return;

        SetStatus(BotStatus.Running);
        _logger.LogInformation("Торговля возобновлена");
    }

    private async Task MainLoopAsync(CancellationToken ct)
    {
        _logger.LogInformation("Основной цикл запущен");

        while (!ct.IsCancellationRequested)
        {
            try
            {
                if (_status == BotStatus.Running)
                {
                    await ProcessSymbolsAsync(ct);
                }

                await Task.Delay(TimeSpan.FromSeconds(_config.Trading.AnalysisIntervalSeconds), ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка в основном цикле");
                await Task.Delay(TimeSpan.FromSeconds(10), ct);
            }
        }

        _logger.LogInformation("Основной цикл завершен");
    }

    private async Task ProcessSymbolsAsync(CancellationToken ct)
    {
        foreach (var symbol in _activeSymbols)
        {
            if (ct.IsCancellationRequested)
                break;

            await ProcessSymbolAsync(symbol, ct);
        }
    }

    private async Task ProcessSymbolAsync(string symbol, CancellationToken ct)
    {
        // P0.6: kill-switch блокирует новые входы независимо от статуса (Pause может не примениться
        // во время Starting); сопровождение открытых позиций продолжает PositionMonitor.
        if (IsKillSwitchEngaged)
        {
            TradeLog.Rejected(symbol, "kill-switch", "входы заблокированы kill-switch (пробит лимит риска или ручная паника)");
            return;
        }

        // 1. Позиция уже открыта — здесь только вопрос модели «держать/закрыть».
        //    P0.2: SL/TP, трейлинг и биржевая защита ушли в PositionMonitor (тик-контур),
        //    чтобы сопровождение не ждало инференса LLM по всем остальным парам.
        if (_positionManager.GetPositionBySymbol(symbol) != null)
        {
            await ReviewOpenPositionAsync(symbol, ct);
            return;
        }

        // 2. Лимит одновременно открытых позиций.
        var openCount = _positionManager.GetOpenPositions().Count;
        if (openCount >= _config.Trading.MaxOpenPositions)
        {
            TradeLog.Rejected(symbol, "portfolio",
                $"достигнут лимит открытых позиций {openCount}/{_config.Trading.MaxOpenPositions}");
            return;
        }

        // 3. Индикаторы.
        var currentCandle = GetCurrentCandle(symbol);
        if (currentCandle == null)
        {
            LogWaiting(symbol, "нет текущей свечи (ожидание данных WebSocket/REST)");
            return;
        }

        var indicators = _marketAnalyzer.GetIndicatorSnapshot(symbol, currentCandle);
        if (indicators == null)
        {
            // Раньше здесь был молчаливый return — в логах было пусто, казалось что бот не работает.
            var warmup = _marketAnalyzer.GetWarmupInfo(symbol);
            LogWaiting(symbol, $"прогрев индикаторов: {warmup.Candles}/{warmup.Required} свечей");
            return;
        }

        // 3a. Cooldown на символ: при 12+ парах и медленном инференсе не забиваем очередь одним символом.
        if (!TryEnterAnalysisCooldown(symbol))
            return;

        // 3b. Детерминированный pre-score (B9): математика до ИИ, якорь для рубрики уверенности.
        var preScore = _calibrator.PreScore(indicators);
        TradeLog.Decision(symbol, "PRE-SCORE", $"{preScore.Summary}; {preScore.ReasonsText}");

        var newsContext = await _sentimentAnalyzer.GetNewsContextAsync(symbol, ct);

        // 4. Сигнал ИИ. Контекст обязателен: без него модель предлагает шорт на споте
        //    и не знает, что позиция уже открыта.
        var requestContext = BuildAiContext(symbol, position: null, preScore, indicators, currentCandle.Close);
        var signal = await _aiModel.GetTradingSignalAsync(symbol, indicators, newsContext, requestContext, ct);

        // 4a. Калибровка уверенности: модель + prior движка (политика AI:ConfidencePolicy).
        signal = _calibrator.Calibrate(signal, preScore, _config.AI.ResolvedConfidencePolicy,
            BuildCalibrationContext(symbol, indicators, currentCandle.Close, hasPosition: false),
            blendModelWeight: _config.AI.BlendModelWeight);

        _metrics.RecordSignal(signal);
        _metrics.RecordInferenceTime(_aiModel.LastInferenceTimeMs);
        OnSignalGenerated?.Invoke(signal);

        if (signal.Action is SignalAction.Hold or SignalAction.Close)
        {
            TradeLog.Decision(symbol, signal.Action.ToString(),
                signal.Action == SignalAction.Close
                    ? "ИИ просит закрыть, но открытой позиции нет"
                    : $"conf={signal.Confidence:P0}: {signal.Reasoning}");
            return;
        }

        if (signal.Action == SignalAction.Sell && !_config.Trading.AllowShort)
        {
            TradeLog.Rejected(symbol, "spot",
                "SELL без открытой позиции = шорт, на споте Binance невозможен (Trading:AllowShort=false)");
            return;
        }

        // 5. Порог уверенности применяется к FINAL confidence (после калибратора B9),
        //    а не к «сырому» числу модели — иначе якорь 0.45 убивал все сигналы.
        if (signal.Confidence < _config.AI.MinConfidence)
        {
            TradeLog.Rejected(symbol, "confidence",
                $"final={signal.Confidence:P0} < порога {_config.AI.MinConfidence:P0} " +
                $"(model={signal.ModelConfidence:P0}, engine={signal.EngineConfidence:P0}, {signal.ConfidenceSource})");
            return;
        }

        // 6. Валидация риск-менеджером (просадка, дневной лимит, R/R, корректность цен).
        var balance = _riskManager.DrawdownTracker.CurrentBalance;
        if (!_riskManager.ValidateSignal(signal, balance, out var reason))
        {
            TradeLog.Rejected(symbol, "risk", reason);
            return;
        }

        if (!signal.EntryPrice.HasValue || signal.EntryPrice.Value <= 0 ||
            !signal.StopLoss.HasValue || !signal.TakeProfit.HasValue)
        {
            TradeLog.Rejected(symbol, "signal", "в сигнале нет корректных entry/SL/TP");
            return;
        }

        // 7. Размер позиции.
        var atr = indicators.TryGetValue("atr_pct", out var atrPct)
            ? atrPct * currentCandle.Close
            : currentCandle.Close * 0.02m; // Fallback: 2% от цены

        var side = signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell;
        var preliminaryStopLoss = _riskManager.CalculateStopLoss(side, signal.EntryPrice.Value, atr);

        var quantity = _riskManager.CalculatePositionSize(
            balance,
            signal.EntryPrice.Value,
            preliminaryStopLoss,
            atr);

        // 7a. Спот без плеча: свободные деньги = баланс минус капитал в открытых позициях.
        //     PositionSizer ограничивает объём всем балансом, поэтому при MaxOpenPositions=3
        //     бот набирал до 3x баланса (в live Binance отклонял ордер по -2010).
        var freeCash = GetFreeCash(balance);
        var feeBuffer = 1m + FeeRate;
        var maxAffordable = freeCash > 0 ? freeCash / (signal.EntryPrice.Value * feeBuffer) : 0m;

        if (maxAffordable <= 0)
        {
            TradeLog.Rejected(symbol, "cash",
                $"нет свободных средств: баланс {balance:F2}, в позициях {balance - freeCash:F2} USDT");
            return;
        }

        // Лимит конкретной пары из symbols.json, в дополнение к риск-сайзингу и свободным средствам.
        if (_config.Trading.SymbolPositionLimits.TryGetValue(symbol, out var positionPercent))
        {
            var symbolCap = balance * positionPercent / 100m / (signal.EntryPrice.Value * feeBuffer);
            if (quantity > symbolCap)
            {
                TradeLog.Decision(symbol, "SYMBOL-CAP", $"объём ограничен лимитом пары {positionPercent}%: {quantity:F8} → {symbolCap:F8}");
                quantity = symbolCap;
            }
        }

        if (quantity > maxAffordable)
        {
            TradeLog.Decision(symbol, "SIZE-CAP",
                $"объём урезан по свободным средствам: {quantity:F8} → {maxAffordable:F8} " +
                $"(свободно {freeCash:F2} USDT из {balance:F2})");
            quantity = maxAffordable;
        }

        if (quantity <= 0)
        {
            TradeLog.Rejected(symbol, "sizing", "рассчитанный объём <= 0");
            return;
        }

        var currentOrderBook = GetCurrentOrderBook(symbol);

        // 7b. P1.5: ликвидность перед входом — спред / глубина стороны входа / объём свечей.
        //     Раньше широкий спред только логировался, вход не блокировался.
        if (!PassesLiquidityFilter(symbol, side, quantity, signal.EntryPrice.Value, currentOrderBook, currentCandle.Close))
            return;

        // 8. Исполнение. Ордер возвращается только после реального исполнения.
        var order = await _orderExecutor.ExecuteSignalAsync(signal, quantity, currentOrderBook, ct);
        if (order == null)
            return;

        // 9. Позиция открывается на ФАКТИЧЕСКИ исполненный объём и цену.
        var executedQuantity = order.ExecutedQuantity > 0 ? order.ExecutedQuantity : quantity;
        var actualEntry = order.AverageFillPrice ?? order.Price;
        if (actualEntry <= 0)
            actualEntry = signal.EntryPrice.Value;

        var stopLoss = _riskManager.CalculateStopLoss(side, actualEntry, atr);

        var takeProfit = signal.TakeProfit.Value;
        var reward = Math.Abs(takeProfit - actualEntry);
        var risk = Math.Abs(actualEntry - stopLoss);
        var tpDirectionOk = side == OrderSide.Buy ? takeProfit > actualEntry : takeProfit < actualEntry;
        if (!tpDirectionOk || risk <= 0 || reward / risk < (decimal)_config.Trading.MinRiskRewardRatio)
        {
            takeProfit = _riskManager.CalculateTakeProfit(side, actualEntry, stopLoss);
        }

        // Цена-ориентир для защитных ног: серединa стакана актуальнее закрытия свечи —
        // Binance проверяет правило OCO относительно последней цены, а не нашей свечи.
        var referencePrice = currentOrderBook?.MidPrice is { } mid && mid > 0m ? mid : currentCandle.Close;

        var position = new Position
        {
            Symbol = symbol,
            Side = side,
            Quantity = executedQuantity,
            EntryPrice = actualEntry,
            CurrentPrice = referencePrice,
            StopLoss = stopLoss,
            TakeProfit = takeProfit,
            InitialStopLoss = stopLoss,
            OpenedAt = DateTime.UtcNow,
            OpeningOrderId = order.Id,
            EntryCommission = order.Commission,
            SignalId = signal.Timestamp.ToString("yyyyMMddHHmmss")
        };

        // P0.2: вход и постановка защиты — под посимвольным шлюзом, чтобы тик-контур
        // не начал сопровождать позицию раньше, чем она защищена на бирже.
        var protectionFailed = false;
        using (await _positionMonitor.LockSymbolAsync(symbol, ct))
        {
            await _positionManager.AddPositionAsync(position, ct);

            // P0.1: биржевая защита ставится СРАЗУ после филла входа.
            if (await _orderExecutor.EnsureProtectionAsync(position, ct))
            {
                if (position.Protection != null)
                    await _positionManager.SavePositionsAsync(ct);
            }
            else
            {
                protectionFailed = true;
            }
        }

        // Не встала — позиция закрывается market'ом (правило «нет защиты → нет позиции»).
        // Вне шлюза: ClosePositionAsync берёт его сам.
        if (protectionFailed)
        {
            if (!_config.Trading.ClosePositionIfProtectionFails ||
                !_config.Trading.ExchangeProtectionEnabled ||
                _config.Trading.PaperTradingMode)
            {
                _logger.LogWarning(
                    "Позиция {Symbol} без биржевой защиты: работает только локальный SL (Trading:ClosePositionIfProtectionFails=false)",
                    symbol);
            }
            else
            {
                _logger.LogError("Позиция {Symbol} без биржевой защиты — аварийное закрытие market", symbol);
                TradeLog.Rejected(symbol, "protection",
                    "OCO не поставлена: закрываем позицию, чтобы капитал не зависел от живого процесса");
                await ClosePositionAsync(position, "NoExchangeProtection", ct);
                return;
            }
        }

        OnPositionOpened?.Invoke(position);

        TradeLog.Opened(symbol, side.ToString(), executedQuantity, actualEntry, stopLoss, takeProfit,
            _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName, order.Id);

        // Комиссия входа уменьшает свободный баланс уже сейчас (paper-режим).
        if (_config.Trading.PaperTradingMode && order.Commission > 0)
        {
            await UpdateRiskBalanceAsync(_riskManager.DrawdownTracker.CurrentBalance - order.Commission, ct);
            LogBalance();
        }

        lock (_reviewLock)
        {
            _lastPositionReview[symbol] = DateTime.UtcNow;
        }

        _logger.LogInformation(
            "Открыта позиция: {Symbol} {Side} {Quantity} @ {Entry}, SL: {SL}, TP: {TP}",
            symbol, position.Side, executedQuantity, actualEntry, stopLoss, takeProfit);
    }

    /// <summary>
    /// Ставка комиссии для расчёта «сколько денег реально нужно под ордер».
    /// В paper-режиме берётся из конфига, в live/demo — консервативные 0.1% (spot).
    /// </summary>
    private decimal FeeRate => _config.Trading.PaperTradingMode
        ? Math.Clamp(_config.Trading.PaperCommissionRate, 0m, 0.01m)
        : 0.001m;

    /// <summary>
    /// Свободные средства спот-счёта: баланс минус капитал, уже вложенный в открытые позиции.
    /// Баланс в RiskManager — это «деньги + позиции по себестоимости», поэтому вычитаем notional.
    /// </summary>
    private decimal GetFreeCash(decimal balance)
    {
        var committed = _positionManager.GetOpenPositions().Sum(p => p.Notional);
        return Math.Max(0m, balance - committed);
    }

    /// <summary>
    /// Контекст для модели: открытая позиция, спот-ограничения, минимальные R/R и уверенность.
    /// </summary>
    private AiRequestContext BuildAiContext(
        string symbol,
        Position? position,
        EngineScore? preScore = null,
        Dictionary<string, decimal>? indicators = null,
        decimal price = 0m) => new()
    {
        HasPosition = position != null,
        PositionSide = position == null ? null : (position.Side == OrderSide.Buy ? "LONG" : "SHORT"),
        EntryPrice = position?.EntryPrice,
        Quantity = position?.Quantity,
        UnrealizedPnlPercent = position?.UnrealizedPnLPercent,
        StopLoss = position?.StopLoss,
        TakeProfit = position?.TakeProfit,
        MinutesInPosition = position == null
            ? null
            : (DateTime.UtcNow - position.OpenedAt).TotalMinutes,
        AllowShort = _config.Trading.AllowShort,
        MinRiskReward = (decimal)_config.Trading.MinRiskRewardRatio,
        MinConfidence = _config.AI.MinConfidence,
        StopLossAtrMultiplier = (decimal)_config.Trading.StopLossAtrMultiplier,
        EngineScore = preScore?.Direction,
        EngineDirection = preScore?.DirectionName,
        EnginePriorConfidence = preScore?.PriorConfidence,
        EngineReasons = preScore?.Reasons,
        EngineFacts = preScore?.Facts,
        PriceDecimals = GetPriceDecimals(symbol),
        TickSize = GetTickSize(symbol)
    };

    /// <summary>Контекст калибровки: пороги, спот-ограничения, цена и ATR для детерминированного входа.</summary>
    private CalibrationContext BuildCalibrationContext(
        string symbol, Dictionary<string, decimal> indicators, decimal price, bool hasPosition) => new()
    {
        MinConfidence = _config.AI.MinConfidence,
        HasPosition = hasPosition,
        AllowShort = _config.Trading.AllowShort,
        Price = price,
        AtrAbsolute = indicators.TryGetValue("atr_abs", out var atrAbs) && atrAbs > 0m
            ? atrAbs
            : indicators.TryGetValue("atr_pct", out var atrPct) ? atrPct * price : price * 0.01m,
        StopLossAtrMultiplier = (decimal)_config.Trading.StopLossAtrMultiplier,
        MinRiskReward = (decimal)_config.Trading.MinRiskRewardRatio,
        PriceDecimals = GetPriceDecimals(symbol)
    };

    private async Task ValidateSymbolsAsync(CancellationToken ct)
    {
        var valid = (await _restClient.GetValidSymbolsAsync(ct)).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var available = new List<string>();
        var unavailable = new List<string>();
        foreach (var symbol in _config.Trading.Symbols)
        {
            ct.ThrowIfCancellationRequested();
            if (!valid.Contains(symbol)) { unavailable.Add(symbol); continue; }
            try
            {
                var info = await _restClient.GetSymbolInfoAsync(symbol, ct);
                if (info is null || !info.IsSpotTradingAllowed ||
                    !string.Equals(info.Status, "TRADING", StringComparison.OrdinalIgnoreCase))
                {
                    unavailable.Add(symbol);
                    continue;
                }
                var tick = info.TickSize > 0 ? info.TickSize : (decimal?)null;
                var configured = _config.Trading.SymbolPriceDecimals.TryGetValue(symbol, out var decimals);
                var precision = tick.HasValue ? TickDecimals(tick.Value) : configured ? decimals : 8;
                _symbolPrecision[symbol] = new SymbolPrecision(precision, tick, info.StepSize > 0 ? info.StepSize : null);
                available.Add(symbol);
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                unavailable.Add(symbol);
                _logger.LogWarning(ex, "Фильтры {Symbol} недоступны; пара отключена до следующего старта", symbol);
            }
        }
        UnavailableSymbols = unavailable;
        foreach (var symbol in unavailable)
            _logger.LogWarning("SYMBOL UNAVAILABLE: {Symbol} отключена в текущем окружении {Environment}", symbol, _restClient.EnvironmentName);
        _activeSymbols = available;
        if (available.Count == 0) throw new InvalidOperationException("Нет доступных торговых пар в выбранном окружении Binance.");
    }

    private static int TickDecimals(decimal tick)
    {
        var text = tick.ToString("G29", CultureInfo.InvariantCulture).TrimEnd('0');
        var dot = text.IndexOf('.');
        return dot < 0 ? 0 : Math.Clamp(text.Length - dot - 1, 0, 12);
    }
    private int GetPriceDecimals(string symbol) =>
        _symbolPrecision.TryGetValue(symbol, out var precision) ? precision.PriceDecimals
        : _config.Trading.SymbolPriceDecimals.TryGetValue(symbol, out var decimals) ? decimals : 8;
    private decimal? GetTickSize(string symbol) =>
        _symbolPrecision.TryGetValue(symbol, out var precision) ? precision.TickSize : null;

    /// <summary>
    /// Троттлинг WAITING-лога: не чаще раза в минуту на символ, чтобы не залить logs/trades-*.log.
    /// </summary>
    private void LogWaiting(string symbol, string reason)
    {
        lock (_throttleLock)
        {
            if (_lastWaitingLog.TryGetValue(symbol, out var last) &&
                DateTime.UtcNow - last < TimeSpan.FromMinutes(1))
                return;

            _lastWaitingLog[symbol] = DateTime.UtcNow;
        }

        TradeLog.Waiting(symbol, reason);
    }

    /// <summary>Cooldown анализа символа (B11). true — можно спрашивать ИИ.</summary>
    private bool TryEnterAnalysisCooldown(string symbol)
    {
        var cooldown = _config.Trading.SymbolAnalysisCooldownSeconds;
        if (cooldown <= 0)
            return true;

        lock (_throttleLock)
        {
            if (_lastSymbolAnalysis.TryGetValue(symbol, out var last) &&
                DateTime.UtcNow - last < TimeSpan.FromSeconds(cooldown))
                return false;

            _lastSymbolAnalysis[symbol] = DateTime.UtcNow;
        }

        return true;
    }

    /// <summary>
    /// Периодический вопрос модели об открытой позиции: держать или закрыть.
    /// Без этого шага ИИ умел только открывать сделки, а выход был лишь по SL/TP.
    /// </summary>
    private async Task ReviewOpenPositionAsync(string symbol, CancellationToken ct)
    {
        if (!_config.Trading.AiCanClosePositions)
            return;

        lock (_reviewLock)
        {
            if (_lastPositionReview.TryGetValue(symbol, out var last) &&
                DateTime.UtcNow - last < TimeSpan.FromSeconds(_config.Trading.PositionReviewIntervalSeconds))
                return;

            _lastPositionReview[symbol] = DateTime.UtcNow;
        }

        var position = _positionManager.GetPositionBySymbol(symbol);
        if (position == null)
            return;

        var candle = GetCurrentCandle(symbol);
        if (candle == null)
            return;

        var indicators = _marketAnalyzer.GetIndicatorSnapshot(symbol, candle);
        if (indicators == null)
        {
            var warmup = _marketAnalyzer.GetWarmupInfo(symbol);
            LogWaiting(symbol, $"прогрев индикаторов: {warmup.Candles}/{warmup.Required} свечей (позиция открыта)");
            return;
        }

        var preScore = _calibrator.PreScore(indicators);
        TradeLog.Decision(symbol, "PRE-SCORE", $"{preScore.Summary}; {preScore.ReasonsText} (сопровождение позиции)");

        var newsContext = await _sentimentAnalyzer.GetNewsContextAsync(symbol, ct);
        var signal = await _aiModel.GetTradingSignalAsync(
            symbol, indicators, newsContext, BuildAiContext(symbol, position, preScore, indicators, candle.Close), ct);

        signal = _calibrator.Calibrate(signal, preScore, _config.AI.ResolvedConfidencePolicy,
            BuildCalibrationContext(symbol, indicators, candle.Close, hasPosition: true),
            blendModelWeight: _config.AI.BlendModelWeight);

        _metrics.RecordSignal(signal);
        _metrics.RecordInferenceTime(_aiModel.LastInferenceTimeMs);
        OnSignalGenerated?.Invoke(signal);

        // CLOSE — явный выход. BUY/SELL — выход, если действие противоположно стороне позиции.
        var opposite = position.Side == OrderSide.Buy
            ? signal.Action == SignalAction.Sell
            : signal.Action == SignalAction.Buy;

        if (signal.Action != SignalAction.Close && !opposite)
        {
            TradeLog.Decision(symbol, "HOLD",
                $"позиция открыта, ИИ держит (conf={signal.Confidence:P0}): {signal.Reasoning}");
            return;
        }

        if (signal.Confidence < _config.AI.MinConfidence)
        {
            TradeLog.Decision(symbol, "HOLD",
                $"ИИ предлагал выход, но уверенность {signal.Confidence:P0} < {_config.AI.MinConfidence:P0}");
            return;
        }

        TradeLog.Decision(symbol, "CLOSE",
            $"решение ИИ (conf={signal.Confidence:P0}): {signal.Reasoning}");

        await ClosePositionAsync(position, $"AI-{signal.Action}", ct);
    }

    /// <summary>
    /// Ручное закрытие позиции из UI — проходит через тот же пайплайн,
    /// что и автоматическое (ордер, история, баланс, события).
    /// </summary>
    public Task ClosePositionManuallyAsync(Position position, CancellationToken ct = default)
    {
        return ClosePositionAsync(position, "Manual", ct);
    }

    private async Task ClosePositionAsync(Position position, string reason, CancellationToken ct, decimal? exitPriceOverride = null)
    {
        // P0.2: закрытие может прийти одновременно из тик-контура, из ИИ-пересмотра и из UI.
        // Шлюз + повторная проверка «позиция ещё открыта» исключают двойной MARKET-выход.
        using (await _positionMonitor.LockSymbolAsync(position.Symbol, ct))
        {
            if (_positionManager.GetPositionById(position.Id) is null)
            {
                _logger.LogInformation(
                    "Позиция {Symbol} уже закрыта другим контуром — повторное закрытие ({Reason}) пропущено",
                    position.Symbol, reason);
                return;
            }

            await ClosePositionCoreAsync(position, reason, ct, exitPriceOverride);
        }
    }

    private async Task ClosePositionCoreAsync(Position position, string reason, CancellationToken ct, decimal? exitPriceOverride)
    {
        _logger.LogInformation("Закрытие позиции {Symbol} по причине: {Reason}", position.Symbol, reason);

        // Фиксируем цену выхода: для SL/TP — уровень срабатывания, для ручного — текущая
        if (exitPriceOverride.HasValue && exitPriceOverride.Value > 0)
        {
            position.UpdatePrice(exitPriceOverride.Value);
        }

        var order = await _orderExecutor.ClosePositionAsync(position, ct);
        if (order == null)
        {
            TradeLog.Rejected(position.Symbol, "close", "ордер на закрытие не исполнен — позиция остаётся открытой");
            _logger.LogError("Не удалось закрыть позицию {Symbol}", position.Symbol);
            return;
        }

        // Для live используем фактическую цену исполнения, если она есть
        var fillPrice = order.AverageFillPrice;
        if (fillPrice.HasValue && fillPrice.Value > 0)
        {
            position.UpdatePrice(fillPrice.Value);
        }

        // Закрываем ровно тот объём, который реально продан/куплен биржей.
        var closedQuantity = order.ExecutedQuantity > 0 ? order.ExecutedQuantity : position.Quantity;
        if (closedQuantity > position.Quantity)
            closedQuantity = position.Quantity;

        var remaining = position.Quantity - closedQuantity;
        var isPartial = remaining > 0m;

        // Создание записи о сделке (на фактически закрытый объём)
        var trade = new TradeRecord
        {
            Symbol = position.Symbol,
            Side = position.Side,
            Quantity = closedQuantity,
            EntryPrice = position.EntryPrice,
            ExitPrice = position.CurrentPrice,
            PnL = (position.Side == OrderSide.Buy
                ? position.CurrentPrice - position.EntryPrice
                : position.EntryPrice - position.CurrentPrice) * closedQuantity,
            PnLPercent = position.UnrealizedPnLPercent,
            Commission = position.EntryCommission + order.Commission,
            ExitReason = isPartial ? reason + "-partial" : reason,
            OpenedAt = position.OpenedAt,
            ClosedAt = DateTime.UtcNow,
            SignalId = position.SignalId
        };

        await _tradeHistory.SaveTradeAsync(trade, ct);

        // P0.5: тот же close-ордер может прийти позже как executionReport/запись журнала —
        // кумулятив уже применён штатным закрытием, повтор не должен уменьшить позицию ещё раз.
        if (!string.IsNullOrWhiteSpace(order.ClientOrderId))
            position.RecordExchangeFill(order.ClientOrderId, order.ExecutedQuantity);

        if (isPartial)
        {
            // Биржа исполнила не всё (тонкий стакан / лимиты): остаток остаётся открытой
            // позицией и будет дозакрыт на следующем цикле, а не «исчезает» из учёта.
            position.ReduceQuantity(closedQuantity);
            position.EntryCommission = 0m; // комиссия входа уже учтена в записи выше
            await _positionManager.SavePositionsAsync(ct);

            TradeLog.Rejected(position.Symbol, "close-partial",
                $"закрыто {closedQuantity} из {closedQuantity + remaining}, остаток {remaining} остаётся открытым");
        }
        else
        {
            await _positionManager.RemovePositionAsync(position.Id, ct);

            lock (_reviewLock)
            {
                _lastPositionReview.Remove(position.Symbol);
            }
        }

        var mode = _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName;
        TradeLog.Closed(position.Symbol, trade.ExitReason, closedQuantity, position.EntryPrice, position.CurrentPrice,
            trade.PnL, trade.PnLPercent, trade.Commission, mode);

        // Обновление баланса (P0.4: каждое изменение сразу персистится в risk_state.json)
        if (_config.Trading.PaperTradingMode)
        {
            // В paper-режиме баланс виртуальный: прибавляем реализованный PnL закрытой части
            await UpdateRiskBalanceAsync(_riskManager.DrawdownTracker.CurrentBalance + trade.PnL - order.Commission, ct);
        }
        else
        {
            var balance = await _restClient.GetAccountBalanceAsync(ct);
            await UpdateRiskBalanceAsync(balance.AvailableUSDT, ct);
        }

        LogBalance();

        if (isPartial)
        {
            // Позиция ещё открыта — событие закрытия не шлём (UI иначе уберёт её из списка).
            // Количество в UI обновится само: Position реализует INotifyPropertyChanged.
            _metrics.RecordTrade(trade);
        }
        else
        {
            OnPositionClosed?.Invoke(trade);
        }

        _logger.LogInformation(
            "Позиция {Outcome}: {Symbol} PnL: {PnL:F2} ({PnLPct:F2}%), Reason: {Reason}",
            isPartial ? "закрыта частично" : "закрыта",
            position.Symbol, trade.PnL, trade.PnLPercent, reason);
    }

    /// <summary>
    /// P0.4: часы биржи для границы торгового дня. Смещение оценивается один раз при старте
    /// (полудлина RTT, как в синхронизации подписи BinanceRestClient); при недоступности /time
    /// остаются локальные UTC-часы.
    /// </summary>
    private async Task ConfigureExchangeClockAsync(CancellationToken ct)
    {
        try
        {
            var localBefore = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            var serverTime = await _restClient.GetServerTimeAsync(ct);
            var localAfter = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            var offsetMs = serverTime - localBefore - (localAfter - localBefore) / 2;

            _riskManager.DrawdownTracker.SetExchangeClock(() => DateTime.UtcNow.AddMilliseconds(offsetMs));
            _logger.LogInformation("Граница риск-дня по часам биржи: смещение {Offset} мс", offsetMs);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось получить время биржи — граница дня по локальным UTC-часам");
        }
    }

    /// <summary>P0.4: снимок риск-состояния на диск (атомарно, внутри репозитория).</summary>
    private Task PersistRiskStateAsync(CancellationToken ct) =>
        _stateRepository.SaveRiskStateAsync(_riskManager.DrawdownTracker.CaptureState(), ct);

    /// <summary>P0.4: обновить баланс и сразу зафиксировать пик/дневной старт — рестарт не обнуляет лимиты.</summary>
    private async Task UpdateRiskBalanceAsync(decimal newBalance, CancellationToken ct)
    {
        _riskManager.UpdateBalance(newBalance);
        await PersistRiskStateAsync(ct);

        // P0.6: пробитие лимита после обновления баланса больше не просто запрещает входы —
        // взводим kill-switch и закрываем все позиции.
        if (_riskManager.ShouldEngageKillSwitch && !IsKillSwitchEngaged)
        {
            var reason = _riskManager.DrawdownTracker.IsMaxDrawdownHit ? "MaxDrawdown" : "DailyLoss";
            await EngageKillSwitchAsync(reason, ct);
        }
    }

    /// <summary>
    /// P0.5: применить филл, уже случившийся на бирзе (защитная нога / close из журнала),
    /// к позиции, истории и балансу — БЕЗ повторного MARKET. Дедуп по кумулятиву ордера
    /// в Position.AppliedExchangeFills переживает рестарт и повторные executionReport.
    /// </summary>
    private async Task<bool> ApplyExchangeFillAsync(Position position, ExecutionReport report, string reason, CancellationToken ct)
    {
        decimal closedQuantity;
        TradeRecord trade;
        bool fullyClosed;

        using (await _positionMonitor.LockSymbolAsync(position.Symbol, ct))
        {
            var live = _positionManager.GetPositionById(position.Id);
            if (live is null) return false;

            var unapplied = live.GetUnappliedExchangeFill(report.ClientOrderId, report.CumulativeQuantity);
            if (unapplied <= 0) return false;

            closedQuantity = Math.Min(unapplied, live.Quantity);
            if (closedQuantity <= 0) return false;

            var exitPrice = report.LastPrice > 0
                ? report.LastPrice
                : report.CumulativeQuantity > 0 && report.CumulativeQuoteQuantity > 0
                    ? report.CumulativeQuoteQuantity / report.CumulativeQuantity
                    : live.CurrentPrice;
            if (exitPrice <= 0) exitPrice = live.EntryPrice;

            live.UpdatePrice(exitPrice);

            var entryCommissionPart = live.Quantity > 0
                ? live.EntryCommission * closedQuantity / live.Quantity
                : 0m;

            trade = new TradeRecord
            {
                Symbol = live.Symbol,
                Side = live.Side,
                Quantity = closedQuantity,
                EntryPrice = live.EntryPrice,
                ExitPrice = exitPrice,
                PnL = (live.Side == OrderSide.Buy ? exitPrice - live.EntryPrice : live.EntryPrice - exitPrice) * closedQuantity,
                PnLPercent = live.EntryPrice > 0
                    ? (live.Side == OrderSide.Buy ? exitPrice - live.EntryPrice : live.EntryPrice - exitPrice) / live.EntryPrice * 100m
                    : 0m,
                Commission = entryCommissionPart + report.Commission,
                ExitReason = reason,
                OpenedAt = live.OpenedAt,
                ClosedAt = report.TransactionTimeUtc > 0 ? report.TransactionTimeUtc : DateTime.UtcNow,
                SignalId = live.SignalId
            };

            await _tradeHistory.SaveTradeAsync(trade, ct);

            // Дедуп-леджер фиксируем до удаления/уменьшения позиции.
            live.RecordExchangeFill(report.ClientOrderId, report.CumulativeQuantity);
            live.EntryCommission = Math.Max(0m, live.EntryCommission - entryCommissionPart);

            var remaining = live.Quantity - closedQuantity;
            fullyClosed = remaining <= 0m;
            if (fullyClosed)
            {
                await _positionManager.RemovePositionAsync(live.Id, ct);
                lock (_reviewLock) _lastPositionReview.Remove(live.Symbol);
            }
            else
            {
                live.ReduceQuantity(closedQuantity);
                await _positionManager.SavePositionsAsync(ct);
            }
        }

        // Частичный филл защитной ноги мог оставить объём защиты больше объёма позиции —
        // снимаем старую OCO, контур сопровождения поставит новую на остаток.
        if (!fullyClosed && reason is "ExchangeStopLoss" or "ExchangeTakeProfit")
        {
            var live = _positionManager.GetPositionById(position.Id);
            if (live?.Protection != null)
            {
                await _orderExecutor.CancelProtectionAsync(live, ct);
                await _positionManager.SavePositionsAsync(ct);
            }
        }

        var mode = _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName;
        TradeLog.Closed(position.Symbol, reason, closedQuantity, trade.EntryPrice, trade.ExitPrice,
            trade.PnL, trade.PnLPercent, trade.Commission, mode);

        if (!_config.Trading.PaperTradingMode)
        {
            var balance = await _restClient.GetAccountBalanceAsync(ct);
            await UpdateRiskBalanceAsync(balance.AvailableUSDT, ct);
        }
        LogBalance();

        _metrics.RecordReconciliationFill();
        if (fullyClosed)
            OnPositionClosed?.Invoke(trade);
        else
            _metrics.RecordTrade(trade);

        _logger.LogWarning(
            "EXCHANGE-FILL-APPLIED: {Symbol} {Reason} qty={Qty}@{Price}, остаток={Remaining}, без повторного MARKET",
            position.Symbol, reason, closedQuantity, trade.ExitPrice, fullyClosed ? 0m : position.Quantity);
        return true;
    }

    /// <summary>
    /// P0.5: подхватить сиротскую позицию бота (entry исполнился, пока процесс был мёртв,
    /// либо positions.json потерял запись). Ставим защиту сразу; fail-closed сохраняет правило
    /// «нет биржевой защиты → нет позиции».
    /// </summary>
    private async Task AdoptOrphanPositionAsync(Position orphan, CancellationToken ct)
    {
        using (await _positionMonitor.LockSymbolAsync(orphan.Symbol, ct))
        {
            if (_positionManager.GetPositionBySymbol(orphan.Symbol) != null) return;

            var atr = GetAtrAbsolute(orphan.Symbol) ?? orphan.EntryPrice * 0.02m;
            orphan.StopLoss = _riskManager.CalculateStopLoss(orphan.Side, orphan.EntryPrice, atr);
            orphan.TakeProfit = _riskManager.CalculateTakeProfit(orphan.Side, orphan.EntryPrice, orphan.StopLoss);
            orphan.InitialStopLoss = orphan.StopLoss;
            orphan.SignalId = "reconciled";

            await _positionManager.AddPositionAsync(orphan, ct);
            var protectedOk = await _orderExecutor.EnsureProtectionAsync(orphan, ct);
            if (protectedOk && orphan.Protection != null)
                await _positionManager.SavePositionsAsync(ct);

            OnPositionOpened?.Invoke(orphan);
            TradeLog.Opened(orphan.Symbol, orphan.Side.ToString(), orphan.Quantity, orphan.EntryPrice,
                orphan.StopLoss, orphan.TakeProfit,
                _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName, orphan.OpeningOrderId);

            if (!protectedOk && _config.Trading.ClosePositionIfProtectionFails &&
                _config.Trading.ExchangeProtectionEnabled && !_config.Trading.PaperTradingMode)
            {
                _logger.LogError("RECON-ADOPT: сиротская позиция {Symbol} без защиты — аварийное закрытие", orphan.Symbol);
                await ClosePositionCoreAsync(orphan, "NoExchangeProtection", ct, null);
            }
        }
    }

    /// <summary>
    /// P0.6: взвести kill-switch (авто по лимиту риска или ручная паника из UI):
    /// блокировка новых входов + закрытие всех позиций штатным пайплайном
    /// (снятие OCO → market → история → баланс → события). Идемпотентно.
    /// </summary>
    public async Task<int> EngageKillSwitchAsync(string reason, CancellationToken ct = default)
    {
        var first = Interlocked.CompareExchange(ref _killSwitchEngaged, 1, 0) == 0;
        if (first)
        {
            _metrics.RecordKillSwitch();
            _logger.LogCritical("KILL-SWITCH: {Reason} — новые входы заблокированы, закрываю все позиции", reason);
            Pause(); // если уже Running; в Starting флаг выше всё равно блокирует входы
            OnKillSwitchEngaged?.Invoke(reason);
        }

        return await CloseAllPositionsAsync($"KillSwitch:{reason}", ct);
    }

    /// <summary>
    /// P0.6: закрыть все открытые позиции. Каждое закрытие проходит посимвольный шлюз
    /// и повторную проверку «ещё открыта» — гонка с тик-контуром/ИИ-пересмотром исключена.
    /// Возвращает число реально закрытых позиций; сбой одной не прерывает остальные.
    /// </summary>
    public async Task<int> CloseAllPositionsAsync(string reason, CancellationToken ct = default)
    {
        var open = _positionManager.GetOpenPositions().ToList();
        if (open.Count == 0) return 0;

        _logger.LogWarning("KILL-SWITCH: закрытие {Count} позиций ({Reason})", open.Count, reason);
        var closed = 0;
        foreach (var position in open)
        {
            try
            {
                await ClosePositionAsync(position, reason, ct);
                if (_positionManager.GetPositionById(position.Id) is null)
                    closed++;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                _logger.LogError(ex, "KILL-SWITCH: не удалось закрыть {Symbol} — позиция остаётся под сопровождением", position.Symbol);
            }
        }

        _logger.LogWarning("KILL-SWITCH: закрыто {Closed}/{Total} позиций ({Reason})", closed, open.Count, reason);
        return closed;
    }

    /// <summary>
    /// P0.6: явный сброс kill-switch (после разбора причины). UI-флоу сброса — остаток пункта;
    /// Resume сам по себе kill-switch НЕ снимает.
    /// </summary>
    public void ResetKillSwitch()
    {
        if (Interlocked.Exchange(ref _killSwitchEngaged, 0) == 1)
            _logger.LogWarning("KILL-SWITCH: сброшен вручную — входы снова разрешены");
    }

    /// <summary>Пишет срез баланса/просадки в logs/trades-*.log.</summary>
    private void LogBalance()
    {
        var tracker = _riskManager.DrawdownTracker;
        var equity = tracker.CurrentBalance + _positionManager.GetOpenPositions().Sum(p => p.UnrealizedPnL);

        TradeLog.Balance(
            _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName,
            tracker.CurrentBalance,
            equity,
            tracker.CurrentDrawdownPercent * 100m);
    }

    private void OnKlineReceived(OHLCV candle)
    {
        // 1. Сохраняем текущую свечу в кэш для актуальной цены. Внутриинтервальные
        //    тики не участвуют в volume_ratio: снапшот берёт объём последней закрытой
        //    свечи из IndicatorCalculator, обновляемого ниже только при IsClosed.
        lock (_candleLock)
        {
            _currentCandles[candle.Symbol] = candle;
        }

        // 2. ГАРАНТИРОВАННО создаем калькулятор индикаторов при первом получении данных
        _marketAnalyzer.GetOrCreateCalculator(candle.Symbol);

        // 3. Если свеча закрыта, обновляем индикаторы (добавляем в историю)
        if (candle.IsClosed)
        {
            _marketAnalyzer.UpdateIndicators(candle.Symbol, candle);
        }

        // 4. Обновляем текущую цену для расчета PnL открытых позиций
        _positionManager.UpdatePrices(candle.Symbol, candle.Close);

        // 5. ATR для трейлинга пересчитываем только на закрытой свече (индикаторы всё равно
        //    обновляются лишь по закрытым свечам) — тик-контур берёт готовое значение.
        if (candle.IsClosed)
            RefreshAtrCache(candle.Symbol, candle);

        // 6. P0.2: тик в независимый контур сопровождения. Только запись в словарь:
        //    WebSocket receive-loop не должен ждать REST/SL-проверок.
        _positionMonitor.OnKlineTick(candle);
    }

    private void RefreshAtrCache(string symbol, OHLCV candle)
    {
        try
        {
            var indicators = _marketAnalyzer.GetIndicatorSnapshot(symbol, candle);
            if (indicators == null)
                return;

            var atr = indicators.TryGetValue("atr_abs", out var abs) && abs > 0m
                ? abs
                : indicators.TryGetValue("atr_pct", out var pct) ? pct * candle.Close : 0m;

            if (atr > 0m)
                _atrAbsolute[symbol] = atr;
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Не удалось обновить ATR для {Symbol}", symbol);
        }
    }

    /// <summary>Абсолютный ATR символа для тик-контура (null — ещё не прогрет).</summary>
    private decimal? GetAtrAbsolute(string symbol) =>
        _atrAbsolute.TryGetValue(symbol, out var atr) && atr > 0m ? atr : null;

    private void OnOrderBookReceived(OrderBook orderBook)
    {
        // Кэшируем актуальный стакан для каждого символа
        lock (_orderBookLock)
        {
            _currentOrderBooks[orderBook.Symbol] = orderBook;
        }

        // P0.2: стакан — самый частый тик (partial-depth 1 с) и лучшая цена выхода
        // (bid для long, ask для short). Обработчик не блокируется.
        _positionMonitor.OnOrderBookTick(orderBook);

        // Логирование аномально широкого спреда (защита от манипуляций или низкой ликвидности)
        if (orderBook.Spread.HasValue && orderBook.MidPrice.HasValue)
        {
            var spreadPercent = (orderBook.Spread.Value / orderBook.MidPrice.Value) * 100m;
            if (spreadPercent > 0.5m) // Спред более 0.5%
            {
                _logger.LogWarning(
                    "Аномально широкий спред на {Symbol}: {SpreadPercent:F3}% (Bid: {Bid}, Ask: {Ask})",
                    orderBook.Symbol, spreadPercent, orderBook.BestBid, orderBook.BestAsk);
            }
        }
    }

    private OrderBook? GetCurrentOrderBook(string symbol)
    {
        lock (_orderBookLock)
        {
            return _currentOrderBooks.TryGetValue(symbol, out var ob) ? ob : null;
        }
    }

    /// <summary>
    /// P1.5: фильтр ликвидности перед входом. Пороги — глобальные из TradingConfig,
    /// точечные — из symbols.json (SymbolLiquidityOverrides: BTTC/STRAX/FLR и прочие тонкие пары).
    /// Отказ попадает в воронку как Rejected/liquidity и агрегируется в метрику;
    /// применяется и в paper-режиме, чтобы «бумажная» статистика не врала.
    /// </summary>
    private bool PassesLiquidityFilter(
        string symbol,
        OrderSide side,
        decimal quantity,
        decimal fallbackPrice,
        OrderBook? orderBook,
        decimal lastPrice)
    {
        var cfg = _config.Trading;
        if (!cfg.LiquidityFilterEnabled)
            return true;

        cfg.SymbolLiquidityOverrides.TryGetValue(symbol, out var ov);
        var thresholds = new LiquidityThresholds
        {
            MaxSpreadPercent = ov?.MaxSpreadPercent ?? cfg.MaxEntrySpreadPercent,
            MinDepthQuote = ov?.MinDepthQuote ?? cfg.MinEntryDepthQuote,
            MinDepthNotionalRatio = cfg.MinDepthNotionalRatio,
            DepthLevels = cfg.LiquidityDepthLevels,
            MinCandleQuoteVolume = ov?.MinCandleQuoteVolume ?? cfg.MinCandleQuoteVolume
        };

        // Средний объём закрытой свечи в котировке: SMA20 объёма закрытых свечей × текущая цена.
        // Незакрытая WS-свеча в оценку не попадает (контракт фикса volume_ratio, проход 11).
        var avgCandleQuoteVolume = _marketAnalyzer.GetOrCreateCalculator(symbol).VolumeSma20 * lastPrice;

        var result = LiquidityFilter.Evaluate(orderBook, side, quantity, fallbackPrice, avgCandleQuoteVolume, thresholds);
        if (result.Passed)
            return true;

        _metrics.RecordLiquidityRejection(result.Reason);
        TradeLog.Rejected(symbol, "liquidity", $"[{result.Reason}] {result.Detail}");
        return false;
    }

    private void OnWebSocketError(Exception ex)
    {
        _logger.LogError(ex, "Ошибка WebSocket");
    }

    private OHLCV? GetCurrentCandle(string symbol)
    {
        lock (_candleLock)
        {
            return _currentCandles.TryGetValue(symbol, out var candle) ? candle : null;
        }
    }

    private void SetStatus(BotStatus status)
    {
        _status = status;
        OnStatusChanged?.Invoke(status);
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
    }
}
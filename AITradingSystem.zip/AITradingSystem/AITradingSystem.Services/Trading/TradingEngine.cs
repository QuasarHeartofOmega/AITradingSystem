﻿using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Data.Binance;
using AITradingSystem.Data.Storage;
using AITradingSystem.Services.AI;
using AITradingSystem.Services.Analysis;
using AITradingSystem.Services.Monitoring;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Центральный движок торговли — координирует все компоненты (FR-1 — FR-8).
/// </summary>
public sealed class TradingEngine : IAsyncDisposable
{
    private readonly AppConfig _config;
    private readonly IBinanceWebSocketClient _wsClient;
    private readonly IBinanceRestClient _restClient;
    private readonly IAIModel _aiModel;
    private readonly MarketAnalyzer _marketAnalyzer;
    private readonly SentimentAnalyzer _sentimentAnalyzer;
    private readonly RiskManager _riskManager;
    private readonly PositionManager _positionManager;
    private readonly IOrderExecutor _orderExecutor;
    private readonly ITradeHistoryRepository _tradeHistory;
    private readonly MetricsCollector _metrics;
    private readonly ILogger<TradingEngine> _logger;

    private CancellationTokenSource? _cts;
    private Task? _mainLoop;
    private BotStatus _status = BotStatus.Stopped;

    private readonly Dictionary<string, OHLCV> _currentCandles = new();
    private readonly object _candleLock = new();

    private readonly Dictionary<string, OrderBook> _currentOrderBooks = new();
    private readonly object _orderBookLock = new();

    /// <summary>Когда последний раз спрашивали ИИ об уже открытой позиции (закрыть/держать).</summary>
    private readonly Dictionary<string, DateTime> _lastPositionReview = new(StringComparer.OrdinalIgnoreCase);
    private readonly object _reviewLock = new();

    public BotStatus Status => _status;
    public event Action<BotStatus>? OnStatusChanged;
    public event Action<TradingSignal>? OnSignalGenerated;
    public event Action<Position>? OnPositionOpened;
    public event Action<TradeRecord>? OnPositionClosed;

    public TradingEngine(
        AppConfig config,
        IBinanceWebSocketClient wsClient,
        IBinanceRestClient restClient,
        IAIModel aiModel,
        MarketAnalyzer marketAnalyzer,
        SentimentAnalyzer sentimentAnalyzer,
        RiskManager riskManager,
        PositionManager positionManager,
        IOrderExecutor orderExecutor,
        ITradeHistoryRepository tradeHistory,
        MetricsCollector metrics,
        ILogger<TradingEngine> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _wsClient = wsClient ?? throw new ArgumentNullException(nameof(wsClient));
        _restClient = restClient ?? throw new ArgumentNullException(nameof(restClient));
        _aiModel = aiModel ?? throw new ArgumentNullException(nameof(aiModel));
        _marketAnalyzer = marketAnalyzer ?? throw new ArgumentNullException(nameof(marketAnalyzer));
        _sentimentAnalyzer = sentimentAnalyzer ?? throw new ArgumentNullException(nameof(sentimentAnalyzer));
        _riskManager = riskManager ?? throw new ArgumentNullException(nameof(riskManager));
        _positionManager = positionManager ?? throw new ArgumentNullException(nameof(positionManager));
        _orderExecutor = orderExecutor ?? throw new ArgumentNullException(nameof(orderExecutor));
        _tradeHistory = tradeHistory ?? throw new ArgumentNullException(nameof(tradeHistory));
        _metrics = metrics ?? throw new ArgumentNullException(nameof(metrics));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Запустить торговый движок.
    /// </summary>
    public async Task StartAsync(CancellationToken ct = default)
    {
        if (_status is BotStatus.Running or BotStatus.Starting or BotStatus.Stopping or BotStatus.Paused)
        {
            _logger.LogWarning("Движок уже запущен или в переходном состоянии: {Status}", _status);
            return;
        }

        SetStatus(BotStatus.Starting);
        _logger.LogInformation("Запуск торгового движка");

        try
        {
            // Загрузка модели
            await _aiModel.LoadAsync(ct);

            // Восстановление позиций
            await _positionManager.LoadPositionsAsync(ct);
            foreach (var restored in _positionManager.GetOpenPositions())
            {
                OnPositionOpened?.Invoke(restored); // показываем восстановленные позиции в UI
            }

            // Получение начального баланса
            if (_config.Trading.PaperTradingMode)
            {
                _logger.LogInformation("Режим Paper Trading: используем виртуальный начальный баланс {Balance} USDT",
                    _config.Trading.PaperTradingInitialBalance);
                _riskManager.UpdateBalance(_config.Trading.PaperTradingInitialBalance);
            }
            else
            {
                // В реальном режиме запрашиваем баланс с биржи
                _logger.LogInformation("Режим Live: запрос баланса с Binance...");
                var balance = await _restClient.GetAccountBalanceAsync(ct);
                _riskManager.UpdateBalance(balance.AvailableUSDT);
            }

            // Прогрев индикаторов историческими свечами с REST.
            // Без этого боту потребовались бы сутки+ ожидания закрытых свечей с WebSocket.
            foreach (var symbol in _config.Trading.Symbols)
            {
                try
                {
                    var history = await _restClient.GetKlinesAsync(
                        symbol, _config.Trading.CandleInterval, _config.Trading.HistoryCandlesCount, ct);

                    var calc = _marketAnalyzer.GetOrCreateCalculator(symbol);
                    var closed = history.Where(k => k.IsClosed).ToList();
                    foreach (var candle in closed)
                    {
                        calc.Update(candle);
                    }

                    if (history.Count > 0)
                    {
                        lock (_candleLock)
                        {
                            _currentCandles[symbol] = history[^1];
                        }
                    }

                    _logger.LogInformation("История для {Symbol}: {Count} закрытых свечей, индикаторы прогреты: {Ready}",
                        symbol, closed.Count, calc.AllReady);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Не удалось загрузить историю для {Symbol} — индикаторы будут прогреваться через WebSocket", symbol);
                }
            }

            // Подписка на события ДО подключения, чтобы не потерять первые сообщения
            _wsClient.OnKline += OnKlineReceived;
            _wsClient.OnOrderBook += OnOrderBookReceived;
            _wsClient.OnError += OnWebSocketError;

            // Подключение к WebSocket
            await _wsClient.ConnectAsync(
                _config.Trading.Symbols,
                _config.Trading.CandleInterval,
                ct);

            // Запуск основного цикла
            _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            _mainLoop = Task.Run(() => MainLoopAsync(_cts.Token), _cts.Token);

            SetStatus(BotStatus.Running);
            _logger.LogInformation("Торговый движок запущен");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка запуска движка");

            // Откатываем частично выполненный запуск: иначе остаются подписки на WS,
            // живой receive-loop и загруженная модель, а повторный "Старт" плодит дубли.
            await CleanupAfterFailedStartAsync();

            SetStatus(BotStatus.Error);
            throw;
        }
    }

    private async Task CleanupAfterFailedStartAsync()
    {
        _wsClient.OnKline -= OnKlineReceived;
        _wsClient.OnOrderBook -= OnOrderBookReceived;
        _wsClient.OnError -= OnWebSocketError;

        try
        {
            _cts?.Cancel();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Не удалось отменить токен основного цикла");
        }

        if (_mainLoop != null)
        {
            try
            {
                await _mainLoop;
            }
            catch (OperationCanceledException)
            {
                // Ожидаемо
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Основной цикл завершился с ошибкой при откате запуска");
            }
        }

        try
        {
            await _wsClient.DisconnectAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось отключить WebSocket при откате запуска");
        }

        try
        {
            await _aiModel.UnloadAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось выгрузить модель при откате запуска");
        }

        _cts?.Dispose();
        _cts = null;
        _mainLoop = null;
    }

    /// <summary>
    /// Остановить торговый движок.
    /// </summary>
    public async Task StopAsync()
    {
        if (_status == BotStatus.Stopped)
            return;

        SetStatus(BotStatus.Stopping);
        _logger.LogInformation("Остановка торгового движка");

        try
        {
            _cts?.Cancel();
        }
        catch (ObjectDisposedException)
        {
            // Токен уже освобождён предыдущей остановкой
        }

        if (_mainLoop != null)
        {
            try
            {
                await _mainLoop;
            }
            catch (OperationCanceledException)
            {
                // Ожидаемое поведение
            }
        }

        _wsClient.OnKline -= OnKlineReceived;
        _wsClient.OnOrderBook -= OnOrderBookReceived;
        _wsClient.OnError -= OnWebSocketError;

        try
        {
            await _wsClient.DisconnectAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка отключения WebSocket при остановке");
        }

        try
        {
            await _aiModel.UnloadAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Ошибка выгрузки модели при остановке");
        }

        try
        {
            await _positionManager.SavePositionsAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Не удалось сохранить позиции при остановке");
        }

        _cts?.Dispose();
        _cts = null;
        _mainLoop = null;

        SetStatus(BotStatus.Stopped);
        _logger.LogInformation("Торговый движок остановлен");
    }

    /// <summary>
    /// Приостановить торговлю.
    /// </summary>
    public void Pause()
    {
        if (_status != BotStatus.Running)
            return;

        SetStatus(BotStatus.Paused);
        _logger.LogInformation("Торговля приостановлена");
    }

    /// <summary>
    /// Возобновить торговлю.
    /// </summary>
    public void Resume()
    {
        if (_status != BotStatus.Paused)
            return;

        SetStatus(BotStatus.Running);
        _logger.LogInformation("Торговля возобновлена");
    }

    private async Task MainLoopAsync(CancellationToken ct)
    {
        _logger.LogInformation("Основной цикл запущен");

        while (!ct.IsCancellationRequested)
        {
            try
            {
                if (_status == BotStatus.Running)
                {
                    await ProcessSymbolsAsync(ct);
                }

                await Task.Delay(TimeSpan.FromSeconds(_config.Trading.AnalysisIntervalSeconds), ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка в основном цикле");
                await Task.Delay(TimeSpan.FromSeconds(10), ct);
            }
        }

        _logger.LogInformation("Основной цикл завершен");
    }

    private async Task ProcessSymbolsAsync(CancellationToken ct)
    {
        foreach (var symbol in _config.Trading.Symbols)
        {
            if (ct.IsCancellationRequested)
                break;

            await ProcessSymbolAsync(symbol, ct);
        }
    }

    private async Task ProcessSymbolAsync(string symbol, CancellationToken ct)
    {
        // 1. Если позиция уже открыта — сопровождаем её (SL/TP/trailing) и спрашиваем ИИ о выходе.
        var existingPosition = _positionManager.GetPositionBySymbol(symbol);
        if (existingPosition != null)
        {
            await MonitorPositionAsync(existingPosition, ct);

            // MonitorPositionAsync мог закрыть позицию по SL/TP — тогда пересматривать нечего.
            if (_positionManager.GetPositionBySymbol(symbol) != null)
                await ReviewOpenPositionAsync(symbol, ct);

            return;
        }

        // 2. Лимит одновременно открытых позиций.
        var openCount = _positionManager.GetOpenPositions().Count;
        if (openCount >= _config.Trading.MaxOpenPositions)
        {
            TradeLog.Rejected(symbol, "portfolio",
                $"достигнут лимит открытых позиций {openCount}/{_config.Trading.MaxOpenPositions}");
            return;
        }

        // 3. Индикаторы.
        var currentCandle = GetCurrentCandle(symbol);
        if (currentCandle == null)
            return;

        var indicators = _marketAnalyzer.GetIndicatorSnapshot(symbol, currentCandle);
        if (indicators == null)
            return;

        var newsContext = await _sentimentAnalyzer.GetNewsContextAsync(symbol, ct);

        // 4. Сигнал ИИ. Контекст обязателен: без него модель предлагает шорт на споте
        //    и не знает, что позиция уже открыта.
        var requestContext = BuildAiContext(position: null);
        var signal = await _aiModel.GetTradingSignalAsync(symbol, indicators, newsContext, requestContext, ct);
        _metrics.RecordSignal(signal);
        _metrics.RecordInferenceTime(_aiModel.LastInferenceTimeMs);
        OnSignalGenerated?.Invoke(signal);

        if (signal.Action is SignalAction.Hold or SignalAction.Close)
        {
            TradeLog.Decision(symbol, signal.Action.ToString(),
                signal.Action == SignalAction.Close
                    ? "ИИ просит закрыть, но открытой позиции нет"
                    : $"conf={signal.Confidence:P0}: {signal.Reasoning}");
            return;
        }

        if (signal.Action == SignalAction.Sell && !_config.Trading.AllowShort)
        {
            TradeLog.Rejected(symbol, "spot",
                "SELL без открытой позиции = шорт, на споте Binance невозможен (Trading:AllowShort=false)");
            return;
        }

        // 5. Валидация риск-менеджером (просадка, дневной лимит, R/R, корректность цен).
        var balance = _riskManager.DrawdownTracker.CurrentBalance;
        if (!_riskManager.ValidateSignal(signal, balance, out var reason))
        {
            TradeLog.Rejected(symbol, "risk", reason);
            return;
        }

        if (!signal.EntryPrice.HasValue || signal.EntryPrice.Value <= 0 ||
            !signal.StopLoss.HasValue || !signal.TakeProfit.HasValue)
        {
            TradeLog.Rejected(symbol, "signal", "в сигнале нет корректных entry/SL/TP");
            return;
        }

        // 6. Размер позиции.
        var atr = indicators.TryGetValue("atr_pct", out var atrPct)
            ? atrPct * currentCandle.Close
            : currentCandle.Close * 0.02m; // Fallback: 2% от цены

        var side = signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell;
        var preliminaryStopLoss = _riskManager.CalculateStopLoss(side, signal.EntryPrice.Value, atr);

        var quantity = _riskManager.CalculatePositionSize(
            balance,
            signal.EntryPrice.Value,
            preliminaryStopLoss,
            atr);

        if (quantity <= 0)
        {
            TradeLog.Rejected(symbol, "sizing", "рассчитанный объём <= 0");
            return;
        }

        var currentOrderBook = GetCurrentOrderBook(symbol);

        // 7. Исполнение. Ордер возвращается только после реального исполнения.
        var order = await _orderExecutor.ExecuteSignalAsync(signal, quantity, currentOrderBook, ct);
        if (order == null)
            return;

        // 8. Позиция открывается на ФАКТИЧЕСКИ исполненный объём и цену.
        var executedQuantity = order.ExecutedQuantity > 0 ? order.ExecutedQuantity : quantity;
        var actualEntry = order.AverageFillPrice ?? order.Price;
        if (actualEntry <= 0)
            actualEntry = signal.EntryPrice.Value;

        var stopLoss = _riskManager.CalculateStopLoss(side, actualEntry, atr);

        var takeProfit = signal.TakeProfit.Value;
        var reward = Math.Abs(takeProfit - actualEntry);
        var risk = Math.Abs(actualEntry - stopLoss);
        var tpDirectionOk = side == OrderSide.Buy ? takeProfit > actualEntry : takeProfit < actualEntry;
        if (!tpDirectionOk || risk <= 0 || reward / risk < (decimal)_config.Trading.MinRiskRewardRatio)
        {
            takeProfit = _riskManager.CalculateTakeProfit(side, actualEntry, stopLoss);
        }

        var position = new Position
        {
            Symbol = symbol,
            Side = side,
            Quantity = executedQuantity,
            EntryPrice = actualEntry,
            CurrentPrice = currentCandle.Close,
            StopLoss = stopLoss,
            TakeProfit = takeProfit,
            InitialStopLoss = stopLoss,
            OpenedAt = DateTime.UtcNow,
            OpeningOrderId = order.Id,
            SignalId = signal.Timestamp.ToString("yyyyMMddHHmmss")
        };

        await _positionManager.AddPositionAsync(position, ct);
        OnPositionOpened?.Invoke(position);

        TradeLog.Opened(symbol, side.ToString(), executedQuantity, actualEntry, stopLoss, takeProfit,
            _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName, order.Id);

        // Комиссия входа уменьшает свободный баланс уже сейчас (paper-режим).
        if (_config.Trading.PaperTradingMode && order.Commission > 0)
        {
            _riskManager.UpdateBalance(_riskManager.DrawdownTracker.CurrentBalance - order.Commission);
            LogBalance();
        }

        lock (_reviewLock)
        {
            _lastPositionReview[symbol] = DateTime.UtcNow;
        }

        _logger.LogInformation(
            "Открыта позиция: {Symbol} {Side} {Quantity} @ {Entry}, SL: {SL}, TP: {TP}",
            symbol, position.Side, executedQuantity, actualEntry, stopLoss, takeProfit);
    }

    /// <summary>
    /// Контекст для модели: открытая позиция, спот-ограничения, минимальные R/R и уверенность.
    /// </summary>
    private AiRequestContext BuildAiContext(Position? position) => new()
    {
        HasPosition = position != null,
        PositionSide = position == null ? null : (position.Side == OrderSide.Buy ? "LONG" : "SHORT"),
        EntryPrice = position?.EntryPrice,
        Quantity = position?.Quantity,
        UnrealizedPnlPercent = position?.UnrealizedPnLPercent,
        StopLoss = position?.StopLoss,
        TakeProfit = position?.TakeProfit,
        MinutesInPosition = position == null
            ? null
            : (DateTime.UtcNow - position.OpenedAt).TotalMinutes,
        AllowShort = _config.Trading.AllowShort,
        MinRiskReward = (decimal)_config.Trading.MinRiskRewardRatio,
        MinConfidence = _config.AI.MinConfidence,
        StopLossAtrMultiplier = (decimal)_config.Trading.StopLossAtrMultiplier
    };

    /// <summary>
    /// Периодический вопрос модели об открытой позиции: держать или закрыть.
    /// Без этого шага ИИ умел только открывать сделки, а выход был лишь по SL/TP.
    /// </summary>
    private async Task ReviewOpenPositionAsync(string symbol, CancellationToken ct)
    {
        if (!_config.Trading.AiCanClosePositions)
            return;

        lock (_reviewLock)
        {
            if (_lastPositionReview.TryGetValue(symbol, out var last) &&
                DateTime.UtcNow - last < TimeSpan.FromSeconds(_config.Trading.PositionReviewIntervalSeconds))
                return;

            _lastPositionReview[symbol] = DateTime.UtcNow;
        }

        var position = _positionManager.GetPositionBySymbol(symbol);
        if (position == null)
            return;

        var candle = GetCurrentCandle(symbol);
        if (candle == null)
            return;

        var indicators = _marketAnalyzer.GetIndicatorSnapshot(symbol, candle);
        if (indicators == null)
            return;

        var newsContext = await _sentimentAnalyzer.GetNewsContextAsync(symbol, ct);
        var signal = await _aiModel.GetTradingSignalAsync(
            symbol, indicators, newsContext, BuildAiContext(position), ct);

        _metrics.RecordSignal(signal);
        _metrics.RecordInferenceTime(_aiModel.LastInferenceTimeMs);
        OnSignalGenerated?.Invoke(signal);

        // CLOSE — явный выход. BUY/SELL — выход, если действие противоположно стороне позиции.
        var opposite = position.Side == OrderSide.Buy
            ? signal.Action == SignalAction.Sell
            : signal.Action == SignalAction.Buy;

        if (signal.Action != SignalAction.Close && !opposite)
        {
            TradeLog.Decision(symbol, "HOLD",
                $"позиция открыта, ИИ держит (conf={signal.Confidence:P0}): {signal.Reasoning}");
            return;
        }

        if (signal.Confidence < _config.AI.MinConfidence)
        {
            TradeLog.Decision(symbol, "HOLD",
                $"ИИ предлагал выход, но уверенность {signal.Confidence:P0} < {_config.AI.MinConfidence:P0}");
            return;
        }

        TradeLog.Decision(symbol, "CLOSE",
            $"решение ИИ (conf={signal.Confidence:P0}): {signal.Reasoning}");

        await ClosePositionAsync(position, $"AI-{signal.Action}", ct);
    }

    private async Task MonitorPositionAsync(Position position, CancellationToken ct)
    {
        var currentCandle = GetCurrentCandle(position.Symbol);
        if (currentCandle == null)
            return;

        position.UpdatePrice(currentCandle.Close);

        // Проверка SL/TP
        var (slHit, tpHit) = _positionManager.CheckStopLossTakeProfit(
            position.Id, currentCandle.Low, currentCandle.High);

        if (slHit)
        {
            await ClosePositionAsync(position, "Stop-Loss", ct, position.StopLoss);
            return;
        }

        if (tpHit)
        {
            await ClosePositionAsync(position, "Take-Profit", ct, position.TakeProfit);
            return;
        }

        // Trailing Stop
        if (_config.Trading.EnableTrailingStop)
        {
            var indicators = _marketAnalyzer.GetIndicatorSnapshot(position.Symbol, currentCandle);
            if (indicators != null)
            {
                var atr = indicators.TryGetValue("atr_pct", out var atrPct)
                    ? atrPct * currentCandle.Close
                    : currentCandle.Close * 0.02m;

                var newStopLoss = _riskManager.CalculateTrailingStop(position.Side, currentCandle.Close, atr);

                if (_positionManager.UpdateTrailingStop(position.Id, newStopLoss))
                {
                    _logger.LogInformation(
                        "Trailing Stop обновлен для {Symbol}: {NewSL}",
                        position.Symbol, newStopLoss);

                    // Персистим: иначе после перезапуска подтянутый стоп потеряется (NFR-2.2).
                    await _positionManager.SavePositionsAsync(ct);
                }
            }
        }
    }

    /// <summary>
    /// Ручное закрытие позиции из UI — проходит через тот же пайплайн,
    /// что и автоматическое (ордер, история, баланс, события).
    /// </summary>
    public Task ClosePositionManuallyAsync(Position position, CancellationToken ct = default)
    {
        return ClosePositionAsync(position, "Manual", ct);
    }

    private async Task ClosePositionAsync(Position position, string reason, CancellationToken ct, decimal? exitPriceOverride = null)
    {
        _logger.LogInformation("Закрытие позиции {Symbol} по причине: {Reason}", position.Symbol, reason);

        // Фиксируем цену выхода: для SL/TP — уровень срабатывания, для ручного — текущая
        if (exitPriceOverride.HasValue && exitPriceOverride.Value > 0)
        {
            position.UpdatePrice(exitPriceOverride.Value);
        }

        var order = await _orderExecutor.ClosePositionAsync(position, ct);
        if (order == null)
        {
            TradeLog.Rejected(position.Symbol, "close", "ордер на закрытие не исполнен — позиция остаётся открытой");
            _logger.LogError("Не удалось закрыть позицию {Symbol}", position.Symbol);
            return;
        }

        // Для live используем фактическую цену исполнения, если она есть
        var fillPrice = order.AverageFillPrice;
        if (fillPrice.HasValue && fillPrice.Value > 0)
        {
            position.UpdatePrice(fillPrice.Value);
        }

        // Закрываем ровно тот объём, который реально продан/куплен биржей.
        var closedQuantity = order.ExecutedQuantity > 0 ? order.ExecutedQuantity : position.Quantity;

        // Создание записи о сделке
        var trade = new TradeRecord
        {
            Symbol = position.Symbol,
            Side = position.Side,
            Quantity = closedQuantity,
            EntryPrice = position.EntryPrice,
            ExitPrice = position.CurrentPrice,
            PnL = position.UnrealizedPnL,
            PnLPercent = position.UnrealizedPnLPercent,
            Commission = order.Commission,
            ExitReason = reason,
            OpenedAt = position.OpenedAt,
            ClosedAt = DateTime.UtcNow,
            SignalId = position.SignalId
        };

        await _tradeHistory.SaveTradeAsync(trade, ct);
        await _positionManager.RemovePositionAsync(position.Id, ct);

        lock (_reviewLock)
        {
            _lastPositionReview.Remove(position.Symbol);
        }

        var mode = _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName;
        TradeLog.Closed(position.Symbol, reason, closedQuantity, position.EntryPrice, position.CurrentPrice,
            trade.PnL, trade.PnLPercent, order.Commission, mode);

        // Обновление баланса
        if (_config.Trading.PaperTradingMode)
        {
            // В paper-режиме баланс виртуальный: прибавляем реализованный PnL
            _riskManager.UpdateBalance(_riskManager.DrawdownTracker.CurrentBalance + trade.PnL - order.Commission);
        }
        else
        {
            var balance = await _restClient.GetAccountBalanceAsync(ct);
            _riskManager.UpdateBalance(balance.AvailableUSDT);
        }

        LogBalance();
        OnPositionClosed?.Invoke(trade);

        _logger.LogInformation(
            "Позиция закрыта: {Symbol} PnL: {PnL:F2} ({PnLPct:F2}%), Reason: {Reason}",
            position.Symbol, trade.PnL, trade.PnLPercent, reason);
    }

    /// <summary>Пишет срез баланса/просадки в logs/trades-*.log.</summary>
    private void LogBalance()
    {
        var tracker = _riskManager.DrawdownTracker;
        var equity = tracker.CurrentBalance + _positionManager.GetOpenPositions().Sum(p => p.UnrealizedPnL);

        TradeLog.Balance(
            _config.Trading.PaperTradingMode ? "PAPER" : _restClient.EnvironmentName,
            tracker.CurrentBalance,
            equity,
            tracker.CurrentDrawdownPercent * 100m);
    }

    private void OnKlineReceived(OHLCV candle)
    {        // 1. Сохраняем текущую свечу в кэш
        lock (_candleLock)
        {
            _currentCandles[candle.Symbol] = candle;
        }

        // 2. ГАРАНТИРОВАННО создаем калькулятор индикаторов при первом получении данных
        _marketAnalyzer.GetOrCreateCalculator(candle.Symbol);

        // 3. Если свеча закрыта, обновляем индикаторы (добавляем в историю)
        if (candle.IsClosed)
        {
            _marketAnalyzer.UpdateIndicators(candle.Symbol, candle);
        }

        // 4. Обновляем текущую цену для расчета PnL открытых позиций
        _positionManager.UpdatePrices(candle.Symbol, candle.Close);
    }

    private void OnOrderBookReceived(OrderBook orderBook)
    {
        // Кэшируем актуальный стакан для каждого символа
        lock (_orderBookLock)
        {
            _currentOrderBooks[orderBook.Symbol] = orderBook;
        }

        // Логирование аномально широкого спреда (защита от манипуляций или низкой ликвидности)
        if (orderBook.Spread.HasValue && orderBook.MidPrice.HasValue)
        {
            var spreadPercent = (orderBook.Spread.Value / orderBook.MidPrice.Value) * 100m;
            if (spreadPercent > 0.5m) // Спред более 0.5%
            {
                _logger.LogWarning(
                    "Аномально широкий спред на {Symbol}: {SpreadPercent:F3}% (Bid: {Bid}, Ask: {Ask})",
                    orderBook.Symbol, spreadPercent, orderBook.BestBid, orderBook.BestAsk);
            }
        }
    }

    private OrderBook? GetCurrentOrderBook(string symbol)
    {
        lock (_orderBookLock)
        {
            return _currentOrderBooks.TryGetValue(symbol, out var ob) ? ob : null;
        }
    }

    private void OnWebSocketError(Exception ex)
    {
        _logger.LogError(ex, "Ошибка WebSocket");
    }

    private OHLCV? GetCurrentCandle(string symbol)
    {
        lock (_candleLock)
        {
            return _currentCandles.TryGetValue(symbol, out var candle) ? candle : null;
        }
    }

    private void SetStatus(BotStatus status)
    {
        _status = status;
        OnStatusChanged?.Invoke(status);
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
    }
}
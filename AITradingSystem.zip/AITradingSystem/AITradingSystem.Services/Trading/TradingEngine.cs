﻿using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.MarketData;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Core.RiskManagement;
using AITradingSystem.Data.Binance;
using AITradingSystem.Data.Storage;
using AITradingSystem.Services.AI;
using AITradingSystem.Services.Analysis;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Центральный движок торговли — координирует все компоненты (FR-1 — FR-8).
/// </summary>
public sealed class TradingEngine : IAsyncDisposable
{
    private readonly AppConfig _config;
    private readonly IBinanceWebSocketClient _wsClient;
    private readonly IBinanceRestClient _restClient;
    private readonly IAIModel _aiModel;
    private readonly MarketAnalyzer _marketAnalyzer;
    private readonly SentimentAnalyzer _sentimentAnalyzer;
    private readonly RiskManager _riskManager;
    private readonly PositionManager _positionManager;
    private readonly IOrderExecutor _orderExecutor;
    private readonly ITradeHistoryRepository _tradeHistory;
    private readonly ILogger<TradingEngine> _logger;

    private CancellationTokenSource? _cts;
    private Task? _mainLoop;
    private BotStatus _status = BotStatus.Stopped;

    private readonly Dictionary<string, OHLCV> _currentCandles = new();
    private readonly object _candleLock = new();

    private readonly Dictionary<string, OrderBook> _currentOrderBooks = new();
    private readonly object _orderBookLock = new();

    public BotStatus Status => _status;
    public event Action<BotStatus>? OnStatusChanged;
    public event Action<TradingSignal>? OnSignalGenerated;
    public event Action<Position>? OnPositionOpened;
    public event Action<TradeRecord>? OnPositionClosed;

    public TradingEngine(
        AppConfig config,
        IBinanceWebSocketClient wsClient,
        IBinanceRestClient restClient,
        IAIModel aiModel,
        MarketAnalyzer marketAnalyzer,
        SentimentAnalyzer sentimentAnalyzer,
        RiskManager riskManager,
        PositionManager positionManager,
        IOrderExecutor orderExecutor,
        ITradeHistoryRepository tradeHistory,
        ILogger<TradingEngine> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _wsClient = wsClient ?? throw new ArgumentNullException(nameof(wsClient));
        _restClient = restClient ?? throw new ArgumentNullException(nameof(restClient));
        _aiModel = aiModel ?? throw new ArgumentNullException(nameof(aiModel));
        _marketAnalyzer = marketAnalyzer ?? throw new ArgumentNullException(nameof(marketAnalyzer));
        _sentimentAnalyzer = sentimentAnalyzer ?? throw new ArgumentNullException(nameof(sentimentAnalyzer));
        _riskManager = riskManager ?? throw new ArgumentNullException(nameof(riskManager));
        _positionManager = positionManager ?? throw new ArgumentNullException(nameof(positionManager));
        _orderExecutor = orderExecutor ?? throw new ArgumentNullException(nameof(orderExecutor));
        _tradeHistory = tradeHistory ?? throw new ArgumentNullException(nameof(tradeHistory));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Запустить торговый движок.
    /// </summary>
    public async Task StartAsync(CancellationToken ct = default)
    {
        if (_status == BotStatus.Running)
        {
            _logger.LogWarning("Движок уже запущен");
            return;
        }

        SetStatus(BotStatus.Starting);
        _logger.LogInformation("Запуск торгового движка");

        try
        {
            // Загрузка модели
            await _aiModel.LoadAsync(ct);

            // Восстановление позиций
            await _positionManager.LoadPositionsAsync(ct);

            // Получение начального баланса
            // Получение начального баланса
            if (_config.Trading.PaperTradingMode)
            {
                _logger.LogInformation("Режим Paper Trading: используем виртуальный начальный баланс {Balance} USDT",
                    _config.Trading.PaperTradingInitialBalance);
                _riskManager.UpdateBalance(_config.Trading.PaperTradingInitialBalance);
            }
            else
            {
                // В реальном режиме запрашиваем баланс с биржи
                _logger.LogInformation("Режим Live: запрос баланса с Binance...");
                var balance = await _restClient.GetAccountBalanceAsync(ct);
                _riskManager.UpdateBalance(balance.AvailableUSDT);
            }

            // Подключение к WebSocket
            await _wsClient.ConnectAsync(
                _config.Trading.Symbols,
                _config.Trading.CandleInterval,
                ct);

            // Подписка на события
            _wsClient.OnKline += OnKlineReceived;
            _wsClient.OnOrderBook += OnOrderBookReceived;
            _wsClient.OnError += OnWebSocketError;

            // Запуск основного цикла
            _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            _mainLoop = Task.Run(() => MainLoopAsync(_cts.Token), _cts.Token);

            SetStatus(BotStatus.Running);
            _logger.LogInformation("Торговый движок запущен");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка запуска движка");
            SetStatus(BotStatus.Error);
            throw;
        }
    }

    /// <summary>
    /// Остановить торговый движок.
    /// </summary>
    public async Task StopAsync()
    {
        if (_status == BotStatus.Stopped)
            return;

        SetStatus(BotStatus.Stopping);
        _logger.LogInformation("Остановка торгового движка");

        _cts?.Cancel();

        if (_mainLoop != null)
        {
            try
            {
                await _mainLoop;
            }
            catch (OperationCanceledException)
            {
                // Ожидаемое поведение
            }
        }

        _wsClient.OnKline -= OnKlineReceived;
        _wsClient.OnOrderBook -= OnOrderBookReceived;
        _wsClient.OnError -= OnWebSocketError;

        await _wsClient.DisconnectAsync();
        await _aiModel.UnloadAsync();

        SetStatus(BotStatus.Stopped);
        _logger.LogInformation("Торговый движок остановлен");
    }

    /// <summary>
    /// Приостановить торговлю.
    /// </summary>
    public void Pause()
    {
        if (_status != BotStatus.Running)
            return;

        SetStatus(BotStatus.Paused);
        _logger.LogInformation("Торговля приостановлена");
    }

    /// <summary>
    /// Возобновить торговлю.
    /// </summary>
    public void Resume()
    {
        if (_status != BotStatus.Paused)
            return;

        SetStatus(BotStatus.Running);
        _logger.LogInformation("Торговля возобновлена");
    }

    private async Task MainLoopAsync(CancellationToken ct)
    {
        _logger.LogInformation("Основной цикл запущен");

        while (!ct.IsCancellationRequested)
        {
            try
            {
                if (_status == BotStatus.Running)
                {
                    await ProcessSymbolsAsync(ct);
                }

                await Task.Delay(TimeSpan.FromSeconds(5), ct); // Интервал анализа
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка в основном цикле");
                await Task.Delay(TimeSpan.FromSeconds(10), ct);
            }
        }

        _logger.LogInformation("Основной цикл завершен");
    }

    private async Task ProcessSymbolsAsync(CancellationToken ct)
    {
        foreach (var symbol in _config.Trading.Symbols)
        {
            if (ct.IsCancellationRequested)
                break;

            await ProcessSymbolAsync(symbol, ct);
        }
    }

    private async Task ProcessSymbolAsync(string symbol, CancellationToken ct)
    {
        // Проверка: есть ли уже открытая позиция
        var existingPosition = _positionManager.GetPositionBySymbol(symbol);
        if (existingPosition != null)
        {
            // Мониторинг существующей позиции (SL/TP/Trailing)
            await MonitorPositionAsync(existingPosition, ct);
            return;
        }

        // Получение индикаторов
        var currentCandle = GetCurrentCandle(symbol);
        if (currentCandle == null)
            return;

        var indicators = _marketAnalyzer.GetIndicatorSnapshot(symbol, currentCandle);
        if (indicators == null)
            return;

        // Получение новостного контекста
        var newsContext = await _sentimentAnalyzer.GetNewsContextAsync(symbol, ct);

        // Запрос сигнала у AI
        var signal = await _aiModel.GetTradingSignalAsync(symbol, indicators, newsContext, ct);
        OnSignalGenerated?.Invoke(signal);

        // Валидация сигнала
        var balance = _riskManager.DrawdownTracker.CurrentBalance;
        if (!_riskManager.ValidateSignal(signal, balance, out var reason))
        {
            _logger.LogDebug("Сигнал для {Symbol} отклонен: {Reason}", symbol, reason);
            return;
        }

        // Расчет размера позиции
        var atr = indicators.TryGetValue("atr_pct", out var atrPct)
            ? atrPct * currentCandle.Close
            : currentCandle.Close * 0.02m; // Fallback: 2% от цены

        var stopLoss = _riskManager.CalculateStopLoss(
            signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell,
            signal.EntryPrice!.Value,
            atr);

        var quantity = _riskManager.CalculatePositionSize(
            balance,
            signal.EntryPrice.Value,
            stopLoss,
            atr);

        if (quantity <= 0)
        {
            _logger.LogWarning("Рассчитанная quantity <= 0 для {Symbol}", symbol);
            return;
        }

        var currentOrderBook = GetCurrentOrderBook(symbol);

        // Исполнение сигнала
        var order = await _orderExecutor.ExecuteSignalAsync(signal, quantity, currentOrderBook, ct);
        if (order == null)
            return;

        // Создание позиции
        var position = new Position
        {
            Symbol = symbol,
            Side = signal.Action == SignalAction.Buy ? OrderSide.Buy : OrderSide.Sell,
            Quantity = quantity,
            EntryPrice = signal.EntryPrice.Value,
            CurrentPrice = currentCandle.Close,
            StopLoss = stopLoss,
            TakeProfit = signal.TakeProfit!.Value,
            InitialStopLoss = stopLoss,
            OpenedAt = DateTime.UtcNow,
            OpeningOrderId = order.Id,
            SignalId = signal.Timestamp.ToString("yyyyMMddHHmmss")
        };

        await _positionManager.AddPositionAsync(position, ct);
        OnPositionOpened?.Invoke(position);

        _logger.LogInformation(
            "Открыта позиция: {Symbol} {Side} {Quantity} @ {Entry}, SL: {SL}, TP: {TP}",
            symbol, position.Side, quantity, position.EntryPrice, stopLoss, position.TakeProfit);
    }

    private async Task MonitorPositionAsync(Position position, CancellationToken ct)
    {
        var currentCandle = GetCurrentCandle(position.Symbol);
        if (currentCandle == null)
            return;

        position.UpdatePrice(currentCandle.Close);

        // Проверка SL/TP
        var (slHit, tpHit) = _positionManager.CheckStopLossTakeProfit(
            position.Id, currentCandle.Low, currentCandle.High);

        if (slHit)
        {
            await ClosePositionAsync(position, "Stop-Loss", ct);
            return;
        }

        if (tpHit)
        {
            await ClosePositionAsync(position, "Take-Profit", ct);
            return;
        }

        // Trailing Stop
        if (_config.Trading.EnableTrailingStop)
        {
            var indicators = _marketAnalyzer.GetIndicatorSnapshot(position.Symbol, currentCandle);
            if (indicators != null)
            {
                var atr = indicators.TryGetValue("atr_pct", out var atrPct)
                    ? atrPct * currentCandle.Close
                    : currentCandle.Close * 0.02m;

                var newStopLoss = _riskManager.CalculateTrailingStop(position.Side, currentCandle.Close, atr);

                if (_positionManager.UpdateTrailingStop(position.Id, newStopLoss))
                {
                    _logger.LogInformation(
                        "Trailing Stop обновлен для {Symbol}: {NewSL}",
                        position.Symbol, newStopLoss);
                }
            }
        }
    }

    private async Task ClosePositionAsync(Position position, string reason, CancellationToken ct)
    {
        _logger.LogInformation("Закрытие позиции {Symbol} по причине: {Reason}", position.Symbol, reason);

        var order = await _orderExecutor.ClosePositionAsync(position, ct);
        if (order == null)
        {
            _logger.LogError("Не удалось закрыть позицию {Symbol}", position.Symbol);
            return;
        }

        // Создание записи о сделке
        var trade = new TradeRecord
        {
            Symbol = position.Symbol,
            Side = position.Side,
            Quantity = position.Quantity,
            EntryPrice = position.EntryPrice,
            ExitPrice = position.CurrentPrice,
            PnL = position.UnrealizedPnL,
            PnLPercent = position.UnrealizedPnLPercent,
            ExitReason = reason,
            OpenedAt = position.OpenedAt,
            ClosedAt = DateTime.UtcNow,
            SignalId = position.SignalId
        };

        await _tradeHistory.SaveTradeAsync(trade, ct);
        await _positionManager.RemovePositionAsync(position.Id, ct);

        // Обновление баланса
        var balance = await _restClient.GetAccountBalanceAsync(ct);
        _riskManager.UpdateBalance(balance.AvailableUSDT);

        OnPositionClosed?.Invoke(trade);

        _logger.LogInformation(
            "Позиция закрыта: {Symbol} PnL: {PnL:F2} ({PnLPct:P2}), Reason: {Reason}",
            position.Symbol, trade.PnL, trade.PnLPercent, reason);
    }

    private void OnKlineReceived(OHLCV candle)
    {
        // 1. Сохраняем текущую свечу в кэш
        lock (_candleLock)
        {
            _currentCandles[candle.Symbol] = candle;
        }

        // 2. ГАРАНТИРОВАННО создаем калькулятор индикаторов при первом получении данных
        _marketAnalyzer.GetOrCreateCalculator(candle.Symbol);

        // 3. Если свеча закрыта, обновляем индикаторы (добавляем в историю)
        if (candle.IsClosed)
        {
            _marketAnalyzer.UpdateIndicators(candle.Symbol, candle);
        }

        // 4. Обновляем текущую цену для расчета PnL открытых позиций
        _positionManager.UpdatePrices(candle.Symbol, candle.Close);
    }

    private void OnOrderBookReceived(OrderBook orderBook)
    {
        // Кэшируем актуальный стакан для каждого символа
        lock (_orderBookLock)
        {
            _currentOrderBooks[orderBook.Symbol] = orderBook;
        }

        // Логирование аномально широкого спреда (защита от манипуляций или низкой ликвидности)
        if (orderBook.Spread.HasValue && orderBook.MidPrice.HasValue)
        {
            var spreadPercent = (orderBook.Spread.Value / orderBook.MidPrice.Value) * 100m;
            if (spreadPercent > 0.5m) // Спред более 0.5%
            {
                _logger.LogWarning(
                    "Аномально широкий спред на {Symbol}: {SpreadPercent:F3}% (Bid: {Bid}, Ask: {Ask})",
                    orderBook.Symbol, spreadPercent, orderBook.BestBid, orderBook.BestAsk);
            }
        }
    }

    private OrderBook? GetCurrentOrderBook(string symbol)
    {
        lock (_orderBookLock)
        {
            return _currentOrderBooks.TryGetValue(symbol, out var ob) ? ob : null;
        }
    }

    private void OnWebSocketError(Exception ex)
    {
        _logger.LogError(ex, "Ошибка WebSocket");
    }

    private OHLCV? GetCurrentCandle(string symbol)
    {
        lock (_candleLock)
        {
            return _currentCandles.TryGetValue(symbol, out var candle) ? candle : null;
        }
    }

    private void SetStatus(BotStatus status)
    {
        _status = status;
        OnStatusChanged?.Invoke(status);
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
    }
}
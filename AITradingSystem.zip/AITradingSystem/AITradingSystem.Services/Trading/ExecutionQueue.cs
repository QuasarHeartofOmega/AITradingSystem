using System.Collections.Concurrent;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Services.Monitoring;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// Приоритет операции исполнения. Меньше значение — раньше в очереди.
/// Защита и закрытие всегда обгоняют входы: капитал важнее новой сделки.
/// </summary>
public enum ExecutionPriority
{
    /// <summary>Постановка/снятие биржевой защиты (OCO).</summary>
    Protection = 0,

    /// <summary>Закрытие позиции, отмена ордера.</summary>
    Close = 1,

    /// <summary>Cancel/replace защитной связки при трейлинге.</summary>
    Trailing = 2,

    /// <summary>Открытие новой позиции.</summary>
    Entry = 3
}

/// <summary>
/// P0.3 (фундамент) — очередь исполнения с приоритетами и идемпотентностью.
///
/// Что даёт:
///  - защита/закрытие уходят на биржу раньше входов, даже если вход был запрошен первым;
///  - по одному символу не более одной операции в полёте (нет гонок «вход vs закрытие»);
///  - идемпотентность по <c>clientOrderId</c>: повторный запрос с тем же ключом не отправляет
///    второй ордер — либо присоединяется к уже идущему, либо получает сохранённый результат;
///  - ограничение параллелизма (<see cref="TradingConfig.ExecutionQueueMaxParallel"/>) —
///    задел под бюджет весов запросов (P1.6).
///
/// В очередь кладётся ТОЛЬКО сетевая операция (короткий REST), а не ожидание филла:
/// иначе 60-секундный опрос лимитного входа заблокировал бы закрытие другой позиции.
/// </summary>
public sealed class ExecutionQueue : IAsyncDisposable
{
    private readonly TradingConfig _config;
    private readonly MetricsCollector _metrics;
    private readonly ILogger<ExecutionQueue> _logger;

    private readonly object _lock = new();
    private readonly List<WorkItem> _pending = new();
    private readonly Dictionary<string, WorkItem> _inFlightByKey = new(StringComparer.Ordinal);
    private readonly Dictionary<string, CachedResult> _completed = new(StringComparer.Ordinal);
    private readonly HashSet<string> _busySymbols = new(StringComparer.OrdinalIgnoreCase);
    private readonly SemaphoreSlim _signal = new(0);
    private readonly ConcurrentDictionary<long, Task> _workers = new();

    private long _seq;
    private int _started;
    private int _running;
    private CancellationTokenSource? _cts;
    private Task? _dispatcher;

    /// <summary>Сколько операций ждут отправки прямо сейчас.</summary>
    public int PendingCount { get { lock (_lock) return _pending.Count; } }

    /// <summary>Сколько запросов склеено с уже идущей операцией по тому же ключу.</summary>
    public long CoalescedRequests { get; private set; }

    /// <summary>Сколько запросов получили сохранённый результат вместо повторной отправки.</summary>
    public long ReplayedResults { get; private set; }

    public ExecutionQueue(TradingConfig config, MetricsCollector metrics, ILogger<ExecutionQueue> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _metrics = metrics ?? throw new ArgumentNullException(nameof(metrics));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Поставить операцию в очередь. <paramref name="idempotencyKey"/> — clientOrderId ордера
    /// (или listClientOrderId связки): null означает операцию без дедупликации (чтение, cancel).
    /// </summary>
    public async Task<T> SubmitAsync<T>(
        string symbol,
        ExecutionPriority priority,
        string? idempotencyKey,
        Func<CancellationToken, Task<T>> work,
        CancellationToken ct = default)
    {
        if (work is null) throw new ArgumentNullException(nameof(work));
        ct.ThrowIfCancellationRequested();

        var result = await SubmitCoreAsync(
            symbol, priority, idempotencyKey,
            async token => (object?)await work(token).ConfigureAwait(false),
            ct).ConfigureAwait(false);

        return result is T typed ? typed : default!;
    }

    private Task<object?> SubmitCoreAsync(
        string symbol,
        ExecutionPriority priority,
        string? key,
        Func<CancellationToken, Task<object?>> work,
        CancellationToken ct)
    {
        EnsureStarted();
        PurgeExpired();

        WorkItem item;
        lock (_lock)
        {
            if (key != null)
            {
                // Уже отправлено и успешно завершено — второй ордер не шлём.
                if (_completed.TryGetValue(key, out var cached) && !cached.Failed)
                {
                    ReplayedResults++;
                    _logger.LogInformation(
                        "Идемпотентность: {Key} уже исполнен — повторная отправка пропущена ({Symbol})", key, symbol);
                    TradeLog.Decision(symbol, "IDEMPOTENT-REPLAY",
                        $"{key}: результат взят из кэша, ордер повторно не отправляется");
                    return Task.FromResult(cached.Result);
                }

                // Ещё в полёте — присоединяемся к тому же результату.
                if (_inFlightByKey.TryGetValue(key, out var running))
                {
                    CoalescedRequests++;
                    TradeLog.Decision(symbol, "IDEMPOTENT-JOIN", $"{key}: запрос склеен с уже идущей отправкой");
                    return running.Completion.Task;
                }
            }

            item = new WorkItem(
                symbol, priority, key, work,
                Interlocked.Increment(ref _seq),
                DateTime.UtcNow,
                new TaskCompletionSource<object?>(TaskCreationOptions.RunContinuationsAsynchronously))
            {
                CallerToken = ct
            };

            if (key != null)
                _inFlightByKey[key] = item;

            InsertByPriority(item);
        }

        // Отмена вызывающего (стоп движка) снимает ещё не отправленный ордер с очереди.
        if (ct.CanBeCanceled)
        {
            ct.Register(() =>
            {
                lock (_lock)
                {
                    if (_pending.Remove(item))
                        item.Completion.TrySetCanceled(ct);
                }
            });
        }

        _signal.Release();
        return item.Completion.Task;
    }

    /// <summary>Вставка с сохранением порядка (приоритет, затем FIFO внутри приоритета).</summary>
    private void InsertByPriority(WorkItem item)
    {
        var index = _pending.Count;
        while (index > 0 &&
               (_pending[index - 1].Priority > item.Priority ||
                (_pending[index - 1].Priority == item.Priority && _pending[index - 1].Seq > item.Seq)))
        {
            index--;
        }

        _pending.Insert(index, item);

        _metrics.RecordExecutionQueueDepth(_pending.Count);
    }

    private void EnsureStarted()
    {
        if (Interlocked.CompareExchange(ref _started, 1, 0) != 0)
            return;

        _cts = new CancellationTokenSource();
        _dispatcher = Task.Run(() => DispatchLoopAsync(_cts.Token));
        _logger.LogInformation(
            "Очередь исполнения запущена: параллелизм {Parallel}, TTL идемпотентности {Ttl} с",
            _config.ExecutionQueueMaxParallel, _config.ExecutionIdempotencyTtlSeconds);
    }

    private async Task DispatchLoopAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                await _signal.WaitAsync(ct).ConfigureAwait(false);
                Dispatch(ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка диспетчера очереди исполнения");
            }
        }

        CancelPending();
    }

    private void Dispatch(CancellationToken ct)
    {
        while (true)
        {
            WorkItem? next = null;
            lock (_lock)
            {
                if (_running >= Math.Max(1, _config.ExecutionQueueMaxParallel))
                    return;

                for (var i = 0; i < _pending.Count; i++)
                {
                    var candidate = _pending[i];
                    if (candidate.Completion.Task.IsCompleted)
                    {
                        _pending.RemoveAt(i--);
                        continue;
                    }

                    // По символу — строго одна операция в полёте.
                    if (_busySymbols.Contains(candidate.Symbol))
                        continue;

                    _pending.RemoveAt(i);
                    _busySymbols.Add(candidate.Symbol);
                    _running++;
                    next = candidate;
                    break;
                }
            }

            if (next is null)
                return;

            var item = next;
            var task = Task.Run(() => RunAsync(item, ct), CancellationToken.None);
            var id = item.Seq;
            _workers[id] = task;
            _ = task.ContinueWith(
                _ => _workers.TryRemove(id, out _),
                CancellationToken.None,
                TaskContinuationOptions.ExecuteSynchronously,
                TaskScheduler.Default);
        }
    }

    private async Task RunAsync(WorkItem item, CancellationToken queueToken)
    {
        var waitMs = (DateTime.UtcNow - item.EnqueuedAtUtc).TotalMilliseconds;
        _metrics.RecordExecutionWait(waitMs);

        if (waitMs > _config.ExecutionQueueWarnWaitMs)
        {
            _logger.LogWarning(
                "Очередь исполнения: {Symbol} {Priority} ждал {Wait:F0} мс (порог {Threshold} мс)",
                item.Symbol, item.Priority, waitMs, _config.ExecutionQueueWarnWaitMs);
            TradeLog.Decision(item.Symbol, "QUEUE-WAIT",
                $"{item.Priority} ждал {waitMs:F0} мс при пороге {_config.ExecutionQueueWarnWaitMs} мс");
        }

        using var linked = CancellationTokenSource.CreateLinkedTokenSource(queueToken, item.CallerToken);
        object? result = null;
        Exception? error = null;

        try
        {
            result = await item.Work(linked.Token).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            error = ex;
        }
        finally
        {
            lock (_lock)
            {
                _busySymbols.Remove(item.Symbol);
                _running--;

                if (item.Key != null)
                {
                    _inFlightByKey.Remove(item.Key);

                    // Кэшируем только успех: отказ можно повторить тем же clientOrderId.
                    if (error is null)
                        _completed[item.Key] = new CachedResult(result, DateTime.UtcNow, Failed: false);
                }
            }

            _signal.Release(); // освободившийся слот/символ — повод пересмотреть очередь
        }

        if (error is not null)
            item.Completion.TrySetException(error);
        else
            item.Completion.TrySetResult(result);
    }

    private void PurgeExpired()
    {
        var ttl = TimeSpan.FromSeconds(_config.ExecutionIdempotencyTtlSeconds);
        var now = DateTime.UtcNow;

        lock (_lock)
        {
            if (_completed.Count == 0)
                return;

            var expired = _completed.Where(kv => now - kv.Value.CompletedAtUtc > ttl).Select(kv => kv.Key).ToList();
            foreach (var key in expired)
                _completed.Remove(key);
        }
    }

    private void CancelPending()
    {
        lock (_lock)
        {
            foreach (var item in _pending)
                item.Completion.TrySetCanceled();

            _pending.Clear();
        }
    }

    public async Task StopAsync()
    {
        if (Interlocked.Exchange(ref _started, 0) == 0)
            return;

        _cts?.Cancel();

        if (_dispatcher != null)
        {
            try { await _dispatcher.ConfigureAwait(false); }
            catch (OperationCanceledException) { /* ожидаемо */ }
        }

        var pending = _workers.Values.ToArray();
        if (pending.Length > 0)
        {
            try { await Task.WhenAll(pending).ConfigureAwait(false); }
            catch (OperationCanceledException) { /* ожидаемо */ }
            catch (Exception ex) { _logger.LogWarning(ex, "Ошибка завершения операций очереди исполнения"); }
        }

        _workers.Clear();
        CancelPending();
        _cts?.Dispose();
        _cts = null;
        _dispatcher = null;
    }

    public async ValueTask DisposeAsync() => await StopAsync().ConfigureAwait(false);

    private sealed record CachedResult(object? Result, DateTime CompletedAtUtc, bool Failed);

    private sealed class WorkItem
    {
        public WorkItem(
            string symbol,
            ExecutionPriority priority,
            string? key,
            Func<CancellationToken, Task<object?>> work,
            long seq,
            DateTime enqueuedAtUtc,
            TaskCompletionSource<object?> completion)
        {
            Symbol = symbol;
            Priority = priority;
            Key = key;
            Work = work;
            Seq = seq;
            EnqueuedAtUtc = enqueuedAtUtc;
            Completion = completion;
        }

        public string Symbol { get; }
        public ExecutionPriority Priority { get; }
        public string? Key { get; }
        public Func<CancellationToken, Task<object?>> Work { get; }
        public long Seq { get; }
        public DateTime EnqueuedAtUtc { get; }
        public TaskCompletionSource<object?> Completion { get; }
        public CancellationToken CallerToken { get; set; }
    }
}

using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.Models.Trading;
using AITradingSystem.Data.Binance;
using AITradingSystem.Services.Monitoring;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace AITradingSystem.Services.Trading;

/// <summary>
/// P0.5 (фундамент): реконсиляция с биржей + user-data stream.
/// Что уже делает:
///  - стартовая инвентаризация: открытые ордера/OCO-связки биржи против positions.json;
///    сироты и пропавшая защита фиксируются в отчёте, логе и метриках (ничего не закрывает);
///  - listenKey: создание, keepalive, закрытие; приём executionReport в реальном времени;
///  - филлы защитных ног помечаются PROTECTION-FILLED и складываются в очередь фактов.
/// Чего ещё НЕ делает (остаток P0.5): применение филлов к позициям/балансу, подхват
/// сиротских позиций, пересоздание просроченного listenKey, учёт частичных филлов из stream.
/// </summary>
public sealed class ReconciliationService : IAsyncDisposable
{
    private readonly TradingConfig _config;
    private readonly IBinanceRestClient _rest;
    private readonly IBinanceWebSocketClient _ws;
    private readonly PositionManager _positions;
    private readonly MetricsCollector _metrics;
    private readonly ILogger<ReconciliationService> _logger;

    private CancellationTokenSource? _cts;
    private Task? _keepAliveLoop;
    private string? _listenKey;

    /// <summary>Факты филлов защитных ног, ещё не применённые к позициям (очередь для полного P0.5).</summary>
    private readonly ConcurrentQueue<ExecutionReport> _protectionFills = new();
    public IReadOnlyCollection<ExecutionReport> PendingProtectionFills => _protectionFills;

    public ReconciliationReport? LastReport { get; private set; }
    public bool IsRunning => _cts is { IsCancellationRequested: false };

    /// <summary>Префиксы детерминированных clientOrderId бота (P0.3/P0.1): mkt/ent/cls/oco/sl/tp + '-' + hex.</summary>
    private static readonly string[] BotClientIdPrefixes = { "mkt-", "ent-", "cls-", "oco-", "sl-", "tp-" };

    public sealed record ReconciliationReport(
        DateTime AtUtc,
        int PositionsChecked,
        int OrphanOcoLists,
        int OrphanOrders,
        int ExternalOrders,
        int ProtectionMissing,
        IReadOnlyList<string> Findings)
    {
        public int TotalIssues => OrphanOcoLists + OrphanOrders + ProtectionMissing;
    }

    public ReconciliationService(
        TradingConfig config,
        IBinanceRestClient rest,
        IBinanceWebSocketClient ws,
        PositionManager positions,
        MetricsCollector metrics,
        ILogger<ReconciliationService> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _rest = rest ?? throw new ArgumentNullException(nameof(rest));
        _ws = ws ?? throw new ArgumentNullException(nameof(ws));
        _positions = positions ?? throw new ArgumentNullException(nameof(positions));
        _metrics = metrics ?? throw new ArgumentNullException(nameof(metrics));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Запуск контура: listenKey + user-data socket + keepalive + стартовая реконсиляция.
    /// В paper-режиме и без API-ключей контур не нужен — тихий пропуск.
    /// </summary>
    public async Task StartAsync(CancellationToken ct = default)
    {
        if (IsRunning) return;

        if (_config.PaperTradingMode || !_rest.HasApiKeys || !_config.UserDataStreamEnabled)
        {
            _logger.LogInformation(
                "Реконсиляция/user-data stream пропущены: paper={Paper}, ключи={Keys}, включено={Enabled}",
                _config.PaperTradingMode, _rest.HasApiKeys, _config.UserDataStreamEnabled);
            return;
        }

        _cts = CancellationTokenSource.CreateLinkedTokenSource(ct);

        try
        {
            _listenKey = await _rest.CreateListenKeyAsync(_cts.Token);
            _ws.OnExecutionReport += OnExecutionReport;
            await _ws.ConnectUserDataStreamAsync(_listenKey, _cts.Token);
            _keepAliveLoop = Task.Run(() => KeepAliveLoopAsync(_cts.Token), _cts.Token);
            _logger.LogInformation("USER-DATA-START: listenKey получен, keepalive каждые {Minutes} мин",
                _config.UserDataKeepAliveMinutes);
        }
        catch (Exception ex)
        {
            // Fail-open для фундамента: без user-data stream торговля продолжается на polling,
            // но оператор видит явное предупреждение.
            _logger.LogWarning(ex, "USER-DATA-FAIL: user-data stream не поднят — остаётся polling (остаток P0.5)");
            await StopAsync();
        }

        // Стартовая инвентаризация полезна и без user-data socket.
        await ReconcileAsync(ct);
    }

    /// <summary>
    /// Инвентаризация: что на бирже против того, что знает бот. Только детект и отчёт —
    /// авто-подхват/авто-закрытие сирот — остаток P0.5.
    /// </summary>
    public async Task<ReconciliationReport?> ReconcileAsync(CancellationToken ct = default)
    {
        if (_config.PaperTradingMode || !_rest.HasApiKeys) return null;

        try
        {
            var openOrders = await _rest.GetOpenOrdersAsync(ct: ct);
            var openLists = await _rest.GetOpenOrderListsAsync(ct: ct);
            var positions = _positions.GetOpenPositions();

            var report = Classify(positions, openOrders, openLists);
            LastReport = report;
            _metrics.RecordReconciliation(report.TotalIssues);

            foreach (var finding in report.Findings)
                _logger.LogWarning("RECON: {Finding}", finding);

            _logger.LogInformation(
                "RECON-SUMMARY: позиций {Positions}, сиротских OCO {OrphanOco}, сиротских ордеров {OrphanOrders}, " +
                "внешних ордеров {External}, позиций без защиты {Missing}",
                report.PositionsChecked, report.OrphanOcoLists, report.OrphanOrders,
                report.ExternalOrders, report.ProtectionMissing);

            return report;
        }
        catch (OperationCanceledException) { throw; }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "RECON-FAIL: стартовая реконсиляция не выполнена");
            return null;
        }
    }

    /// <summary>
    /// Чистая классификация (покрыта тестами): известные защиты — по id связки/ног из Position.Protection;
    /// ордера бота — по префиксам clientOrderId; всё прочее — внешние (не трогаем).
    /// </summary>
    public static ReconciliationReport Classify(
        IReadOnlyList<Position> positions,
        IReadOnlyList<Order> openOrders,
        IReadOnlyList<ProtectiveOrderList> openLists)
    {
        var findings = new List<string>();
        var knownListIds = new HashSet<long>();
        var knownOrderIds = new HashSet<long>();
        var knownClientIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var pos in positions)
        {
            if (pos.Protection is not { } prot || !prot.IsLive) continue;
            knownListIds.Add(prot.OrderListId);
            knownOrderIds.Add(prot.StopOrderId);
            knownOrderIds.Add(prot.TakeProfitOrderId);
            foreach (var id in prot.OrderIds) knownOrderIds.Add(id);
            if (prot.ListClientOrderId.Length > 0) knownClientIds.Add(prot.ListClientOrderId);
            if (prot.StopClientOrderId.Length > 0) knownClientIds.Add(prot.StopClientOrderId);
            if (prot.TakeProfitClientOrderId.Length > 0) knownClientIds.Add(prot.TakeProfitClientOrderId);
        }

        var openListIds = openLists.Select(l => l.OrderListId).ToHashSet();

        var orphanOco = 0;
        foreach (var list in openLists)
        {
            if (knownListIds.Contains(list.OrderListId)) continue;
            orphanOco++;
            findings.Add($"ORPHAN-OCO: связка {list.OrderListId} ({list.Symbol}) на бирже не принадлежит ни одной позиции бота");
        }

        var orphanOrders = 0;
        var externalOrders = 0;
        foreach (var order in openOrders)
        {
            if (knownOrderIds.Contains(order.BinanceOrderId) || knownClientIds.Contains(order.ClientOrderId))
                continue;

            if (BotClientIdPrefixes.Any(p => order.ClientOrderId.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
            {
                orphanOrders++;
                findings.Add($"ORPHAN-ORDER: ордер бота {order.ClientOrderId} ({order.Symbol}) открыт без позиции/защиты в снапшоте");
            }
            else
            {
                externalOrders++;
                findings.Add($"EXTERNAL-ORDER: ордер {order.ClientOrderId} ({order.Symbol}) поставлен не ботом — не трогаем");
            }
        }

        var protectionMissing = 0;
        foreach (var pos in positions)
        {
            if (pos.Protection is not { } prot || !prot.IsLive) continue;
            if (openListIds.Contains(prot.OrderListId)) continue;
            protectionMissing++;
            findings.Add($"PROTECTION-MISSING: у позиции {pos.Symbol} ({pos.Id}) связка {prot.OrderListId} исчезла с биржи — " +
                         "возможно, стоп/тейк сработал пока процесс был мёртв (применение филла — остаток P0.5)");
        }

        return new ReconciliationReport(DateTime.UtcNow, positions.Count,
            orphanOco, orphanOrders, externalOrders, protectionMissing, findings);
    }

    private void OnExecutionReport(ExecutionReport report)
    {
        _metrics.RecordExecutionReport();
        _logger.LogInformation(
            "EXEC-REPORT: {Symbol} {Side} {Execution}/{Status} last={LastQty}@{LastPrice} cum={CumQty} id={ClientId}",
            report.Symbol, report.Side, report.ExecutionType, report.OrderStatus,
            report.LastQuantity, report.LastPrice, report.CumulativeQuantity, report.ClientOrderId);

        if (!report.IsFill) return;

        // Филл ноги защиты = биржа закрыла (часть) позиции. Пока только фиксируем факт:
        // применение к Position/балансу — полный P0.5.
        var match = _positions.GetOpenPositions().FirstOrDefault(p =>
            p.Protection is { } prot &&
            (string.Equals(prot.StopClientOrderId, report.ClientOrderId, StringComparison.OrdinalIgnoreCase) ||
             string.Equals(prot.TakeProfitClientOrderId, report.ClientOrderId, StringComparison.OrdinalIgnoreCase)));

        if (match != null)
        {
            _protectionFills.Enqueue(report);
            _logger.LogWarning(
                "PROTECTION-FILLED: {Symbol} нога {ClientId} исполнилась на бирже ({Qty}@{Price}) — " +
                "позиция требует реконсиляции (остаток P0.5)",
                match.Symbol, report.ClientOrderId, report.LastQuantity, report.LastPrice);
        }
    }

    private async Task KeepAliveLoopAsync(CancellationToken ct)
    {
        try
        {
            using var timer = new PeriodicTimer(TimeSpan.FromMinutes(_config.UserDataKeepAliveMinutes));
            while (await timer.WaitForNextTickAsync(ct))
            {
                if (_listenKey is null) continue;
                try
                {
                    await _rest.KeepAliveListenKeyAsync(_listenKey, ct);
                    _logger.LogDebug("listenKey продлён");
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "USER-DATA-KEEPALIVE-FAIL: не удалось продлить listenKey");
                }
            }
        }
        catch (OperationCanceledException) { /* остановка */ }
    }

    public async Task StopAsync()
    {
        _cts?.Cancel();

        if (_keepAliveLoop != null)
        {
            try { await _keepAliveLoop; }
            catch (OperationCanceledException) { /* ожидаемо */ }
            _keepAliveLoop = null;
        }

        _ws.OnExecutionReport -= OnExecutionReport;

        try { await _ws.DisconnectUserDataStreamAsync(); }
        catch (Exception ex) { _logger.LogWarning(ex, "Ошибка отключения user-data stream"); }

        if (_listenKey != null)
        {
            try { await _rest.CloseListenKeyAsync(_listenKey); }
            catch (Exception ex) { _logger.LogDebug(ex, "Не удалось закрыть listenKey (истечёт сам)"); }
            _listenKey = null;
        }

        _cts?.Dispose();
        _cts = null;
    }

    public async ValueTask DisposeAsync() => await StopAsync();
}

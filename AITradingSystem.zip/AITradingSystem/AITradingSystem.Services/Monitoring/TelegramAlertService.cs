﻿using Telegram.Bot;
using Telegram.Bot.Types.Enums;
using AITradingSystem.Common.Configuration;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Monitoring;

/// <summary>
/// Сервис отправки алертов в Telegram (FR-8.2).
/// </summary>
public sealed class TelegramAlertService
{
    private readonly TelegramConfig _config;
    private readonly TelegramBotClient? _botClient;
    private readonly ILogger<TelegramAlertService> _logger;

    public TelegramAlertService(
        TelegramConfig config,
        ILogger<TelegramAlertService> logger)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));

        if (_config.Enabled && !string.IsNullOrWhiteSpace(_config.BotToken))
        {
            _botClient = new TelegramBotClient(_config.BotToken);
        }
    }

    /// <summary>
    /// Отправить алерт.
    /// </summary>
    public async Task SendAlertAsync(string message, string level = "Info", CancellationToken ct = default)
    {
        if (!_config.Enabled || _botClient == null)
            return;

        var minLevel = Enum.Parse<LogLevel>(_config.MinAlertLevel, true);
        var currentLevel = Enum.Parse<LogLevel>(level, true);

        if (currentLevel < minLevel)
            return;

        try
        {
            var emoji = level.ToLower() switch
            {
                "info" => "ℹ️",
                "warning" => "⚠️",
                "error" => "❌",
                "critical" => "🚨",
                _ => "📊"
            };

            var fullMessage = $"{emoji} [{level.ToUpper()}]\n{message}";

            await _botClient.SendTextMessageAsync(
                chatId: _config.ChatId,
                text: fullMessage,
                parseMode: ParseMode.Html,
                cancellationToken: ct);

            _logger.LogDebug("Telegram алерт отправлен: {Level}", level);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка отправки Telegram алерта");
        }
    }
}
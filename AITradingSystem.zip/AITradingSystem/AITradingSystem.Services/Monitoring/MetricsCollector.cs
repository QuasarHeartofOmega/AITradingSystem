﻿using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Services.Monitoring;

/// <summary>
/// Сборщик метрик производительности (FR-8.3).
/// </summary>
public sealed class MetricsCollector
{
    private readonly Queue<double> _inferenceTimes = new();
    private readonly Queue<double> _positionCheckLatencies = new();
    private readonly Queue<double> _executionWaits = new();
    private int _totalSignals;
    private int _totalTrades;
    private decimal _totalPnL;
    private readonly object _lock = new();

    public int TotalSignals => _totalSignals;
    public int TotalTrades => _totalTrades;
    public decimal TotalPnL => _totalPnL;
    public double AverageInferenceTimeMs { get; private set; }

    /// <summary>P0.2: сколько проверок сопровождения позиций выполнил тик-контур.</summary>
    public long PositionChecks { get; private set; }

    /// <summary>Средняя и худшая задержка «тик → проверка позиции», мс.</summary>
    public double AveragePositionCheckLatencyMs { get; private set; }
    public double MaxPositionCheckLatencyMs { get; private set; }

    /// <summary>P0.3: ожидание операции в очереди исполнения (среднее/худшее), мс.</summary>
    public double AverageExecutionWaitMs { get; private set; }
    public double MaxExecutionWaitMs { get; private set; }

    /// <summary>Максимальная глубина очереди исполнения за сессию.</summary>
    public int ExecutionQueueMaxDepth { get; private set; }

    /// <summary>Текущая глубина очереди исполнения (для дашборда).</summary>
    public int ExecutionQueueDepth { get; private set; }

    /// <summary>P0.3: сколько операций очередь повторила из-за транзиентных сбоев.</summary>
    public long ExecutionRetries { get; private set; }

    /// <summary>
    /// Зафиксировать время инференса.
    /// </summary>
    public void RecordInferenceTime(double timeMs)
    {
        // Под тем же локом, что и остальные метрики: иначе гонка
        // "очередь опустела между Dequeue и Average" роняла цикл анализа.
        lock (_lock)
        {
            _inferenceTimes.Enqueue(timeMs);

            // Храним только последние 100 значений
            while (_inferenceTimes.Count > 100)
            {
                _inferenceTimes.Dequeue();
            }

            AverageInferenceTimeMs = _inferenceTimes.Count > 0 ? _inferenceTimes.Average() : 0d;
        }
    }

    /// <summary>
    /// P0.2: зафиксировать задержку сопровождения позиции (тик пришёл → проверка началась).
    /// Критерий независимого контура: ≤1–2 с, иначе позиция снова защищена только «на бумаге».
    /// </summary>
    public void RecordPositionCheck(double latencyMs)
    {
        lock (_lock)
        {
            PositionChecks++;
            _positionCheckLatencies.Enqueue(latencyMs);

            while (_positionCheckLatencies.Count > 200)
                _positionCheckLatencies.Dequeue();

            AveragePositionCheckLatencyMs = _positionCheckLatencies.Average();
            if (latencyMs > MaxPositionCheckLatencyMs)
                MaxPositionCheckLatencyMs = latencyMs;
        }
    }

    /// <summary>
    /// P0.3: зафиксировать ожидание операции в очереди исполнения.
    /// Закрытие/защита не должны стоять за входами — рост этой метрики означает регресс.
    /// </summary>
    public void RecordExecutionWait(double waitMs)
    {
        lock (_lock)
        {
            _executionWaits.Enqueue(waitMs);
            while (_executionWaits.Count > 200)
                _executionWaits.Dequeue();

            AverageExecutionWaitMs = _executionWaits.Average();
            if (waitMs > MaxExecutionWaitMs)
                MaxExecutionWaitMs = waitMs;
        }
    }

    /// <summary>Зафиксировать текущую глубину очереди исполнения.</summary>
    public void RecordExecutionQueueDepth(int depth)
    {
        lock (_lock)
        {
            ExecutionQueueDepth = depth;
            if (depth > ExecutionQueueMaxDepth)
                ExecutionQueueMaxDepth = depth;
        }
    }

    /// <summary>
    /// P0.3: зафиксировать повтор операции исполнения (backoff на транзиентном сбое).
    /// Рост метрики при неизменном числе сделок = деградация сети/биржи.
    /// </summary>
    public void RecordExecutionRetry()
    {
        lock (_lock)
        {
            ExecutionRetries++;
        }
    }

    /// <summary>P0.5: получено executionReport из user-data stream.</summary>
    public long ExecutionReportsReceived { get; private set; }

    /// <summary>P0.5: число проблем последней реконсиляции (сироты + пропавшая защита).</summary>
    public int ReconciliationIssues { get; private set; }

    /// <summary>P0.6: сколько раз взводился kill-switch (авто + ручной).</summary>
    public int KillSwitchActivations { get; private set; }

    public void RecordExecutionReport()
    {
        lock (_lock)
        {
            ExecutionReportsReceived++;
        }
    }

    public void RecordReconciliation(int issues)
    {
        lock (_lock)
        {
            ReconciliationIssues = issues;
        }
    }

    public void RecordKillSwitch()
    {
        lock (_lock)
        {
            KillSwitchActivations++;
        }
    }

    /// <summary>
    /// Зафиксировать сигнал.
    /// </summary>
    public void RecordSignal(TradingSignal signal)
    {
        Interlocked.Increment(ref _totalSignals);
    }

    /// <summary>
    /// Зафиксировать сделку.
    /// </summary>
    public void RecordTrade(TradeRecord trade)
    {
        lock (_lock)
        {
            _totalTrades++;
            _totalPnL += trade.PnL;
        }
    }

    /// <summary>
    /// Получить сводку метрик.
    /// </summary>
    public string GetSummary()
    {
        return $"Signals: {_totalSignals}, Trades: {_totalTrades}, " +
               $"PnL: {_totalPnL:F2} USDT, Avg Inference: {AverageInferenceTimeMs:F0} ms, " +
               $"Position checks: {PositionChecks} (avg {AveragePositionCheckLatencyMs:F0} ms, max {MaxPositionCheckLatencyMs:F0} ms), " +
               $"Exec queue wait: avg {AverageExecutionWaitMs:F0} ms / max {MaxExecutionWaitMs:F0} ms, " +
               $"depth {ExecutionQueueDepth}/{ExecutionQueueMaxDepth}, retries {ExecutionRetries}, " +
               $"exec reports {ExecutionReportsReceived}, recon issues {ReconciliationIssues}, kill-switch {KillSwitchActivations}";
    }
}
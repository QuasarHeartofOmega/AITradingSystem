﻿using System.Collections.Concurrent;
using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Services.Monitoring;

/// <summary>
/// Сборщик метрик производительности (FR-8.3).
/// </summary>
public sealed class MetricsCollector
{
    private readonly ConcurrentQueue<double> _inferenceTimes = new();
    private int _totalSignals;
    private int _totalTrades;
    private decimal _totalPnL;
    private readonly object _lock = new();

    public int TotalSignals => _totalSignals;
    public int TotalTrades => _totalTrades;
    public decimal TotalPnL => _totalPnL;
    public double AverageInferenceTimeMs { get; private set; }

    /// <summary>
    /// Зафиксировать время инференса.
    /// </summary>
    public void RecordInferenceTime(double timeMs)
    {
        _inferenceTimes.Enqueue(timeMs);

        // Храним только последние 100 значений
        while (_inferenceTimes.Count > 100)
        {
            _inferenceTimes.TryDequeue(out _);
        }

        AverageInferenceTimeMs = _inferenceTimes.Average();
    }

    /// <summary>
    /// Зафиксировать сигнал.
    /// </summary>
    public void RecordSignal(TradingSignal signal)
    {
        Interlocked.Increment(ref _totalSignals);
    }

    /// <summary>
    /// Зафиксировать сделку.
    /// </summary>
    public void RecordTrade(TradeRecord trade)
    {
        lock (_lock)
        {
            _totalTrades++;
            _totalPnL += trade.PnL;
        }
    }

    /// <summary>
    /// Получить сводку метрик.
    /// </summary>
    public string GetSummary()
    {
        return $"Signals: {_totalSignals}, Trades: {_totalTrades}, " +
               $"PnL: {_totalPnL:F2} USDT, Avg Inference: {AverageInferenceTimeMs:F0} ms";
    }
}
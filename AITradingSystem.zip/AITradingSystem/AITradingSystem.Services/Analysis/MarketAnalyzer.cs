﻿using AITradingSystem.Core.Indicators;
using AITradingSystem.Core.Models.MarketData;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Analysis;

/// <summary>
/// Анализатор рынка — агрегирует индикаторы и рыночные данные.
/// </summary>
public sealed class MarketAnalyzer
{
    private readonly ILogger<MarketAnalyzer> _logger;
    private readonly Dictionary<string, IndicatorCalculator> _calculators = new();

    public MarketAnalyzer(ILogger<MarketAnalyzer> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить или создать калькулятор индикаторов для символа.
    /// </summary>
    public IndicatorCalculator GetOrCreateCalculator(string symbol)
    {
        if (!_calculators.TryGetValue(symbol, out var calc))
        {
            calc = new IndicatorCalculator(symbol);
            _calculators[symbol] = calc;
            _logger.LogInformation("Создан калькулятор индикаторов для {Symbol}", symbol);
        }
        return calc;
    }

    /// <summary>
    /// Обновить индикаторы новой свечой.
    /// </summary>
    public void UpdateIndicators(string symbol, OHLCV candle)
    {
        var calc = GetOrCreateCalculator(symbol);
        calc.Update(candle);
    }

    /// <summary>
    /// Получить нормализованный снимок индикаторов для AI.
    /// </summary>
    /// <summary>
    /// Получить нормализованный снимок индикаторов для AI.
    /// </summary>
    public Dictionary<string, decimal>? GetIndicatorSnapshot(string symbol, OHLCV currentCandle)
    {
        // Гарантируем создание калькулятора, если его еще нет
        var calc = GetOrCreateCalculator(symbol);

        // Если индикаторы еще не "прогрелись" (нужно 200+ свечей), возвращаем null.
        // Бот просто пропустит этот цикл анализа и попробует снова через 5 секунд.
        if (!calc.AllReady)
        {
            return null;
        }

        var snapshot = calc.GetNormalizedSnapshot(currentCandle);
        return snapshot.ToDictionary();
    }
}
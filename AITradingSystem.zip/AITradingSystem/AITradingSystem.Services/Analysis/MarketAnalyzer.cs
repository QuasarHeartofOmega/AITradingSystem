﻿using System.Collections.Concurrent;
using AITradingSystem.Core.Indicators;
using AITradingSystem.Core.Models.MarketData;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Analysis;

/// <summary>
/// Анализатор рынка — агрегирует индикаторы и рыночные данные.
/// Потокобезопасен: калькуляторы создаются из WebSocket-потока и основного цикла.
/// </summary>
public sealed class MarketAnalyzer
{
    private readonly ILogger<MarketAnalyzer> _logger;
    private readonly ConcurrentDictionary<string, IndicatorCalculator> _calculators = new(StringComparer.OrdinalIgnoreCase);

    public MarketAnalyzer(ILogger<MarketAnalyzer> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить или создать калькулятор индикаторов для символа.
    /// </summary>
    public IndicatorCalculator GetOrCreateCalculator(string symbol)
    {
        return _calculators.GetOrAdd(symbol, s =>
        {
            _logger.LogInformation("Создан калькулятор индикаторов для {Symbol}", s);
            return new IndicatorCalculator(s);
        });
    }

    /// <summary>
    /// Обновить индикаторы новой свечой.
    /// </summary>
    public void UpdateIndicators(string symbol, OHLCV candle)
    {
        var calc = GetOrCreateCalculator(symbol);
        calc.Update(candle);
    }

    /// <summary>
    /// Статус прогрева индикаторов символа (B11): чтобы движок писал в лог
    /// «прогрев N/M свечей» вместо молчаливого return.
    /// </summary>
    public (bool Ready, int Candles, int Required) GetWarmupInfo(string symbol)
    {
        var calc = GetOrCreateCalculator(symbol);
        return (calc.AllReady, calc.ClosedCandles, calc.MaxWarmupPeriod);
    }

    /// <summary>
    /// Получить нормализованный снимок индикаторов для AI.
    /// </summary>
    public Dictionary<string, decimal>? GetIndicatorSnapshot(string symbol, OHLCV currentCandle)
    {
        // Гарантируем создание калькулятора, если его еще нет
        var calc = GetOrCreateCalculator(symbol);

        // Если индикаторы еще не "прогрелись" (нужно 200+ свечей), возвращаем null.
        // Бот просто пропустит этот цикл анализа и попробует снова через 5 секунд.
        if (!calc.AllReady)
        {
            return null;
        }

        var snapshot = calc.GetNormalizedSnapshot(currentCandle);
        return snapshot.ToDictionary();
    }
}
using System.Globalization;
using AITradingSystem.Common.Configuration;
using AITradingSystem.Common.Logging;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Services.Analysis;

/// <summary>Один вклад в детерминированную оценку сетапа (для лога и промпта).</summary>
public sealed class ScoreComponent
{
    public string Name { get; init; } = string.Empty;
    public decimal Weight { get; init; }
    public decimal Value { get; init; }
    public decimal Contribution { get; init; }

    public override string ToString() =>
        string.Format(CultureInfo.InvariantCulture,
            "{0}={1:0.##} (w={2:0.##}, вклад {3:0.###})", Name, Value, Weight, Contribution);
}

/// <summary>
/// Детерминированная оценка сетапа БЕЗ ИИ (B9): направление, prior-уверенность и причины.
/// Модель получает её как «Engine pre-score» и якорится на фактах, а не на выдуманном числе.
/// </summary>
public sealed class EngineScore
{
    /// <summary>Направление и сила сетапа в [-1; 1]: &gt;0 — long, &lt;0 — short/exit.</summary>
    public decimal Direction { get; init; }

    /// <summary>Prior-уверенность движка в [0.1; 0.9].</summary>
    public decimal PriorConfidence { get; init; }

    public IReadOnlyList<ScoreComponent> Components { get; init; } = Array.Empty<ScoreComponent>();
    public IReadOnlyList<string> Reasons { get; init; } = Array.Empty<string>();

    /// <summary>LONG / SHORT / FLAT — как в промпте.</summary>
    public string DirectionName => Direction > 0.05m ? "LONG" : Direction < -0.05m ? "SHORT" : "FLAT";

    public string Summary =>
        string.Format(CultureInfo.InvariantCulture,
            "direction={0}, score={1:0.##}, prior_confidence={2:0.##}", DirectionName, Direction, PriorConfidence);

    public string ReasonsText => Reasons.Count == 0 ? "нет выраженных факторов" : string.Join("; ", Reasons);
}

/// <summary>Параметры калибровки: пороги, спот-ограничения и цены для детерминированного входа.</summary>
public sealed class CalibrationContext
{
    public decimal MinConfidence { get; init; } = 0.55m;
    public bool HasPosition { get; init; }
    public bool AllowShort { get; init; }

    /// <summary>Текущая цена (для расчёта entry/SL/TP, если действие пересмотрено движком).</summary>
    public decimal Price { get; init; }

    /// <summary>ATR в абсолютных единицах цены.</summary>
    public decimal AtrAbsolute { get; init; }

    public decimal StopLossAtrMultiplier { get; init; } = 2m;
    public decimal MinRiskReward { get; init; } = 2m;

    /// <summary>Знаков после запятой для цен символа (tickSize, D24).</summary>
    public int PriceDecimals { get; init; } = 8;
}

/// <summary>
/// B9. Калибратор уверенности: математика — алгоритмам, ИИ — качественная оценка.
///
/// PreScore считает направление/силу сетапа из индикаторов (тренд, моментум, ADX, объём,
/// волатильность, положение в Bollinger). Calibrate сводит уверенность модели и prior движка
/// по политике AI:ConfidencePolicy и лечит «якорные» ответы модели (HOLD conf≈0.45).
/// SL/TP/сайзинг остаются за RiskManager; здесь цены считаются только если движок
/// сам меняет HOLD на вход (иначе сигнал был бы без цен и всё равно отклонился).
/// </summary>
public sealed class SignalCalibrator
{
    // Веса.direction-скоринга (сумма = 1.0).
    private const decimal WTrendAlign = 0.30m;
    private const decimal WSupertrend = 0.20m;
    private const decimal WEmaPosition = 0.15m;
    private const decimal WRsi = 0.15m;
    private const decimal WMacd = 0.10m;
    private const decimal WStoch = 0.05m;
    private const decimal WObv = 0.05m;

    /// <summary>
    /// Детерминированный pre-score по словарю индикаторов (нормализованные + сырые ключи B10).
    /// Работает и без сырых ключей — тогда берутся нормализованные аналоги.
    /// </summary>
    public EngineScore PreScore(Dictionary<string, decimal> indicators)
    {
        if (indicators == null)
            throw new ArgumentNullException(nameof(indicators));

        var components = new List<ScoreComponent>();
        var reasons = new List<string>();

        var emaAlign = Get(indicators, "ema_align");
        var supertrend = Get(indicators, "supertrend");
        var emaPos = (Get(indicators, "ema20_pos") + Get(indicators, "ema50_pos") + Get(indicators, "ema200_pos")) / 3m;

        var rsiRaw = indicators.TryGetValue("rsi_raw", out var rr) ? rr : Get(indicators, "rsi") * 50m + 50m;
        var rsiComponent = RsiScore(rsiRaw);

        var macd = Get(indicators, "macd_hist");
        var stochK = indicators.TryGetValue("stoch_k_raw", out var sk) ? sk / 100m : Get(indicators, "stoch_rsi_k");
        var stochD = indicators.TryGetValue("stoch_d_raw", out var sd) ? sd / 100m : Get(indicators, "stoch_rsi_d");
        var stoch = StochScore(stochK, stochD);
        var obv = Get(indicators, "obv_trend");

        Add(components, "ema_align", WTrendAlign, emaAlign);
        Add(components, "supertrend", WSupertrend, supertrend);
        Add(components, "ema_position", WEmaPosition, emaPos);
        Add(components, "rsi", WRsi, rsiComponent);
        Add(components, "macd_hist", WMacd, macd);
        Add(components, "stoch_rsi", WStoch, stoch);
        Add(components, "obv_trend", WObv, obv);

        var direction = components.Sum(c => c.Contribution);

        // --- Модификаторы (штрафы/бонусы к силе сетапа, не к направлению) ---
        var adxRaw = indicators.TryGetValue("adx_raw", out var ar) ? ar : Get(indicators, "adx") * 100m;
        var adxFactor = adxRaw >= 25m ? 1.0m : adxRaw >= 20m ? 0.85m : 0.6m;
        if (adxRaw < 20m)
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "слабый тренд: ADX {0:0.#} < 20 (штраф ×0.6)", adxRaw));
        else if (adxRaw >= 25m)
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "тренд подтверждён: ADX {0:0.#} >= 25", adxRaw));

        var volumeRatio = Get(indicators, "volume_ratio");
        var volumeFactor = volumeRatio <= 0m ? 1.0m
            : volumeRatio >= 1.5m ? 1.1m
            : volumeRatio >= 1.0m ? 1.0m
            : volumeRatio >= 0.6m ? 0.9m
            : 0.8m;
        if (volumeRatio > 0m && volumeRatio < 0.6m)
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "объём ниже среднего: volume_ratio {0:0.##} (штраф ×0.8)", volumeRatio));
        else if (volumeRatio >= 1.5m)
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "объём подтверждает движение: volume_ratio {0:0.##}", volumeRatio));

        var atrPct = Get(indicators, "atr_pct");
        var volatilityFactor = 1.0m;
        if (atrPct > 0m && atrPct < 0.001m)
        {
            volatilityFactor = 0.8m;
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "волатильность слишком низкая: ATR {0:0.###}% (штраф ×0.8)", atrPct * 100m));
        }
        else if (atrPct > 0.06m)
        {
            volatilityFactor = 0.75m;
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "волатильность экстремальная: ATR {0:0.##}% (штраф ×0.75)", atrPct * 100m));
        }

        var bbPos = Get(indicators, "bb_pos");
        var bbFactor = 1.0m;
        if (direction > 0m && bbPos > 0.85m)
        {
            bbFactor = 0.85m;
            reasons.Add("цена у верхней полосы Bollinger — вход в long перегрет (штраф ×0.85)");
        }
        else if (direction < 0m && bbPos < -0.85m)
        {
            bbFactor = 0.85m;
            reasons.Add("цена у нижней полосы Bollinger — выход/short перегрет (штраф ×0.85)");
        }

        var score = Math.Clamp(direction * adxFactor * volumeFactor * volatilityFactor * bbFactor, -1m, 1m);
        var prior = Math.Clamp(0.2m + 0.7m * Math.Abs(score), 0.1m, 0.9m);

        // --- Человекочитаемые причины (уходят в промпт и в лог) ---
        if (emaAlign > 0m) reasons.Add("EMA20>EMA50>EMA200 — бычье выравнивание");
        else if (emaAlign < 0m) reasons.Add("EMA20<EMA50<EMA200 — медвежье выравнивание");
        else reasons.Add("EMA перепутаны — тренд не определён");

        reasons.Add(supertrend > 0m ? "Supertrend вверх" : "Supertrend вниз");

        if (rsiRaw >= 70m)
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "RSI {0:0.#} — перекупленность", rsiRaw));
        else if (rsiRaw <= 30m)
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "RSI {0:0.#} — перепроданность", rsiRaw));
        else
            reasons.Add(string.Format(CultureInfo.InvariantCulture, "RSI {0:0.#} — рабочая зона", rsiRaw));

        if (macd > 0.1m) reasons.Add("MACD-гистограмма положительная");
        else if (macd < -0.1m) reasons.Add("MACD-гистограмма отрицательная");

        if (stochK > stochD && stochK < 0.8m) reasons.Add("StochRSI K выше D (бычий крест)");
        else if (stochK < stochD && stochK > 0.2m) reasons.Add("StochRSI K ниже D (медвежий крест)");

        if (obv > 0.1m) reasons.Add("OBV растёт — объём поддерживает тренд");
        else if (obv < -0.1m) reasons.Add("OBV падает — объём против тренда");

        return new EngineScore
        {
            Direction = score,
            PriorConfidence = prior,
            Components = components,
            Reasons = reasons
        };
    }

    /// <summary>
    /// Сводит уверенность модели и prior движка по политике; лечит дегенерат HOLD conf≈0.45.
    /// Действие пересматривается ТОЛЬКО при явном согласии фактов (prior >= порога, направление
    /// совпадает, позиции нет) — и тогда цены входа считает математика, а не модель.
    /// </summary>
    public TradingSignal Calibrate(
        TradingSignal signal,
        EngineScore score,
        ConfidencePolicy policy,
        CalibrationContext context)
    {
        if (signal == null) throw new ArgumentNullException(nameof(signal));
        if (score == null) throw new ArgumentNullException(nameof(score));
        if (context == null) throw new ArgumentNullException(nameof(context));

        var modelConf = signal.ModelConfidence > 0m ? signal.ModelConfidence : signal.Confidence;
        var prior = score.PriorConfidence;
        var degenerate = signal.IsDegenerateConfidence ||
                         (signal.Action == SignalAction.Hold && Math.Abs(modelConf - 0.45m) <= 0.02m);

        decimal final;
        string source;

        switch (policy)
        {
            case ConfidencePolicy.ModelOnly:
                final = modelConf;
                source = "ModelOnly";
                break;

            case ConfidencePolicy.EngineOverride:
                final = prior;
                source = "EngineOverride";
                break;

            default:
                if (degenerate)
                {
                    final = prior;
                    source = "Degenerate→Prior";
                }
                else
                {
                    final = 0.5m * modelConf + 0.5m * prior;
                    source = "Blend";
                }
                break;
        }

        final = Math.Clamp(final, 0m, 1m);

        signal.ModelConfidence = modelConf;
        signal.EngineConfidence = prior;
        signal.IsDegenerateConfidence = degenerate;
        signal.Confidence = final;
        signal.ConfidenceSource = source;

        // Пересмотр действия: только когда модель «заякорилась»/движок решает сам,
        // позиции нет и факты уверенно указывают направление.
        var mayReconsider = policy != ConfidencePolicy.ModelOnly &&
                            (degenerate || policy == ConfidencePolicy.EngineOverride) &&
                            signal.Action == SignalAction.Hold &&
                            !context.HasPosition &&
                            final >= context.MinConfidence;

        if (mayReconsider)
        {
            if (score.Direction > 0.05m)
                TryUpgrade(signal, SignalAction.Buy, score, context);
            else if (score.Direction < -0.05m && context.AllowShort)
                TryUpgrade(signal, SignalAction.Sell, score, context);
        }

        TradeLog.Decision(signal.Symbol, "CALIBRATE",
            string.Format(CultureInfo.InvariantCulture,
                "model_conf={0:0.##}, engine_prior={1:0.##}, final={2:0.##}, policy={3}, source={4}, action={5}, {6}",
                modelConf, prior, final, policy, source, signal.Action, score.Summary));

        return signal;
    }

    /// <summary>
    /// HOLD → вход по детерминированным ценам: entry = текущая цена,
    /// SL = entry − k·ATR, TP = entry + R/R·risk. Без цен сигнал был бы отклонён как невалидный.
    /// </summary>
    private static void TryUpgrade(TradingSignal signal, SignalAction action, EngineScore score, CalibrationContext ctx)
    {
        if (ctx.Price <= 0m)
            return;

        var atr = ctx.AtrAbsolute > 0m ? ctx.AtrAbsolute : ctx.Price * 0.01m;
        var risk = atr * Math.Max(0.1m, ctx.StopLossAtrMultiplier);
        var reward = risk * Math.Max(1m, ctx.MinRiskReward);
        var decimals = Math.Clamp(ctx.PriceDecimals, 0, 18);

        var entry = Math.Round(ctx.Price, decimals, MidpointRounding.AwayFromZero);
        decimal stop, target;

        if (action == SignalAction.Buy)
        {
            stop = Math.Round(entry - risk, decimals, MidpointRounding.AwayFromZero);
            target = Math.Round(entry + reward, decimals, MidpointRounding.AwayFromZero);
        }
        else
        {
            stop = Math.Round(entry + risk, decimals, MidpointRounding.AwayFromZero);
            target = Math.Round(entry - reward, decimals, MidpointRounding.AwayFromZero);
        }

        if (stop <= 0m || target <= 0m || entry <= 0m)
            return;

        signal.Action = action;
        signal.EntryPrice = entry;
        signal.StopLoss = stop;
        signal.TakeProfit = target;
        signal.Reasoning =
            $"Движок пересмотрел HOLD по фактам ({score.Summary}): {score.ReasonsText}. " +
            $"Цены рассчитаны алгоритмом: entry={entry}, SL={stop} ({ctx.StopLossAtrMultiplier}×ATR), TP={target}. " +
            (string.IsNullOrWhiteSpace(signal.Reasoning) ? string.Empty : "Модель: " + signal.Reasoning);

        TradeLog.Decision(signal.Symbol, "ENGINE-ENTRY",
            string.Format(CultureInfo.InvariantCulture,
                "HOLD → {0}: prior={1:0.##} >= порога {2:0.##}, entry={3}, sl={4}, tp={5}",
                action, score.PriorConfidence, ctx.MinConfidence, entry, stop, target));
    }

    private static decimal Get(Dictionary<string, decimal> dict, string key) =>
        dict.TryGetValue(key, out var value) ? value : 0m;

    private static void Add(List<ScoreComponent> list, string name, decimal weight, decimal value)
    {
        var v = Math.Clamp(value, -1m, 1m);
        list.Add(new ScoreComponent
        {
            Name = name,
            Weight = weight,
            Value = v,
            Contribution = v * weight
        });
    }

    /// <summary>RSI 0..100 → [-1; 1] с поправкой на перекупленность/перепроданность.</summary>
    private static decimal RsiScore(decimal rsi)
    {
        if (rsi <= 0m) return 0m;
        if (rsi >= 80m) return 0.2m;   // перекупленность — не повод покупать
        if (rsi <= 20m) return -0.2m;  // перепроданность в падающем тренде — не повод продавать
        return Math.Clamp((rsi - 50m) / 25m, -1m, 1m);
    }

    /// <summary>StochRSI K/D (0..1) → [-1; 1]: направление креста, крайние зоны гасим.</summary>
    private static decimal StochScore(decimal k, decimal d)
    {
        var cross = Math.Clamp((k - d) * 4m, -1m, 1m);
        if (k > 0.9m) return Math.Min(cross, 0.2m);
        if (k < 0.1m) return Math.Max(cross, -0.2m);
        return cross;
    }
}
﻿using System.Text;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.News;
using AITradingSystem.Data.News;
using Microsoft.Extensions.Logging;

namespace AITradingSystem.Services.Analysis;

/// <summary>
/// Анализатор новостей — формирует контекст для AI-модели (FR-2.3).
/// </summary>
public sealed class SentimentAnalyzer
{
    private readonly NewsAggregator _newsAggregator;
    private readonly ILogger<SentimentAnalyzer> _logger;

    public SentimentAnalyzer(
        NewsAggregator newsAggregator,
        ILogger<SentimentAnalyzer> logger)
    {
        _newsAggregator = newsAggregator ?? throw new ArgumentNullException(nameof(newsAggregator));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    /// <summary>
    /// Получить новостной контекст для символа.
    /// </summary>
    public async Task<string?> GetNewsContextAsync(string symbol, CancellationToken ct = default)
    {
        try
        {
            var news = await _newsAggregator.GetNewsForSymbolAsync(symbol, ct);

            if (news.Count == 0)
                return null;

            var sb = new StringBuilder();

            foreach (var item in news.Take(5))
            {
                var sentimentEmoji = item.Sentiment switch
                {
                    Sentiment.Bullish => "🟢",
                    Sentiment.Bearish => "🔴",
                    _ => "⚪"
                };

                sb.AppendLine($"{sentimentEmoji} [{item.Source}] {item.Title}");
                sb.AppendLine($"   Score: {item.SentimentScore:+0.00;-0.00}");
                sb.AppendLine();
            }

            // Общий sentiment score
            var avgScore = news.Average(n => n.SentimentScore);
            sb.AppendLine($"**Average Sentiment: {avgScore:+0.00;-0.00}**");

            return sb.ToString();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ошибка получения новостного контекста для {Symbol}", symbol);
            return null;
        }
    }
}
﻿using AITradingSystem.Core.Models.MarketData;

namespace AITradingSystem.Core.Indicators;

/// <summary>
/// On-Balance Volume (FR-3.1).
/// Кумулятивный индикатор объема.
/// </summary>
public sealed class OBV : BaseIndicator
{
    private decimal _value;
    private decimal _prevClose;
    private bool _hasPrev;

    public override string Name => "OBV";
    public override int WarmupPeriod => 1;

    public override void Update(OHLCV candle)
    {
        ProcessedCount++;

        if (!_hasPrev)
        {
            _value = candle.Volume;
            _prevClose = candle.Close;
            _hasPrev = true;
            return;
        }

        if (candle.Close > _prevClose)
            _value += candle.Volume;
        else if (candle.Close < _prevClose)
            _value -= candle.Volume;

        _prevClose = candle.Close;
    }

    public override decimal UpdateUnfinished(OHLCV candle)
    {
        if (!_hasPrev)
            return candle.Volume;

        var obv = _value;
        if (candle.Close > _prevClose)
            obv += candle.Volume;
        else if (candle.Close < _prevClose)
            obv -= candle.Volume;

        return obv;
    }

    public override decimal GetValue() => _value;

    public override void Reset()
    {
        _value = 0;
        _prevClose = 0;
        _hasPrev = false;
        ProcessedCount = 0;
    }
}
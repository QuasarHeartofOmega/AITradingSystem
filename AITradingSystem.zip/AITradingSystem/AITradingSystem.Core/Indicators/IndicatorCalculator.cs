﻿using AITradingSystem.Core.Models.MarketData;

namespace AITradingSystem.Core.Indicators;

/// <summary>
/// Агрегатор всех индикаторов для одной торговой пары.
/// </summary>
public sealed class IndicatorCalculator
{
    public string Symbol { get; }

    // Тренд
    public EMA EMA20 { get; }
    public EMA EMA50 { get; }
    public EMA EMA200 { get; }
    public Supertrend Supertrend { get; }
    public ADX ADX { get; }

    // Импульс
    public RSI RSI { get; }
    public MACD MACD { get; }
    public StochasticRsi StochasticRsi { get; }

    // Волатильность
    public ATR ATR { get; }
    public BollingerBands BollingerBands { get; }

    // Объем
    public OBV OBV { get; }
    public VWAP VWAP { get; }

    public IndicatorCalculator(string symbol)
    {
        Symbol = symbol ?? throw new ArgumentNullException(nameof(symbol));

        // Тренд
        EMA20 = new EMA(20);
        EMA50 = new EMA(50);
        EMA200 = new EMA(200);
        Supertrend = new Supertrend(10, 3.0m);
        ADX = new ADX(14);

        // Импульс
        RSI = new RSI(14);
        MACD = new MACD(12, 26, 9);
        StochasticRsi = new StochasticRsi(14, 14, 3, 3);

        // Волатильность
        ATR = new ATR(14);
        BollingerBands = new BollingerBands(20, 2.0m);

        // Объем
        OBV = new OBV();
        VWAP = new VWAP();
    }

    /// <summary>
    /// Обновить все индикаторы новой свечой.
    /// </summary>
    public void Update(OHLCV candle)
    {
        EMA20.Update(candle);
        EMA50.Update(candle);
        EMA200.Update(candle);
        Supertrend.Update(candle);
        ADX.Update(candle);

        RSI.Update(candle);
        MACD.Update(candle);
        StochasticRsi.Update(candle);

        ATR.Update(candle);
        BollingerBands.Update(candle);

        OBV.Update(candle);
        VWAP.Update(candle);
    }

    /// <summary>
    /// Все индикаторы прошли прогрев.
    /// </summary>
    public bool AllReady =>
        EMA20.IsReady && EMA50.IsReady && EMA200.IsReady &&
        Supertrend.IsReady && ADX.IsReady &&
        RSI.IsReady && MACD.IsReady && StochasticRsi.IsReady &&
        ATR.IsReady && BollingerBands.IsReady &&
        OBV.IsReady && VWAP.IsReady;

    /// <summary>
    /// Максимальный период прогрева среди всех индикаторов.
    /// </summary>
    public int MaxWarmupPeriod => 250; // EMA200 + буфер

    /// <summary>
    /// Получить нормализованный снимок для AI-модели (FR-3.3).
    /// </summary>
    public NormalizedIndicatorSnapshot GetNormalizedSnapshot(OHLCV currentCandle)
    {
        return new NormalizedIndicatorSnapshot(Symbol, currentCandle, this);
    }

    public void Reset()
    {
        EMA20.Reset();
        EMA50.Reset();
        EMA200.Reset();
        Supertrend.Reset();
        ADX.Reset();
        RSI.Reset();
        MACD.Reset();
        StochasticRsi.Reset();
        ATR.Reset();
        BollingerBands.Reset();
        OBV.Reset();
        VWAP.Reset();
    }
}
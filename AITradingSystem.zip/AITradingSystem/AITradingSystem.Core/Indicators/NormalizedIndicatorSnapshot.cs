﻿using AITradingSystem.Core.Models.MarketData;

namespace AITradingSystem.Core.Indicators;

/// <summary>
/// Нормализованный снимок индикаторов для AI-модели (FR-3.3).
/// Все значения приведены к диапазону [-1; 1] или [0; 1].
/// </summary>
public sealed class NormalizedIndicatorSnapshot
{
    public string Symbol { get; }
    public DateTime Timestamp { get; }
    public decimal Price { get; }

    // Тренд (все в [-1; 1])
    public decimal EMA20Position { get; } // позиция цены относительно EMA20
    public decimal EMA50Position { get; }
    public decimal EMA200Position { get; }
    public decimal EMAAlignment { get; } // 1 = бычье выравнивание, -1 = медвежье
    public decimal SupertrendDirection { get; } // 1 = uptrend, -1 = downtrend
    public decimal ADXStrength { get; } // [0; 1] — сила тренда

    // Импульс (все в [-1; 1])
    public decimal RSI { get; } // нормализованный RSI
    public decimal MACDHistogram { get; } // нормализованный гистограм
    public decimal StochRSI_K { get; } // [0; 1]
    public decimal StochRSI_D { get; } // [0; 1]

    // Волатильность (все в [0; 1])
    public decimal ATRPercent { get; } // ATR в % от цены
    public decimal BollingerWidth { get; } // ширина BB
    public decimal BollingerPosition { get; } // позиция цены в BB [-1; 1]

    // Объем (все в [-1; 1])
    public decimal OBVTrend { get; } // тренд OBV
    public decimal VWAPDeviation { get; } // отклонение от VWAP

    public NormalizedIndicatorSnapshot(string symbol, OHLCV candle, IndicatorCalculator calc)
    {
        Symbol = symbol;
        Timestamp = candle.CloseTime;
        Price = candle.Close;

        // Тренд
        EMA20Position = NormalizeDeviation(candle.Close, calc.EMA20.GetValue());
        EMA50Position = NormalizeDeviation(candle.Close, calc.EMA50.GetValue());
        EMA200Position = NormalizeDeviation(candle.Close, calc.EMA200.GetValue());

        var ema20 = calc.EMA20.GetValue();
        var ema50 = calc.EMA50.GetValue();
        var ema200 = calc.EMA200.GetValue();
        EMAAlignment = (ema20 > ema50 && ema50 > ema200) ? 1m :
                       (ema20 < ema50 && ema50 < ema200) ? -1m : 0m;

        SupertrendDirection = calc.Supertrend.IsUptrend ? 1m : -1m;
        ADXStrength = Math.Min(calc.ADX.Value / 100m, 1m); // ADX обычно 0-100

        // Импульс
        RSI = (calc.RSI.GetValue() - 50m) / 50m; // RSI 0-100 → -1..1
        var macdHist = calc.MACD.Histogram;
        MACDHistogram = NormalizeWithATR(macdHist, calc.ATR.GetValue());
        StochRSI_K = calc.StochasticRsi.K / 100m;
        StochRSI_D = calc.StochasticRsi.D / 100m;

        // Волатильность
        ATRPercent = calc.ATR.GetValue() / candle.Close;
        BollingerWidth = calc.BollingerBands.Width;
        var bbUpper = calc.BollingerBands.Upper;
        var bbLower = calc.BollingerBands.Lower;
        var bbRange = bbUpper - bbLower;
        BollingerPosition = bbRange > 0 ? (candle.Close - bbLower) / bbRange * 2m - 1m : 0;

        // Объем (упрощенно)
        OBVTrend = 0; // Для полной реализации нужен анализ тренда OBV
        var vwap = calc.VWAP.GetValue();
        VWAPDeviation = vwap > 0 ? (candle.Close - vwap) / vwap : 0;
    }

    /// <summary>
    /// Нормализация отклонения в % к диапазону [-1; 1].
    /// </summary>
    private static decimal NormalizeDeviation(decimal price, decimal indicator)
    {
        if (indicator == 0) return 0;
        var deviation = (price - indicator) / indicator;
        return Math.Max(-1m, Math.Min(1m, deviation * 10m)); // умножаем на 10 для чувствительности
    }

    /// <summary>
    /// Нормализация значения через ATR.
    /// </summary>
    private static decimal NormalizeWithATR(decimal value, decimal atr)
    {
        if (atr == 0) return 0;
        var normalized = value / atr;
        return Math.Max(-1m, Math.Min(1m, normalized / 3m));
    }

    /// <summary>
    /// Преобразовать в словарь для промпта.
    /// </summary>
    public Dictionary<string, decimal> ToDictionary()
    {
        return new Dictionary<string, decimal>
        {
            ["ema20_pos"] = EMA20Position,
            ["ema50_pos"] = EMA50Position,
            ["ema200_pos"] = EMA200Position,
            ["ema_align"] = EMAAlignment,
            ["supertrend"] = SupertrendDirection,
            ["adx"] = ADXStrength,
            ["rsi"] = RSI,
            ["macd_hist"] = MACDHistogram,
            ["stoch_rsi_k"] = StochRSI_K,
            ["stoch_rsi_d"] = StochRSI_D,
            ["atr_pct"] = ATRPercent,
            ["bb_width"] = BollingerWidth,
            ["bb_pos"] = BollingerPosition,
            ["obv_trend"] = OBVTrend,
            ["vwap_dev"] = VWAPDeviation
        };
    }
}
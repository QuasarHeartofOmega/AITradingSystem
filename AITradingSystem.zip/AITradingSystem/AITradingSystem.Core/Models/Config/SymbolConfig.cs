using System.Text.Json.Serialization;
using AITradingSystem.Common.Configuration;
namespace AITradingSystem.Core.Models.Config;

public sealed class SymbolConfig
{
    public string Symbol { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public int Priority { get; set; }
    public decimal MaxPositionPercent { get; set; } = 5m;
    public string Notes { get; set; } = string.Empty;
    /// <summary>Необязательная точность из конфигурации; exchangeInfo.tickSize имеет приоритет.</summary>
    public int? PriceDecimals { get; set; }
    [JsonIgnore]
    public IEnumerable<string>? KnownQuotes { get; set; }
    public string BaseAsset => SymbolNaming.TrySplit(Symbol, KnownQuotes, out var b, out _) ? b : Symbol;
    public string QuoteAsset => SymbolNaming.TrySplit(Symbol, KnownQuotes, out _, out var q) ? q : string.Empty;

    public void Validate()
    {
        var normalized = SymbolNaming.NormalizeSymbol(Symbol, KnownQuotes);
        if (normalized is null)
            throw new InvalidOperationException($"Symbol {Symbol}: ожидается BASEQUOTE с известной котировкой.");
        Symbol = normalized;
        if (MaxPositionPercent <= 0 || MaxPositionPercent > 100)
            throw new InvalidOperationException($"MaxPositionPercent {Symbol} должен быть в диапазоне (0; 100].");
        if (Priority < 0) throw new InvalidOperationException("Priority не может быть отрицательным.");
        if (PriceDecimals is < 0 or > 12) throw new InvalidOperationException($"PriceDecimals {Symbol} должен быть в [0; 12].");
    }
}

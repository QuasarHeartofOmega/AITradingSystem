﻿namespace AITradingSystem.Core.Models.Config;

/// <summary>
/// Конфигурация одной торговой пары.
/// </summary>
public sealed class SymbolConfig
{
    public string Symbol { get; set; } = string.Empty;
    public bool Enabled { get; set; } = true;
    public int Priority { get; set; }
    public decimal MaxPositionPercent { get; set; }
    public string Notes { get; set; } = string.Empty;

    /// <summary>
    /// Базовый актив (например, BTC для BTCUSDT).
    /// </summary>
    public string BaseAsset => Symbol.Length >= 4
        ? Symbol.Substring(0, Symbol.Length - 4)
        : Symbol;

    /// <summary>
    /// Котируемый актив (например, USDT для BTCUSDT).
    /// </summary>
    public string QuoteAsset => Symbol.Length >= 4
        ? Symbol.Substring(Symbol.Length - 4)
        : string.Empty;

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Symbol))
            throw new InvalidOperationException("Symbol не может быть пустым.");

        if (Symbol.Length < 5)
            throw new InvalidOperationException(
                $"Symbol {Symbol} слишком короткий. Ожидается формат BASEQUOTE (например, BTCUSDT).");

        if (MaxPositionPercent <= 0 || MaxPositionPercent > 100)
            throw new InvalidOperationException(
                $"MaxPositionPercent должен быть в диапазоне (0; 100]. Текущее: {MaxPositionPercent}");

        if (Priority < 0)
            throw new InvalidOperationException("Priority не может быть отрицательным.");
    }
}
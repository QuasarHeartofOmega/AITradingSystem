﻿namespace AITradingSystem.Core.Models.Config;

/// <summary>
/// Реестр торговых пар (загружается из symbols.json).
/// </summary>
public sealed class SymbolsRegistry
{
    public string Version { get; set; } = "1.0";
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public List<SymbolConfig> Symbols { get; set; } = new();

    public void Validate()
    {
        if (Symbols is null || Symbols.Count == 0)
            throw new InvalidOperationException("Реестр торговых пар пуст.");

        if (Symbols.Count > 10)
            throw new InvalidOperationException(
                $"Максимум 10 торговых пар. Указано: {Symbols.Count}");

        var sum = Symbols.Where(s => s.Enabled).Sum(s => s.MaxPositionPercent);
        if (sum > 100)
            throw new InvalidOperationException(
                $"Сумма MaxPositionPercent активных пар ({sum}%) превышает 100%.");

        var duplicates = Symbols
            .GroupBy(s => s.Symbol, StringComparer.OrdinalIgnoreCase)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        if (duplicates.Count > 0)
            throw new InvalidOperationException(
                $"Дубликаты в реестре: {string.Join(", ", duplicates)}");

        foreach (var symbol in Symbols)
            symbol.Validate();
    }
}
﻿namespace AITradingSystem.Core.Models.MarketData;

/// <summary>
/// Снимок стакана ордеров (FR-1.3).
/// </summary>
public sealed class OrderBook
{
    public string Symbol { get; set; } = string.Empty;
    public List<OrderBookEntry> Bids { get; set; } = new();
    public List<OrderBookEntry> Asks { get; set; } = new();
    public DateTime Timestamp { get; set; }
    public long LastUpdateId { get; set; }

    /// <summary>
    /// Лучшая цена покупки.
    /// </summary>
    public decimal? BestBid => Bids.Count > 0 ? Bids[0].Price : null;

    /// <summary>
    /// Лучшая цена продажи.
    /// </summary>
    public decimal? BestAsk => Asks.Count > 0 ? Asks[0].Price : null;

    /// <summary>
    /// Spread между лучшим bid и ask.
    /// </summary>
    public decimal? Spread => (BestAsk.HasValue && BestBid.HasValue)
        ? BestAsk.Value - BestBid.Value
        : null;

    /// <summary>
    /// Mid-price — средняя цена между лучшим bid и ask.
    /// </summary>
    public decimal? MidPrice => (BestAsk.HasValue && BestBid.HasValue)
        ? (BestAsk.Value + BestBid.Value) / 2m
        : null;

    /// <summary>
    /// Суммарный объем bid на первых N уровнях.
    /// </summary>
    public decimal BidDepth(int levels = 10)
    {
        return Bids.Take(levels).Sum(b => b.Quantity * b.Price);
    }

    /// <summary>
    /// Суммарный объем ask на первых N уровнях.
    /// </summary>
    public decimal AskDepth(int levels = 10)
    {
        return Asks.Take(levels).Sum(a => a.Quantity * a.Price);
    }

    /// <summary>
    /// Соотношение давления покупателей/продавцов (bid/ask volume ratio).
    /// > 1 — давление покупателей, < 1 — продавцов.
    /// </summary>
    public decimal? OrderBookImbalance(int levels = 10)
    {
        var bidDepth = BidDepth(levels);
        var askDepth = AskDepth(levels);
        var total = bidDepth + askDepth;
        return total > 0 ? (bidDepth - askDepth) / total : null;
    }
}

public sealed class OrderBookEntry
{
    public decimal Price { get; set; }
    public decimal Quantity { get; set; }
}
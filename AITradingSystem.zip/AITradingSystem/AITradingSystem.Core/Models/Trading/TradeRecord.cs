﻿using AITradingSystem.Core.Models.Enums;

namespace AITradingSystem.Core.Models.Trading;

/// <summary>
/// Запись о закрытой сделке (для истории, FR-7.1).
/// </summary>
public sealed class TradeRecord
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Symbol { get; set; } = string.Empty;
    public OrderSide Side { get; set; }
    public decimal Quantity { get; set; }
    public decimal EntryPrice { get; set; }
    public decimal ExitPrice { get; set; }
    public decimal PnL { get; set; }
    public decimal PnLPercent { get; set; }
    public decimal Commission { get; set; }
    public string ExitReason { get; set; } = string.Empty; // "TP", "SL", "TrailingStop", "Manual"
    public DateTime OpenedAt { get; set; }
    public DateTime ClosedAt { get; set; }
    public string SignalId { get; set; } = string.Empty;

    /// <summary>
    /// Длительность сделки.
    /// </summary>
    public TimeSpan Duration => ClosedAt - OpenedAt;
}
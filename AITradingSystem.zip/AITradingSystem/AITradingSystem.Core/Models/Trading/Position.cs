﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using AITradingSystem.Core.Models.Enums;

namespace AITradingSystem.Core.Models.Trading;

/// <summary>
/// Открытая позиция (FR-5).
/// Реализует INotifyPropertyChanged, чтобы UI обновлял PnL в реальном времени.
/// </summary>
public sealed class Position : INotifyPropertyChanged
{
    public event PropertyChangedEventHandler? PropertyChanged;

    private void OnPropertyChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    private void RaisePriceDependent()
    {
        OnPropertyChanged(nameof(CurrentPrice));
        OnPropertyChanged(nameof(UnrealizedPnL));
        OnPropertyChanged(nameof(UnrealizedPnLPercent));
        OnPropertyChanged(nameof(DistanceToStopLossPercent));
        OnPropertyChanged(nameof(DistanceToTakeProfitPercent));
    }

    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Symbol { get; set; } = string.Empty;
    public OrderSide Side { get; set; }
    public decimal Quantity { get; set; }
    public decimal EntryPrice { get; set; }
    public decimal CurrentPrice { get; set; }
    public decimal StopLoss { get; set; }
    public decimal TakeProfit { get; set; }
    public decimal InitialStopLoss { get; set; }
    public DateTime OpenedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string OpeningOrderId { get; set; } = string.Empty;
    public string SignalId { get; set; } = string.Empty;

    /// <summary>
    /// Инвестиционная сумма (notional).
    /// </summary>
    public decimal Notional => Quantity * EntryPrice;

    /// <summary>
    /// Нереализованный PnL в USDT.
    /// </summary>
    public decimal UnrealizedPnL => Side == OrderSide.Buy
        ? (CurrentPrice - EntryPrice) * Quantity
        : (EntryPrice - CurrentPrice) * Quantity;

    /// <summary>
    /// Нереализованный PnL в процентах.
    /// </summary>
    public decimal UnrealizedPnLPercent => EntryPrice > 0
        ? UnrealizedPnL / Notional * 100m
        : 0;

    /// <summary>
    /// Расстояние до SL в процентах.
    /// </summary>
    public decimal DistanceToStopLossPercent => CurrentPrice <= 0
        ? 0m
        : Side == OrderSide.Buy
            ? (CurrentPrice - StopLoss) / CurrentPrice * 100m
            : (StopLoss - CurrentPrice) / CurrentPrice * 100m;

    /// <summary>
    /// Расстояние до TP в процентах.
    /// </summary>
    public decimal DistanceToTakeProfitPercent => CurrentPrice <= 0
        ? 0m
        : Side == OrderSide.Buy
            ? (TakeProfit - CurrentPrice) / CurrentPrice * 100m
            : (CurrentPrice - TakeProfit) / CurrentPrice * 100m;

    /// <summary>
    /// Обновить текущую цену (для расчета PnL).
    /// </summary>
    public void UpdatePrice(decimal newPrice)
    {
        CurrentPrice = newPrice;
        UpdatedAt = DateTime.UtcNow;
        RaisePriceDependent();
    }

    /// <summary>
    /// Обновить Trailing Stop (FR-5.5).
    /// Возвращает true, если SL был подтянут.
    /// </summary>
    public bool UpdateTrailingStop(decimal newStopLoss)
    {
        if (Side == OrderSide.Buy)
        {
            if (newStopLoss > StopLoss)
            {
                StopLoss = newStopLoss;
                UpdatedAt = DateTime.UtcNow;
                OnPropertyChanged(nameof(StopLoss));
                OnPropertyChanged(nameof(DistanceToStopLossPercent));
                return true;
            }
        }
        else
        {
            if (newStopLoss < StopLoss)
            {
                StopLoss = newStopLoss;
                UpdatedAt = DateTime.UtcNow;
                OnPropertyChanged(nameof(StopLoss));
                OnPropertyChanged(nameof(DistanceToStopLossPercent));
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Проверка, сработал ли Stop-Loss.
    /// </summary>
    public bool IsStopLossHit(decimal low, decimal high)
    {
        return Side == OrderSide.Buy ? low <= StopLoss : high >= StopLoss;
    }

    /// <summary>
    /// Проверка, сработал ли Take-Profit.
    /// </summary>
    public bool IsTakeProfitHit(decimal low, decimal high)
    {
        return Side == OrderSide.Buy ? high >= TakeProfit : low <= TakeProfit;
    }
}
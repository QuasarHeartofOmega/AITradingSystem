﻿namespace AITradingSystem.Core.Models.Trading;

/// <summary>
/// Баланс аккаунта.
/// </summary>
public sealed class AccountBalance
{
    public decimal TotalUSDT { get; set; }
    public decimal AvailableUSDT { get; set; }
    public decimal LockedUSDT { get; set; }
    public Dictionary<string, decimal> AssetBalances { get; set; } = new();
    public DateTime Timestamp { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Обновить баланс конкретного актива.
    /// </summary>
    public void UpdateAsset(string asset, decimal free, decimal locked)
    {
        AssetBalances[asset] = free;
        if (asset.Equals("USDT", StringComparison.OrdinalIgnoreCase))
        {
            AvailableUSDT = free;
            LockedUSDT = locked;
            TotalUSDT = free + locked;
        }
    }
}
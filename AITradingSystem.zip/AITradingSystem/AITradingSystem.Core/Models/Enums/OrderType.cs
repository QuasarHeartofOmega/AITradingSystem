﻿namespace AITradingSystem.Core.Models.Enums;

public enum OrderType
{
    Limit = 0,
    Market = 1
}
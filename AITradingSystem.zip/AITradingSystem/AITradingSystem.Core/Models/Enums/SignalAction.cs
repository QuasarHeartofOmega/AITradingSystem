﻿namespace AITradingSystem.Core.Models.Enums;

public enum SignalAction
{
    Buy = 0,
    Sell = 1,
    Hold = 2
}
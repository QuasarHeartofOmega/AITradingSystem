﻿using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Core.RiskManagement;

/// <summary>
/// Расчет размера позиции на основе риска (FR-5.1).
/// </summary>
public sealed class PositionSizer
{
    private readonly TradingConfig _config;

    public PositionSizer(TradingConfig config)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
    }

    /// <summary>
    /// Рассчитать размер позиции.
    /// </summary>
    /// <param name="balance">Доступный баланс USDT.</param>
    /// <param name="entryPrice">Цена входа.</param>
    /// <param name="stopLoss">Цена Stop-Loss.</param>
    /// <param name="atr">Текущий ATR для валидации.</param>
    /// <returns>Размер позиции в базовом активе.</returns>
    public decimal CalculatePositionSize(
        decimal balance,
        decimal entryPrice,
        decimal stopLoss,
        decimal atr)
    {
        if (balance <= 0)
            throw new ArgumentException("Balance must be > 0", nameof(balance));
        if (entryPrice <= 0)
            throw new ArgumentException("EntryPrice must be > 0", nameof(entryPrice));
        if (stopLoss <= 0)
            throw new ArgumentException("StopLoss must be > 0", nameof(stopLoss));

        var riskAmount = balance * (decimal)_config.RiskPerTrade;
        var stopDistance = Math.Abs(entryPrice - stopLoss);

        if (stopDistance == 0)
            return 0;

        var quantity = riskAmount / stopDistance;

        // Проверка: не превышает ли позиция доступный баланс
        var maxQuantity = balance / entryPrice;
        quantity = Math.Min(quantity, maxQuantity);

        return quantity;
    }
}
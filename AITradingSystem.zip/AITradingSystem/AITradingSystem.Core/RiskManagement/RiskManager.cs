﻿using AITradingSystem.Common.Configuration;
using AITradingSystem.Core.Models.Enums;
using AITradingSystem.Core.Models.Trading;

namespace AITradingSystem.Core.RiskManagement;

/// <summary>
/// Центральный менеджер рисков (FR-5).
/// </summary>
public sealed class RiskManager
{
    private readonly TradingConfig _config;
    private readonly PositionSizer _positionSizer;
    private readonly DrawdownTracker _drawdownTracker;

    public DrawdownTracker DrawdownTracker => _drawdownTracker;

    /// <summary>
    /// P0.6: условие авто-kill-switch — лимит просадки/дня пробит и автозакрытие включено.
    /// Решение «закрывать ли всё» принимает движок; здесь только чистый предикат (покрыт тестом).
    /// </summary>
    public bool ShouldEngageKillSwitch =>
        _config.KillSwitchAutoCloseOnRiskBreach && !_drawdownTracker.IsTradingAllowed;

    public RiskManager(TradingConfig config, decimal initialBalance, Func<DateTime>? exchangeUtcNow = null)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _positionSizer = new PositionSizer(config);
        // P0.4: трекер создаётся здесь один раз на процесс; состояние (пик/день)
        // восстанавливается через DrawdownTracker.RestoreState в TradingEngine.StartAsync.
        _drawdownTracker = new DrawdownTracker(config, initialBalance, exchangeUtcNow);
    }

    /// <summary>
    /// Рассчитать SL на основе ATR (FR-5.3).
    /// </summary>
    public decimal CalculateStopLoss(OrderSide side, decimal entryPrice, decimal atr)
    {
        var distance = atr * (decimal)_config.StopLossAtrMultiplier;
        return side == OrderSide.Buy
            ? entryPrice - distance
            : entryPrice + distance;
    }

    /// <summary>
    /// Рассчитать TP на основе Risk/Reward (FR-5.4).
    /// </summary>
    public decimal CalculateTakeProfit(OrderSide side, decimal entryPrice, decimal stopLoss)
    {
        var risk = Math.Abs(entryPrice - stopLoss);
        var reward = risk * (decimal)_config.MinRiskRewardRatio;

        return side == OrderSide.Buy
            ? entryPrice + reward
            : entryPrice - reward;
    }

    /// <summary>
    /// Рассчитать Trailing Stop (FR-5.5).
    /// </summary>
    public decimal CalculateTrailingStop(OrderSide side, decimal currentPrice, decimal atr)
    {
        var distance = atr * (decimal)_config.TrailingStopAtrMultiplier;
        return side == OrderSide.Buy
            ? currentPrice - distance
            : currentPrice + distance;
    }

    /// <summary>
    /// Валидация сигнала перед исполнением.
    /// </summary>
    public bool ValidateSignal(TradingSignal signal, decimal balance, out string reason)
    {
        if (!_drawdownTracker.IsTradingAllowed)
        {
            reason = _drawdownTracker.IsMaxDrawdownHit
                ? $"Max drawdown hit: {_drawdownTracker.CurrentDrawdownPercent:P2}"
                : $"Daily loss limit hit: {_drawdownTracker.DailyPnLPercent:P2}";
            return false;
        }

        if (!signal.IsValid(out var signalError))
        {
            reason = $"Invalid signal: {signalError}";
            return false;
        }

        if (signal.Action == SignalAction.Hold)
        {
            reason = "Hold signal";
            return false;
        }

        // Проверка R/R
        var rr = signal.RiskRewardRatio;
        if (rr.HasValue && rr.Value < (decimal)_config.MinRiskRewardRatio)
        {
            reason = $"Risk/Reward too low: {rr.Value:F2} < {_config.MinRiskRewardRatio}";
            return false;
        }

        reason = string.Empty;
        return true;
    }

    /// <summary>
    /// Обновить баланс после сделки.
    /// </summary>
    public void UpdateBalance(decimal newBalance)
    {
        _drawdownTracker.UpdateBalance(newBalance);
    }

    /// <summary>
    /// Рассчитать размер позиции.
    /// </summary>
    public decimal CalculatePositionSize(decimal balance, decimal entryPrice, decimal stopLoss, decimal atr)
    {
        return _positionSizer.CalculatePositionSize(balance, entryPrice, stopLoss, atr);
    }
}
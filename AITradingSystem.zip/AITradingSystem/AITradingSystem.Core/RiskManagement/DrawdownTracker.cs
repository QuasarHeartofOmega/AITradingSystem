﻿using AITradingSystem.Common.Configuration;

namespace AITradingSystem.Core.RiskManagement;

/// <summary>
/// Отслеживание просадки и дневных убытков (FR-5.6, FR-5.7).
/// </summary>
public sealed class DrawdownTracker
{
    private readonly TradingConfig _config;
    private decimal _peakBalance;
    private decimal _dayStartBalance;
    private DateTime _currentDay;

    public decimal CurrentBalance { get; private set; }
    public decimal MaxDrawdownPercent { get; private set; }
    public decimal CurrentDrawdownPercent { get; private set; }
    public decimal DailyPnL { get; private set; }
    public decimal DailyPnLPercent { get; private set; }

    public bool IsMaxDrawdownHit => CurrentDrawdownPercent >= (decimal)_config.MaxDrawdown;
    public bool IsDailyLossLimitHit => DailyPnLPercent <= -(decimal)_config.DailyLossLimit;
    public bool IsTradingAllowed => !IsMaxDrawdownHit && !IsDailyLossLimitHit;

    public DrawdownTracker(TradingConfig config, decimal initialBalance)
    {
        _config = config ?? throw new ArgumentNullException(nameof(config));
        _peakBalance = initialBalance;
        _dayStartBalance = initialBalance;
        CurrentBalance = initialBalance;
        _currentDay = DateTime.UtcNow.Date;
    }

    /// <summary>
    /// Обновить баланс.
    /// </summary>
    public void UpdateBalance(decimal newBalance)
    {
        CurrentBalance = newBalance;

        // Обновляем пик
        if (newBalance > _peakBalance)
            _peakBalance = newBalance;

        // Расчет просадки от пика
        CurrentDrawdownPercent = _peakBalance > 0
            ? (_peakBalance - newBalance) / _peakBalance
            : 0;

        if (CurrentDrawdownPercent > MaxDrawdownPercent)
            MaxDrawdownPercent = CurrentDrawdownPercent;

        // Проверка смены дня
        var today = DateTime.UtcNow.Date;
        if (today != _currentDay)
        {
            _dayStartBalance = newBalance;
            _currentDay = today;
        }

        // Расчет дневного PnL
        DailyPnL = newBalance - _dayStartBalance;
        DailyPnLPercent = _dayStartBalance > 0
            ? DailyPnL / _dayStartBalance
            : 0;
    }

    /// <summary>
    /// Сбросить дневную статистику (при ручном сбросе).
    /// </summary>
    public void ResetDaily()
    {
        _dayStartBalance = CurrentBalance;
        DailyPnL = 0;
        DailyPnLPercent = 0;
    }

    /// <summary>
    /// Полная статистика для логирования.
    /// </summary>
    public string GetStatus()
    {
        return $"Balance: {CurrentBalance:F2}, " +
               $"Drawdown: {CurrentDrawdownPercent:P2} (max: {MaxDrawdownPercent:P2}), " +
               $"Daily PnL: {DailyPnL:F2} ({DailyPnLPercent:P2})";
    }
}
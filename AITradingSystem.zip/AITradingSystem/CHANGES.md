# Введённые изменения — AITradingSystem

Формат: дата · задача · файлы · что сделано.
Исходники: `repo/src/AITradingSystem/`. Сборка/прогоны не выполнялись (по требованию: без компиляций).

---

## 2026-11-23 — Пакет A1–A3 (GPU/native)

### A1. NEW `AITradingSystem.Services/AI/GgmlNative.cs`
- Безопасные обёртки над экспортами загруженных `llama.dll` / `ggml.dll` / `ggml-base.dll` через `LlamaNativeLoader.TryGetExport` (экспорт не найден → однократный лог + деградация, без краша).
- `InstallLogCapture(level)`: `llama_log_set` со своим делегатом (статическая ссылка от GC), маршрутизация нативных строк в `AiLog.Backend` с фильтром уровня (Off/Error/Warn/Info/Debug).
- Парсинг нативного лога: `offloaded N/M layers to GPU`, `using CPU instead`, `CUDA0/Vulkan0 buffer size`, `out of memory` → свойства `OffloadedLayers`, `TotalLayers`, `CpuFallbackDetected`, `OutOfMemoryDetected`, `GpuBufferSizesMb`; `ResetLoadStats()` перед каждой загрузкой модели.
- `TryLoadAllBackends(path)` / `TryLoadBackend(dllPath)` — явная регистрация backend-DLL (`ggml_backend_load_all_from_path` / `ggml_backend_load`), если экспорты есть.
- `SupportsGpuOffload()` (`llama_supports_gpu_offload`), `GetDevices()` → `List<NativeDeviceInfo>` (имя, бэкенд, VRAM free/total через `ggml_backend_dev_*`).

### A1 (предпосылка из A4). MODIFY `AITradingSystem.Services/AI/LlamaNativeLoader.cs`
- Добавлены `public static bool TryGetExport(string library, string export, out IntPtr ptr)` (резолв хэндла + `NativeLibrary.TryGetExport`) и `public static string? GetBackendDirectory()` (каталог фактической загрузки). Остальные правки A4 — впереди.

### A2. NEW `AITradingSystem.Services/AI/GgufInspector.cs`
- Парсер GGUF v2/v3 без загрузки модели: magic/версия, metadata KV (все скалярные типы + пропуск массивов), список тензоров (имя, тип, dims, offset).
- `GgufModelInfo`: Architecture, BlockCount, ContextLength, EmbeddingLength, HeadCount/HeadCountKv/KeyLength/ValueLength, VocabSize; `WeightBytesTotal` (точно по типам квантования ggml, таблица size/block для F32…Q6_K/IQ*), `TokenEmbeddingBytes`, `OutputWeightBytes`, `MaxTensorBytes`, `BytesPerLayer` (среднее по `blk.N.*`), `DataStartOffset`.
- `KvBytesPerToken(kvType)` — f16/q8_0/q4_0, по реальным head_count_kv и key/value length.
- `ComputeBufferEstimate(batch, ctx, flashAttn)` — оценка compute-буферов (attention scores без flash = batch·ctx·heads·4).
- `RecommendGpuLayers(vramFreeMb, reserveMb, ctx, flashAttn, kvType, batch, maxSingleAllocMb)` → максимум слоёв; `CanFullyOffload(...)` отдельно. `maxSingleAllocMb` — лимит одной аллокации для legacy AMD (Polaris ~1 GB): если `token_embd` больше лимита → 0 (CPU).

### A3. NEW `AITradingSystem.Services/AI/NativeStaging.cs`
- `Stage(backend, explicitPath, logger)` → плоский каталог `<exe>\native-staged\<backend>` (fallback `%LOCALAPPDATA%\AITradingSystem\native\<backend>` при read-only exe).
- Копирует выбранный набор: `llama`, `ggml`, `ggml-base`, все найденные `ggml-cpu*` (для GPU — добирает CPU-варианты из CPU-каталогов, llama.cpp требует CPU-бэкенд всегда), `ggml-cuda` + `cudart*/cublas*` для CUDA, `ggml-vulkan` для Vulkan.
- До первого вызова llama API: `GGML_BACKEND_PATH` = staged-каталог; на Windows `SetDllDirectory` + `AddDllDirectory` (зависимости CUDA ищутся там).
- Копирование идемпотентно (пропуск по длине+времени записи), занятые файлы не валят стейдж.
- `LlamaNativeLoader.Initialize(stagedDir)` — staged-каталог становится приоритетным для резолвера (строгий «только staged» режим — в A4).
- Диагностика: итоговый каталог, список файлов, `GGML_BACKEND_PATH`; предупреждение, если llama уже загружена из другого каталога (смена бэкенда потребует чистого стейджа).

### Служебные файлы
- `PLAN.md` — копия плана со статусами задач (A1–A3 ✅).
- `CHANGES.md` — этот журнал изменений.

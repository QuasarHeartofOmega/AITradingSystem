# Введённые изменения — AITradingSystem

Формат: дата · задача · файлы · что сделано.
Исходники: `repo/src/AITradingSystem/`. Сборка/прогоны не выполнялись (по требованию: без компиляций).

---

## 2026-11-24 — Пакет B8–B11 (confidence / детерминированный pre-score)

### B8. MODIFY `AITradingSystem.Services/AI/PromptBuilder.cs` (переписан)
- **Удалено правило 6** («confidence below 0.55») — источник якоря 0.45. Вместо него: «confidence MUST be derived from the evidence rubric … do NOT default to any fixed number».
- Добавлена **легенда индикаторов**: что нормализовано и как (ema*_pos, ema_align, supertrend, adx, rsi, macd_hist, stoch_rsi, atr_pct, bb_*, obv_trend, vwap_dev) и что сырое (rsi_raw/adx_raw 0–100, stoch_k_raw/d_raw, atr_abs, ema20/50/200, bb_upper/lower, vwap, macd_hist_abs, volume_ratio).
- Добавлена **рубрика уверенности**: старт от `engine_prior_confidence`, +0.05…0.15 за согласие тренда/моментума/объёма, −0.10…0.20 за конфликты/ADX<20/объём<0.6/край BB/новостной риск, clamp [0.10; 0.90]; два примера (BUY 0.72 / HOLD 0.30).
- В промпт уходит блок **Engine pre-score**: direction, score, engine_prior_confidence, reasons.
- Thinking сохранён (`/think`), инструкция сокращена до ~110 слов; **пустой think-блок больше не префиллится** (F3).
- Цены форматируются по **tickSize/PriceDecimals символа** (BTTC не округляется в ноль); в контекст печатается «Price precision: N decimals (tick size …)».
- `BuildRepairPrompt(..., bool enableThinking = true)` — ремонт без think-префилла, с явной просьбой не отвечать пустым сообщением.

### B8 (поддержка). MODIFY `AITradingSystem.Services/AI/AiRequestContext.cs`
- Новые поля: `EngineScore`, `EngineDirection`, `EnginePriorConfidence`, `EngineReasons`, `PriceDecimals` (дефолт 8), `TickSize`.

### B9. NEW `AITradingSystem.Services/Analysis/SignalCalibrator.cs`
- `EngineScore { Direction [-1;1], PriorConfidence [0.1;0.9], Components[], Reasons[] }`, `DirectionName` (LONG/SHORT/FLAT), `Summary`, `ReasonsText`; `ScoreComponent { Name, Weight, Value, Contribution }`.
- `PreScore(indicators)` — чистая математика: веса ema_align 0.30, supertrend 0.20, ema_position 0.15, rsi 0.15, macd_hist 0.10, stoch_rsi 0.05, obv_trend 0.05; модификаторы ADX (<20 ×0.6, ≥25 ×1.0), объём (volume_ratio <0.6 ×0.8, ≥1.5 ×1.1), волатильность (ATR <0.1% ×0.8, >6% ×0.75), край Bollinger ×0.85; `prior = 0.2 + 0.7·|score|`. Работает и без сырых ключей (берёт нормализованные аналоги).
- `Calibrate(signal, score, policy, CalibrationContext)`: `ModelOnly` — как раньше; `Blend` — 0.5·model + 0.5·prior, **дегенерат (HOLD, |conf−0.45| ≤ 0.02) → prior**; `EngineOverride` — всегда prior. Заполняет `ModelConfidence/EngineConfidence/IsDegenerateConfidence/ConfidenceSource`, пишет `TradeLog.Decision CALIBRATE` со всеми тремя значениями и политикой.
- Пересмотр HOLD → BUY/SELL только при `prior ≥ MinConfidence`, согласованном направлении и отсутствии позиции; цены входа считает алгоритм (`entry = цена`, `SL = entry − k·ATR`, `TP = entry + R/R·risk`, округление по decimals) — лог `ENGINE-ENTRY`. Сайзинг/SL/TP сопровождения остаются за RiskManager.
- `CalibrationContext { MinConfidence, HasPosition, AllowShort, Price, AtrAbsolute, StopLossAtrMultiplier, MinRiskReward, PriceDecimals }`.

### B10. MODIFY `AITradingSystem.Core/Indicators/NormalizedIndicatorSnapshot.cs`
- Новые свойства и ключи словаря: `rsi_raw, adx_raw, stoch_k_raw, stoch_d_raw, atr_abs, ema20, ema50, ema200, bb_upper, bb_lower, macd_hist_abs, vwap, volume_ratio`. Нормализованные ключи не тронуты (совместимость с тестами).

### B10/B11. MODIFY `AITradingSystem.Core/Indicators/IndicatorCalculator.cs`
- Окно объёмов SMA20 (`VolumeSma20`, `GetVolumeRatio(volume)`) — обновляется в `Update`, чистится в `Reset`.
- Счётчик `ClosedCandles` — для лога прогрева «N/M свечей».

### B11. MODIFY `AITradingSystem.Services/Analysis/MarketAnalyzer.cs`
- `GetWarmupInfo(symbol) → (Ready, Candles, Required)`; убран дублирующийся XML-комментарий.

### B11. MODIFY `AITradingSystem.Common/Logging/LogChannels.cs`
- `TradeLog.Waiting(symbol, reason)` — строка `WAITING` в `logs/trades-*.log`.

### B11. MODIFY `AITradingSystem.Services/Trading/TradingEngine.cs`
- Конструктор принимает `SignalCalibrator` (новое поле `_calibrator`).
- `ProcessSymbolAsync`: `PreScore` до вызова ИИ + лог `PRE-SCORE`, pre-score уходит в промпт через `AiRequestContext`; после ответа — `Calibrate(...)` с политикой `AI:ConfidencePolicy`; порог `MinConfidence` применяется к **FINAL** (в отказе печатаются model/engine/source).
- `indicators == null` / нет свечи → `TradeLog.Waiting` с прогрессом прогрева, не чаще раза в минуту на символ (вместо молчаливого return).
- Cooldown анализа символа `TryEnterAnalysisCooldown` (`Trading:SymbolAnalysisCooldownSeconds`, дефолт 60 с).
- `ReviewOpenPositionAsync` — тот же pre-score + калибровка + WAITING.
- Новые хелперы: `BuildCalibrationContext`, `LogWaiting`, `TryEnterAnalysisCooldown`; `BuildAiContext` расширен (pre-score, indicators, цена).

### D22 (частично). MODIFY `AITradingSystem.Common/Configuration/TradingConfig.cs`
- Новое поле `SymbolAnalysisCooldownSeconds = 60` + валидация [0; 3600].
- Лимит `MaxOpenPositions` поднят с 10 до **32** (дефолт 3 сохранён).

### Открытые хвосты этого пакета (зафиксированы в PLAN.md)
1. `App.xaml.cs`: регистрация `SignalCalibrator` в DI ещё не добавлена (C19) — без неё `TradingEngine` не резолвится.
2. `TradingEngine.GetPriceDecimals/GetTickSize` — заглушки (8/ null); символ в `BuildAiContext` берётся из `position?.Symbol`. Будет закрыто в D24 (tickSize из `GetSymbolInfoAsync` + `SymbolConfig.PriceDecimals`).
3. Лимит списка символов 10 → 32 в `TradingConfig.Validate`/`SymbolsRegistry.Validate` и `WatchAssets`/`QuoteAssets` — ещё не сделаны (D22).

---

## 2026-11-24 — Пакет A4–A7 (GPU/native, завершение блока A)

### A4. MODIFY `AITradingSystem.Services/AI/LlamaNativeLoader.cs` — завершено
- Проверено в коде (было сделано ранее): строгий `HasBackendFiles` (llama + ggml-base + marker в ОДНОМ каталоге, для CUDA ещё cudart/cublas), строгий staged-режим резолвера (`UseStagedDirectory` → поиск только в стейдже), `FreeLoadedHandles` запрещён после первого P/Invoke LLamaSharp (`_marshalerResolved` → `RequiresCleanStage`).
- Добавлено сейчас: `GetDiagnostics()` печатает **состав каталога** (все `llama*`, `ggml*`, `cudart*`, `cublas*` файлы) — видно, какие бэкенды реально зарегистрирует llama; чтение каталога защищено от исключений.

### A5. MODIFY `AITradingSystem.Services/AI/QwenModel.cs` — новый конвейер загрузки
- `LoadAsync`: `GpuProbe.Detect` (VRAM) → `SelectBackend` → `ActivateBackend` (стейдж DLL → резолвер → проба → `GgmlNative.InstallLogCapture` → `TryLoadAllBackends` → `GpuProbe.EnrichFromNative`) → `EnsureAvailable` → `GgufInspector.TryInspect` → `ResolveFit` → `LoadWithRetries`.
- `ActivateBackend(backend)` — единая точка активации: `NativeStaging.Stage`, `LlamaNativeLoader.Initialize/TryProbeBackend`, перехват нативного лога, явная регистрация ggml-бэкендов, предупреждение при `llama_supports_gpu_offload()=false`.
- `ResolveFit()` (AutoFitGpu): `RecommendGpuLayers(free − VramReserveMb, ctx, FlashAttention, KvCacheType, batch, maxSingleAlloc)`; при нехватке VRAM сначала ctx 8192 → 4096, затем при `layers < MinGpuLayers` — чистый CPU с причиной; legacy AMD → лимит одной аллокации 1024 MiB; в лог — KV/compute-оценка и «полный/частичный оффлоад N/M».
- `LoadWithRetries`: до 2 OOM-ретраев (`слои ×0.7, ctx/2`, затем `×0.49, ctx=2048`), распознавание OOM по исключению и нативному логу (`IsOutOfMemory`), затем явный CPU-фолбэк (`AllowCpuFallback`) с причиной в `AiLog`; «тихих» откатов нет.
- `VerifyOffload`: факт оффлоада из нативного лога (`offloaded N/M`), при GPU-бэкенде и offload=0 — громкий WARN + один рестейдж/перезагрузка, при потере весов — CPU-фолбэк.
- `ApplyOptionalParams`: `FlashAttention`, `TypeK/TypeV` (Q8_0/Q4_0) выставляются через рефлексию — отсутствие свойства в конкретной версии LLamaSharp не ломает загрузку (лог «свойство недоступно»).
- Новые свойства для UI (C15): `EffectiveContextSize`, `EffectiveGpuLayers`, `OffloadedLayers`, `TotalLayers`, `GpuName`, `VramTotalMb/VramFreeMb`, `LoadWarning`, `BackendSummary`.
- **F3 (пустой ответ)**: 0 символов больше не считается «невалидным JSON» — отдельная причина «пустой ответ (anti-prompt/EOS)» в лог и немедленный repair-повтор без think-префилла.
- **Confidence**: убран даунгрейд BUY→HOLD по `MinConfidence` внутри модели (порог теперь применяется движком к FINAL после калибратора); в лог пишется `model_conf` и признак дегенерата; в сигнал сохраняются `ModelConfidence` и `IsDegenerateConfidence` (HOLD, |conf−0.45| ≤ 0.02).

### A5 (поддержка). MODIFY `AITradingSystem.Core/Models/Trading/TradingSignal.cs`
- Добавлены `ModelConfidence`, `EngineConfidence`, `IsDegenerateConfidence`, `ConfidenceSource`; `Confidence` документирован как FINAL (после калибратора). Старые поля/`IsValid` не менялись.

### A6/A7 — верификация
- `GpuProbe.cs`: VRAM через nvidia-smi, `vulkaninfo --summary`, `IsLegacyAmd` (Polaris/Vega), WMI-фолбэк, `EnrichFromNative` — реализовано, правок не потребовалось.
- `AIConfig.cs`: `AutoFitGpu`, `VramReserveMb`, `MinGpuLayers`, `AllowCpuFallback`, `FlashAttention`, `KvCacheType`, `NativeLogLevel`, `ConfidencePolicy`, `ThinkingBudgetTokens=384` + Validate — реализовано, правок не потребовалось.

---

## 2026-11-23 — Пакет A1–A3 (GPU/native)

### A1. NEW `AITradingSystem.Services/AI/GgmlNative.cs`
- Безопасные обёртки над экспортами загруженных `llama.dll` / `ggml.dll` / `ggml-base.dll` через `LlamaNativeLoader.TryGetExport` (экспорт не найден → однократный лог + деградация, без краша).
- `InstallLogCapture(level)`: `llama_log_set` со своим делегатом (статическая ссылка от GC), маршрутизация нативных строк в `AiLog.Backend` с фильтром уровня (Off/Error/Warn/Info/Debug).
- Парсинг нативного лога: `offloaded N/M layers to GPU`, `using CPU instead`, `CUDA0/Vulkan0 buffer size`, `out of memory` → свойства `OffloadedLayers`, `TotalLayers`, `CpuFallbackDetected`, `OutOfMemoryDetected`, `GpuBufferSizesMb`; `ResetLoadStats()` перед каждой загрузкой модели.
- `TryLoadAllBackends(path)` / `TryLoadBackend(dllPath)` — явная регистрация backend-DLL (`ggml_backend_load_all_from_path` / `ggml_backend_load`), если экспорты есть.
- `SupportsGpuOffload()` (`llama_supports_gpu_offload`), `GetDevices()` → `List<NativeDeviceInfo>` (имя, бэкенд, VRAM free/total через `ggml_backend_dev_*`).

### A1 (предпосылка из A4). MODIFY `AITradingSystem.Services/AI/LlamaNativeLoader.cs`
- Добавлены `public static bool TryGetExport(string library, string export, out IntPtr ptr)` (резолв хэндла + `NativeLibrary.TryGetExport`) и `public static string? GetBackendDirectory()` (каталог фактической загрузки). Остальные правки A4 — впереди.

### A2. NEW `AITradingSystem.Services/AI/GgufInspector.cs`
- Парсер GGUF v2/v3 без загрузки модели: magic/версия, metadata KV (все скалярные типы + пропуск массивов), список тензоров (имя, тип, dims, offset).
- `GgufModelInfo`: Architecture, BlockCount, ContextLength, EmbeddingLength, HeadCount/HeadCountKv/KeyLength/ValueLength, VocabSize; `WeightBytesTotal` (точно по типам квантования ggml, таблица size/block для F32…Q6_K/IQ*), `TokenEmbeddingBytes`, `OutputWeightBytes`, `MaxTensorBytes`, `BytesPerLayer` (среднее по `blk.N.*`), `DataStartOffset`.
- `KvBytesPerToken(kvType)` — f16/q8_0/q4_0, по реальным head_count_kv и key/value length.
- `ComputeBufferEstimate(batch, ctx, flashAttn)` — оценка compute-буферов (attention scores без flash = batch·ctx·heads·4).
- `RecommendGpuLayers(vramFreeMb, reserveMb, ctx, flashAttn, kvType, batch, maxSingleAllocMb)` → максимум слоёв; `CanFullyOffload(...)` отдельно. `maxSingleAllocMb` — лимит одной аллокации для legacy AMD (Polaris ~1 GB): если `token_embd` больше лимита → 0 (CPU).

### A3. NEW `AITradingSystem.Services/AI/NativeStaging.cs`
- `Stage(backend, explicitPath, logger)` → плоский каталог `<exe>\native-staged\<backend>` (fallback `%LOCALAPPDATA%\AITradingSystem\native\<backend>` при read-only exe).
- Копирует выбранный набор: `llama`, `ggml`, `ggml-base`, все найденные `ggml-cpu*` (для GPU — добирает CPU-варианты из CPU-каталогов, llama.cpp требует CPU-бэкенд всегда), `ggml-cuda` + `cudart*/cublas*` для CUDA, `ggml-vulkan` для Vulkan.
- До первого вызова llama API: `GGML_BACKEND_PATH` = staged-каталог; на Windows `SetDllDirectory` + `AddDllDirectory` (зависимости CUDA ищутся там).
- Копирование идемпотентно (пропуск по длине+времени записи), занятые файлы не валят стейдж.
- `LlamaNativeLoader.Initialize(stagedDir)` — staged-каталог становится приоритетным для резолвера (строгий «только staged» режим — в A4).
- Диагностика: итоговый каталог, список файлов, `GGML_BACKEND_PATH`; предупреждение, если llama уже загружена из другого каталога (смена бэкенда потребует чистого стейджа).

### Служебные файлы
- `PLAN.md` — копия плана со статусами задач (A1–A3 ✅).
- `CHANGES.md` — этот журнал изменений.
